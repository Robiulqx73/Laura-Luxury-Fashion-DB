import fs from 'fs';

const filepath = './src/App.tsx';
let content = fs.readFileSync(filepath, 'utf8');

// Use regex to locate the part from "শপিং ব্যাগে যোগ করুন (Add to Bag)\n                  </button>" down to "/* Dynamic order tracking modal */"
const regex = /শপিং ব্যাগে যোগ করুন \(Add to Bag\)[\s\S]*?\/\* Dynamic order tracking modal \*\//;

if (regex.test(content)) {
  const cleanPart = `শপিং ব্যাগে যোগ করুন (Add to Bag)
                  </button>
                </div>
              </div>
            </div>
          </div>
        )

        /* Dynamic order tracking modal */`;
        
  content = content.replace(regex, cleanPart);
  fs.writeFileSync(filepath, content, 'utf8');
  console.log('Successfully cleaned up the corrupted block!');
} else {
  console.error('Could not find pattern in file.');
}
