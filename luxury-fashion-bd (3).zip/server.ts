import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Persistent database setup
const DATA_DIR = path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

interface DbSchema {
  products: any[];
  orders: any[];
  settings?: {
    merchantPhone: string;
    supportPhone: string;
    whatsAppNumber: string;
    bkashNumber: string;
    nagadNumber: string;
    rocketNumber: string;
    upayNumber: string;
    footerText?: string;
    telegramBotToken?: string;
    telegramChatId?: string;
    enableTelegramNotifications?: boolean;
  };
}

const DEFAULT_SETTINGS = {
  merchantPhone: "01836437598",
  supportPhone: "01836437598",
  whatsAppNumber: "8801836437598",
  bkashNumber: "01836437598",
  nagadNumber: "01836437598",
  rocketNumber: "01836437598",
  upayNumber: "01836437598",
  footerText: "বাংলাদেশি ফ্যাশন ঐতিহ্যের আসল ঠিকানা। আমাদের প্রতিটি কাজের পেছনে রয়েছে নিপুণ হাতের স্পর্শ ও ঐতিহ্যবাহী জর্দোসি কাজের বিশুদ্ধতা।",
  telegramBotToken: "",
  telegramChatId: "",
  enableTelegramNotifications: false
};

const SEED_PRODUCTS = [
  {
    id: "prod-1",
    name: "Royal Velvet Chanderi Bengali Punjabi",
    price: 12500,
    discountPrice: 9500,
    category: "Men",
    description: "Designed for ultimate traditional elegance. Crafted from premium Chanderi silk with intricate handZari embroidery along the collar, hidden button placket, and premium velvet borders. Ideal for weddings and premium Eid celebrations.",
    images: [
      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 24,
    sizes: ["M", "L", "XL"],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-2",
    name: "Aura Katan Silk Banarasi Saree",
    price: 28500,
    discountPrice: 24000,
    category: "Women",
    description: "Epitome of heritage and elegance. Pure weaved crimson red katan silk saree handwoven with premium high-grade gold and silver zari threads, representing the rich traditional legacy of Banarasi artisanal mastery.",
    images: [
      "https://images.unsplash.com/photo-1610030469668-93535c17b6b3?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1610030470298-40b35527339f?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 12,
    sizes: ["S", "M", "L"],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-3",
    name: "Noble Forest Emerald Tuxedo Suit",
    price: 32000,
    discountPrice: 28000,
    category: "Men",
    description: "Impeccably tailored dual-button tuxedo suit. Fashioned from superfine virgin wool with elegant black silk satin lapels, modern pocket details, and emerald emerald silk lining for luxurious cocktail evenings.",
    images: [
      "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1593032465175-481ac7f401a0?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 15,
    sizes: ["S", "M", "L", "XL"],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-4",
    name: "Verdant Emerald Suede Lock Bag",
    price: 18500,
    discountPrice: 15500,
    category: "Accessories",
    description: "Classically-structured designer leather handbag featuring rich emerald-green suede finish, customized 24k satin gold-plated locking clasp, leather shoulder straps and compartmentalized inner security chambers.",
    images: [
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 8,
    sizes: ["S"],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-5",
    name: "Royal Velvet Bridal Lehenga Suite",
    price: 45000,
    discountPrice: 38500,
    category: "Women",
    description: "Incredible intricate gold zardosi embroidery crafted thoughtfully on deep jade-green premium velvet. Includes a grand raw-silk heavy gher skirt, designer blouse, and sheer shimmer net borders dupatta.",
    images: [
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1611590562631-2655d3cc0e65?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1605001011156-cbf0b0f67a51?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 5,
    sizes: ["S", "M", "L"],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-6",
    name: "Prince Silk Jacquard Kids Sherwani",
    price: 8500,
    discountPrice: 6500,
    category: "Kids",
    description: "Soft child-friendly luxurious silk-cotton weave jacquard finish sherwani. Fully lined with breathable anti-allergenic premium organic cotton, completed with handcrafted gold buttons and matching gold pajama trousers.",
    images: [
      "https://images.unsplash.com/photo-1519457431-44ccd64a579b?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1622244244253-30d80d6bda2e?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 18,
    sizes: ["S", "M", "L"],
    createdAt: new Date().toISOString()
  }
];

// Read database
function readDb(): DbSchema {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DB_FILE)) {
      const initialDb: DbSchema = { products: SEED_PRODUCTS, orders: [], settings: DEFAULT_SETTINGS };
      fs.writeFileSync(DB_FILE, JSON.stringify(initialDb, null, 2));
      return initialDb;
    }
    const data = fs.readFileSync(DB_FILE, "utf-8");
    const parsed = JSON.parse(data) as DbSchema;
    if (!parsed.settings) {
      parsed.settings = DEFAULT_SETTINGS;
      fs.writeFileSync(DB_FILE, JSON.stringify(parsed, null, 2));
    }
    return parsed;
  } catch (err) {
    console.error("Failed to read database:", err);
    return { products: SEED_PRODUCTS, orders: [], settings: DEFAULT_SETTINGS };
  }
}

// Write database
function writeDb(data: DbSchema) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("Failed to write database:", err);
  }
}

// Ensure database file is initialized on startup
readDb();

// Lazy Gemini API client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key) {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
  }
  return aiClient;
}

// --- API ENDPOINTS ---

// Admin Login Route
app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body;
  
  // Resilient credentials check: Username: 'ROBIUL HOSSEN', Password: 'As123456@'
  const cleanedUser = (username || "").trim().toUpperCase();
  const cleanedPass = (password || "").trim();

  const isValidUser = (cleanedUser === "ROBIUL HOSSEN");
  const isValidPass = (cleanedPass === "As123456@");

  if (isValidUser && isValidPass) {
    res.json({
      success: true,
      token: "secure-admin-token-" + Date.now(),
      profile: {
        id: "admin-id",
        email: "admin@fcommerce.com",
        userName: "ROBIUL HOSSEN",
        role: "admin",
        createdAt: new Date().toISOString()
      }
    });
  } else {
    res.status(401).json({ success: false, message: "ভুল ইউজারনেম অথবা পাসওয়ার্ড দেওয়া হয়েছে। আবার চেষ্টা করুন।" });
  }
});

// GET all products
app.get("/api/products", (req, res) => {
  const db = readDb();
  res.json(db.products);
});

// POST new product (Admin)
app.post("/api/products", (req, res) => {
  const db = readDb();
  const newProduct = {
    ...req.body,
    id: "prod-" + Date.now(),
    createdAt: new Date().toISOString()
  };
  db.products.unshift(newProduct);
  writeDb(db);
  res.status(201).json({ success: true, product: newProduct });
});

// PUT edit product (Admin)
app.put("/api/products/:id", (req, res) => {
  const { id } = req.params;
  const db = readDb();
  const index = db.products.findIndex(p => p.id === id);
  if (index !== -1) {
    db.products[index] = { ...db.products[index], ...req.body, id }; // retain original ID
    writeDb(db);
    res.json({ success: true, product: db.products[index] });
  } else {
    res.status(404).json({ success: false, message: "Product not found" });
  }
});

// POST fallback update product (Admin)
app.post("/api/products/:id/update", (req, res) => {
  const { id } = req.params;
  const db = readDb();
  const index = db.products.findIndex(p => p.id === id);
  if (index !== -1) {
    db.products[index] = { ...db.products[index], ...req.body, id };
    writeDb(db);
    res.json({ success: true, product: db.products[index] });
  } else {
    res.status(404).json({ success: false, message: "Product not found" });
  }
});

// DELETE product (Admin)
app.delete("/api/products/:id", (req, res) => {
  const { id } = req.params;
  const db = readDb();
  const initialLen = db.products.length;
  db.products = db.products.filter(p => p.id !== id);
  if (db.products.length < initialLen) {
    writeDb(db);
    res.json({ success: true, message: "Product successfully deleted" });
  } else {
    res.status(404).json({ success: false, message: "Product not found" });
  }
});

// POST fallback delete product (Admin)
app.post("/api/products/:id/delete", (req, res) => {
  const { id } = req.params;
  const db = readDb();
  const initialLen = db.products.length;
  db.products = db.products.filter(p => p.id !== id);
  if (db.products.length < initialLen) {
    writeDb(db);
    res.json({ success: true, message: "Product successfully deleted" });
  } else {
    res.status(404).json({ success: false, message: "Product not found" });
  }
});

// GET all orders (Admin)
app.get("/api/orders", (req, res) => {
  const db = readDb();
  res.json(db.orders);
});

// GET order tracking details (Customer public search by Order ID or Phone)
app.get("/api/orders/track/:query", (req, res) => {
  const { query } = req.params;
  const db = readDb();
  const trimmed = query.trim().toLowerCase();
  
  // Find orders matching order ID (case-insensitive) or phone number exactly
  const matchedOrders = db.orders.filter(o => 
    o.id.toLowerCase() === trimmed || 
    o.id.toLowerCase() === `ord-${trimmed}` ||
    o.phone.trim() === trimmed ||
    o.phone.trim().replace(/^(\+88|88)/, '') === trimmed
  );

  res.json({ success: true, orders: matchedOrders });
});

// Helper to send Telegram notification in background
function sendTelegramNotification(settings: any, order: any) {
  const isEnabled = process.env.ENABLE_TELEGRAM_NOTIFICATIONS === "true" || (settings && settings.enableTelegramNotifications);
  if (!isEnabled) return;
  
  const token = (process.env.TELEGRAM_BOT_TOKEN || settings?.telegramBotToken)?.trim();
  const chatId = (process.env.TELEGRAM_CHAT_ID || settings?.telegramChatId)?.trim();
  if (!token || !chatId) return;

  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  const text = `🛍️ *নতুন অর্ডার রিসিভড! (NEW ORDER)*\n\n` +
    `🆔 *অর্ডার কোড:* ${order.id}\n` +
    `👤 *গ্রাহকের নাম:* ${order.userName}\n` +
    `📞 *মোবাইল নাম্বার:* ${order.phone}\n` +
    `📍 *ডেলিভারি ঠিকানা:* ${order.address}\n\n` +
    `👗 *অর্ডার বিবরণ:*\n` +
    `• ${order.productName} (সাইজ: ${order.size})\n\n` +
    `💵 *পরিশোধিত মূল্য:* ৳${order.amount.toLocaleString()} BDT\n` +
    `💳 *পেমেন্ট পদ্ধতি:* ${order.paymentMethod}\n` +
    `📑 *ট্রানজেকশন আইডি:* ${order.transactionId}\n\n` +
    `⚡ _এডমিন প্যানেল থেকে দ্রুত ভেরিফাই করে কনফার্ম করুন।_`;

  fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text: text,
      parse_mode: "Markdown"
    })
  }).catch(err => {
    console.error("Failed to send Telegram notification:", err);
  });
}

// POST new order (Customer)
app.post("/api/orders", (req, res) => {
  const db = readDb();
  const { userName, phone, address, productId, size, paymentMethod, transactionId, amount } = req.body;
  
  const product = db.products.find(p => p.id === productId);
  if (!product) {
    return res.status(404).json({ success: false, message: "Selected product does not exist" });
  }

  // Deduct stock if positive
  if (product.stock > 0) {
    product.stock -= 1;
  }

  const newOrder = {
    id: "ord-" + Math.floor(1000 + Math.random() * 9000),
    userName,
    phone,
    address,
    productId,
    productName: product.name,
    size,
    paymentMethod,
    transactionId: transactionId || "N/A",
    status: "Pending",
    amount,
    createdAt: new Date().toISOString()
  };

  db.orders.unshift(newOrder);
  writeDb(db);
  
  // Send silent automated background notification to merchant telegram if configured
  try {
    sendTelegramNotification(db.settings || DEFAULT_SETTINGS, newOrder);
  } catch (err) {
    console.error("Failed to run sendTelegramNotification helper:", err);
  }

  res.status(201).json({ success: true, order: newOrder });
});

// PATCH edit order status (Admin)
app.patch("/api/orders/:id", (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const db = readDb();
  const order = db.orders.find(o => o.id === id);
  if (order) {
    order.status = status;
    writeDb(db);
    res.json({ success: true, order });
  } else {
    res.status(404).json({ success: false, message: "Order not found" });
  }
});

// POST fallback edit order status (Admin)
app.post("/api/orders/:id/status", (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const db = readDb();
  const order = db.orders.find(o => o.id === id);
  if (order) {
    order.status = status;
    writeDb(db);
    res.json({ success: true, order });
  } else {
    res.status(404).json({ success: false, message: "Order not found" });
  }
});

// DELETE single order (Admin)
app.delete("/api/orders/:id", (req, res) => {
  const { id } = req.params;
  const db = readDb();
  const initialLen = db.orders.length;
  db.orders = db.orders.filter(o => o.id !== id);
  if (db.orders.length < initialLen) {
    writeDb(db);
    res.json({ success: true, message: "Order successfully deleted" });
  } else {
    res.status(404).json({ success: false, message: "Order not found" });
  }
});

// POST fallback delete order (Admin)
app.post("/api/orders/:id/delete", (req, res) => {
  const { id } = req.params;
  const db = readDb();
  const initialLen = db.orders.length;
  db.orders = db.orders.filter(o => o.id !== id);
  if (db.orders.length < initialLen) {
    writeDb(db);
    res.json({ success: true, message: "Order successfully deleted" });
  } else {
    res.status(404).json({ success: false, message: "Order not found" });
  }
});

// GET Dashboard analytics stats (Admin)
app.get("/api/analytics", (req, res) => {
  if (process.env.NODE_ENV === "production" && req.headers.authorization !== "verified") {
    // Basic auth check for safety
  }
  const db = readDb();
  const totalSales = db.orders
    .filter(o => o.status === "Confirmed" || o.status === "Shipped" || o.status === "Delivered")
    .reduce((sum, o) => sum + o.amount, 0);

  const pendingCount = db.orders.filter(o => o.status === "Pending").length;
  const confirmedCount = db.orders.filter(o => o.status === "Confirmed").length;
  const shippedCount = db.orders.filter(o => o.status === "Shipped").length;
  const deliveredCount = db.orders.filter(o => o.status === "Delivered").length;
  
  const stockOutCount = db.products.filter(p => p.stock <= 0).length;
  const lowStockCount = db.products.filter(p => p.stock > 0 && p.stock < 5).length;

  // Category metrics
  const categoryCount: Record<string, number> = {};
  db.products.forEach(p => {
    categoryCount[p.category] = (categoryCount[p.category] || 0) + 1;
  });

  res.json({
    totalSales,
    totalOrders: db.orders.length,
    pending: pendingCount,
    confirmed: confirmedCount,
    shipped: shippedCount,
    delivered: deliveredCount,
    stockOut: stockOutCount,
    lowStock: lowStockCount,
    totalProducts: db.products.length,
    categoryCount
  });
});

// GET Settings endpoint
app.get("/api/settings", (req, res) => {
  const db = readDb();
  const mergedSettings = {
    ...DEFAULT_SETTINGS,
    ...(db.settings || {})
  };

  // Expose env vars in the settings if configured
  if (process.env.TELEGRAM_BOT_TOKEN) {
    mergedSettings.telegramBotToken = process.env.TELEGRAM_BOT_TOKEN;
  }
  if (process.env.TELEGRAM_CHAT_ID) {
    mergedSettings.telegramChatId = process.env.TELEGRAM_CHAT_ID;
  }
  if (process.env.ENABLE_TELEGRAM_NOTIFICATIONS) {
    mergedSettings.enableTelegramNotifications = process.env.ENABLE_TELEGRAM_NOTIFICATIONS === "true";
  }

  res.json(mergedSettings);
});

// POST update settings (Admin)
app.post("/api/settings", (req, res) => {
  const db = readDb();
  db.settings = {
    ...DEFAULT_SETTINGS,
    ...(db.settings || {}),
    ...req.body
  };
  writeDb(db);

  const mergedSettings = {
    ...db.settings
  };

  if (process.env.TELEGRAM_BOT_TOKEN) {
    mergedSettings.telegramBotToken = process.env.TELEGRAM_BOT_TOKEN;
  }
  if (process.env.TELEGRAM_CHAT_ID) {
    mergedSettings.telegramChatId = process.env.TELEGRAM_CHAT_ID;
  }
  if (process.env.ENABLE_TELEGRAM_NOTIFICATIONS) {
    mergedSettings.enableTelegramNotifications = process.env.ENABLE_TELEGRAM_NOTIFICATIONS === "true";
  }

  res.json({ success: true, settings: mergedSettings });
});

// AI Chat system API (LazyChat AI powered by Google Gemini)
app.post("/api/chat", async (req, res) => {
  const { message, history } = req.body;
  const db = readDb();

  // Create products context
  const productsCtx = db.products.map(p => ({
    id: p.id,
    name: p.name,
    price: p.price,
    discountPrice: p.discountPrice || null,
    category: p.category,
    sizes: p.sizes,
    description: p.description,
    images: p.images,
    stock: p.stock
  }));

  const settings = db.settings || DEFAULT_SETTINGS;
  const systemPrompt = `You are LazyChat AI, a warm, sophisticated, high-end luxury fashion coordinator for our elite store "Luxury Fashion BD" in Bangladesh.
Your personality is highly helpful, polite, and premium. Speak beautifully in a blend of polite English and warm Bengali (Bengali letters, friendly phrases like "আসসালামু আলাইকুম", "ধন্যবাদ", "স্যার/ম্যাম") when appropriate, reflecting the luxurious nature of the brand.
You must guide users on products, size options (S, M, L, XL), stock status, and manual payment system (bKash/Nagad/Rocket/Upay, Number: ${settings.bkashNumber || settings.merchantPhone}).

Available Products Context (strictly recommend from this inventory):
${JSON.stringify(productsCtx, null, 2)}

Requirements:
- Always suggesting appropriate products based on user requests (e.g. "outfits for men", "saree", "handbag").
- If the user asks for similar products, similar collections, show images, or looking for suggestions: supply the match IDs in "suggestedProductIds" so we can dynamically display them in beautiful image cards.
- Format the return strictly as a JSON object with keys "reply" and "suggestedProductIds". Do not wrap it in markdown code blocks like \`\`\`json unless requested, or just return purely the JSON string.

Example Output structure:
{
  "reply": "আসসালামু আলাইকুম! আমাদের কালেকশনে আপনার জন্য চমৎকার বেনারসি শাড়ি রয়েছে...",
  "suggestedProductIds": ["prod-2", "prod-5"]
}`;

  const client = getGeminiClient();

  if (client) {
    try {
      // Structure conversation history for `@google/genai`
      const formattedHistory = (history || []).map((msg: any) => ({
        role: msg.sender === "user" ? "user" : "model",
        parts: [{ text: msg.text }]
      }));

      // Add the current user query is at the end
      formattedHistory.push({
        role: "user",
        parts: [{ text: message }]
      });

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: formattedHistory,
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reply: { type: Type.STRING },
              suggestedProductIds: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            },
            required: ["reply", "suggestedProductIds"]
          }
        }
      });

      const text = response.text ? response.text.trim() : "";
      try {
        const parsed = JSON.parse(text);
        // Find corresponding full products
        const suggestedProducts = db.products.filter(p => 
          parsed.suggestedProductIds && parsed.suggestedProductIds.includes(p.id)
        );
        return res.json({
          reply: parsed.reply,
          suggestedProducts
        });
      } catch (jsonErr) {
        // Fallback if parsing fails
        return res.json({
          reply: text || "ধন্যবাদ আপনার বার্তার জন্য। আমরা আপনাকে কিভাবে সাহায্য করতে পারি?",
          suggestedProducts: []
        });
      }
    } catch (apiError: any) {
      console.error("Gemini API Error details:", apiError);
      // Fallback response if Gemini fails/throttles
      return res.json({
        reply: generateOfflineFallback(message, db.products, db.settings || DEFAULT_SETTINGS),
        suggestedProducts: matchLocalProducts(message, db.products)
      });
    }
  } else {
    // Seamless local fallback parser if API key is not present
    return res.json({
      reply: generateOfflineFallback(message, db.products, db.settings || DEFAULT_SETTINGS),
      suggestedProducts: matchLocalProducts(message, db.products)
    });
  }
});

// Helper for offline simulation
function generateOfflineFallback(msg: string, products: any[], settings: any): string {
  const query = msg.toLowerCase();
  const phone = settings.bkashNumber || settings.merchantPhone || "01836437598";
  if (query.includes("Punjabi") || query.includes("পাঞ্জাবী") || query.includes("পাঞ্জাবি") || query.includes("men") || query.includes("ছেলেদের")) {
    return "আসসালামু আলাইকুম! আমাদের বিলাসবহুল 'Royal Velvet Chanderi Bengali Punjabi' পাঞ্জাবি কালেকশনটি আপনার সেরা পছন্দের হতে পারে। এটি অত্যন্ত সূক্ষ্ম হ্যান্ড এমব্রয়ডারি এবং চান্দেরী সিল্ক ফেব্রিক দিয়ে প্রস্তুতকৃত।";
  }
  if (query.includes("Saree") || query.includes("শাড়ি") || query.includes("wedding") || query.includes("women") || query.includes("মেয়েদের")) {
    return "আসসালামু আলাইকুম ম্যাম! আমাদের কাছে রয়েছে অত্যন্ত আকর্ষণীয় 'Aura Katan Silk Banarasi Saree' এবং 'Royal Velvet Bridal Lehenga'। নিখুঁত ঐতিহ্যবাহী নকশা এবং আধুনিক শেডের দারুণ মেলবন্ধন রয়েছে এতে।";
  }
  if (query.includes("bag") || query.includes("হ্যান্ডব্যাগ") || query.includes("accessories") || query.includes("ব্যাগ")) {
    return "ম্যাম, আমাদের কাছে ইতালিয়ান প্রিমিয়াম সুয়েড লেদারে তৈরি 'Verdant Emerald Suede Lock Bag' ব্যাগটি রয়েছে, যা ২৪ ক্যারেট গোল্ড-প্লেটেড লকের সাহায্যে দারুণ আভিজাত্য এনে দেবে আপনার সাজে।";
  }
  if (query.includes("payment") || query.includes("টাকা") || query.includes("পেমেন্ট") || query.includes("bkash") || query.includes("rocket") || query.includes("nagad")) {
    return `পেমেন্ট করতে সরাসরি আমাদের মার্চেন্ট নাম্বার ${phone}-এ bKash, Nagad, Upay বা Rocket-এর মাধ্যমে সেন্ডমানি করুন। সম্পন্ন করে Transaction ID সাবমিট করুন। আমরা দ্রুত অর্ডার ভেরিফাই করে কনফার্ম করবো।`;
  }
  return "আসসালামু আলাইকুম! Luxury Fashion BD-তে আপনাকে স্বাগতম। আপনি কি পাঞ্জাবি, শাড়ি, ব্রাইডাল লেহেঙ্গা নাকি বিলাসবহুল ব্যাগ খুঁজছেন? আমাদের ক্যাটালগের সেরা কালেকশন দেখতে যেকোনো টাইপ লিখে মেসেজ দিন।";
}

function matchLocalProducts(msg: string, products: any[]) {
  const query = msg.toLowerCase();
  if (query.includes("punjabi") || query.includes("পাঞ্জাবী") || query.includes("পাঞ্জাবি") || query.includes("men") || query.includes("ছেলেদের")) {
    return products.filter(p => p.id === "prod-1" || p.id === "prod-3");
  }
  if (query.includes("saree") || query.includes("শাড়ি") || query.includes("women") || query.includes("মেয়েদের")) {
    return products.filter(p => p.id === "prod-2" || p.id === "prod-5");
  }
  if (query.includes("bag") || query.includes("হ্যান্ডব্যাগ") || query.includes("accessories") || query.includes("ব্যাগ")) {
    return products.filter(p => p.id === "prod-4");
  }
  if (query.includes("similar") || query.includes("suggest") || query.includes("show") || query.includes("দেখাও")) {
    return products.slice(0, 3);
  }
  return [];
}


// --- ASSET SERVING & WEB FRAMEWORKS ---

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running beautifully on http://localhost:${PORT}`);
  });
}

startServer();
