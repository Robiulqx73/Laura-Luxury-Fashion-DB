/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  ShoppingBag, Heart, MessageSquare, Shield, X, Copy, Check, CheckCircle, Send, 
  ChevronLeft, ChevronRight, Search, Plus, Filter, Trash2, Edit, 
  RotateCcw, Sparkles, AlertCircle, TrendingUp, CheckCheck, Landmark, CheckSquare, Eye, Phone, MapPin,
  Camera, Upload, EyeOff, Truck, Package, Clock, Mic, Paperclip, Play, Pause, Sun, Moon, Volume2, Maximize2
} from "lucide-react";
import { Product, Order, Category, SizeOption, PaymentMethod, OrderStatus, ChatMessage } from "./types";

const LOCAL_SEED_PRODUCTS: Product[] = [
  {
    id: "prod-1",
    name: "Royal Velvet Chanderi Bengali Punjabi",
    price: 12500,
    discountPrice: 9500,
    category: "Men",
    description: "Designed for ultimate traditional elegance. Crafted from premium Chanderi silk with intricate handZari embroidery along the collar, hidden button placket, and premium velvet borders. Ideal for weddings and premium Eid celebrations.",
    images: [
      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 24,
    sizes: ["M", "L", "XL"],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-2",
    name: "Aura Katan Silk Banarasi Saree",
    price: 28500,
    discountPrice: 24000,
    category: "Women",
    description: "Epitome of heritage and elegance. Pure weaved crimson red katan silk saree handwoven with premium high-grade gold and silver zari threads, representing the rich traditional legacy of Banarasi artisanal mastery.",
    images: [
      "https://images.unsplash.com/photo-1610030469668-93535c17b6b3?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1610030470298-40b35527339f?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 12,
    sizes: ["S", "M", "L"],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-3",
    name: "Noble Forest Emerald Tuxedo Suit",
    price: 32000,
    discountPrice: 28000,
    category: "Men",
    description: "Impeccably tailored dual-button tuxedo suit. Fashioned from superfine virgin wool with elegant black silk satin lapels, modern pocket details, and emerald emerald silk lining for luxurious cocktail evenings.",
    images: [
      "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1593032465175-481ac7f401a0?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 15,
    sizes: ["S", "M", "L", "XL"],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-4",
    name: "Verdant Emerald Suede Lock Bag",
    price: 18500,
    discountPrice: 15500,
    category: "Accessories",
    description: "Classically-structured designer leather handbag featuring rich emerald-green suede finish, customized 24k satin gold-plated locking clasp, leather shoulder straps and compartmentalized inner security chambers.",
    images: [
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 8,
    sizes: ["S"],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-5",
    name: "Royal Velvet Bridal Lehenga Suite",
    price: 45000,
    discountPrice: 38500,
    category: "Women",
    description: "Incredible intricate gold zardosi embroidery crafted thoughtfully on deep jade-green premium velvet. Includes a grand raw-silk heavy gher skirt, designer blouse, and sheer shimmer net borders dupatta.",
    images: [
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1611590562631-2655d3cc0e65?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1605001011156-cbf0b0f67a51?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 5,
    sizes: ["S", "M", "L"],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-6",
    name: "Prince Silk Jacquard Kids Sherwani",
    price: 8500,
    discountPrice: 6500,
    category: "Kids",
    description: "Soft child-friendly luxurious silk-cotton weave jacquard finish sherwani. Fully lined with breathable anti-allergenic premium organic cotton, completed with handcrafted gold buttons and matching gold pajama trousers.",
    images: [
      "https://images.unsplash.com/photo-1519457431-44ccd64a579b?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1622244244253-30d80d6bda2e?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?auto=format&fit=crop&q=80&w=800"
    ],
    stock: 18,
    sizes: ["S", "M", "L"],
    createdAt: new Date().toISOString()
  }
];

const DEFAULT_SETTINGS = {
  merchantPhone: "01836437598",
  supportPhone: "01836437598",
  whatsAppNumber: "8801836437598",
  bkashNumber: "01836437598",
  nagadNumber: "01836437598",
  rocketNumber: "01836437598",
  upayNumber: "01836437598",
  footerText: "বাংলাদেশি ফ্যাশন ঐতিহ্যের আসল ঠিকানা। আমাদের প্রতিটি কাজের পেছনে রয়েছে নিপুণ হাতের স্পর্শ ও ঐতিহ্যবাহী জর্দোসি কাজের বিশুদ্ধতা।",
  telegramBotToken: "",
  telegramChatId: "",
  enableTelegramNotifications: false
};


// Official logos represented simply or dynamically
const PAYMENT_LOGOS = {
  bKash: "https://download.logo.wine/logo/BKash/BKash-Logo.wine.png",
  Nagad: "https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png",
  Rocket: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Dutch-Bangla_Bank_Rocket_Logo.svg/512px-Dutch-Bangla_Bank_Rocket_Logo.svg.png",
  Upay: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Upay_logo.svg/512px-Upay_logo.svg.png",
  "Cash on Delivery": "https://cdn-icons-png.flaticon.com/512/1554/1554401.png"
};

// Beautiful, modular fallback vector graphics for all major Bangladeshi Payment systems
const renderPaymentLogoFallback = (method: PaymentMethod) => {
  switch (method) {
    case "bKash":
      return (
        <svg className="w-full h-full object-contain p-1" viewBox="0 0 160 55" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="160" height="55" rx="10" fill="#E2136E" />
          <g transform="translate(15, 6) scale(0.95)">
            <path d="M25 10 L35 22 L25 28 Z" fill="#ffffff" />
            <path d="M25 28 L35 22 L46 38 L25 41 Z" fill="#ffffff" opacity="0.95" />
            <path d="M5 38 L16 28 L25 28 L18 41 Z" fill="#ffffff" opacity="0.9" />
            <path d="M16 28 L30 4 L25 28 Z" fill="#ffffff" opacity="0.85" />
            <path d="M18 41 L27 28 L31 46 Z" fill="#ffffff" opacity="0.8" />
            <text x="54" y="28" fill="#ffffff" fontFamily="sans-serif" fontSize="19" fontWeight="950">bKash</text>
          </g>
        </svg>
      );
    case "Nagad":
      return (
        <svg className="w-full h-full object-contain p-1" viewBox="0 0 160 55" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="160" height="55" rx="10" fill="#F04E23" />
          <g transform="translate(15, 5)">
            <path d="M22 36 C13 31, 13 13, 27 11 C24 19, 30 23, 27 36 C34 23, 37 16, 30 8 C40 11, 42 26, 34 36" fill="#ffffff" />
            <circle cx="27" cy="23" r="3" fill="#FFE500" />
            <text x="50" y="29" fill="#ffffff" fontFamily="sans-serif" fontSize="20" fontWeight="950">নগদ</text>
          </g>
        </svg>
      );
    case "Rocket":
      return (
        <svg className="w-full h-full object-contain p-1" viewBox="0 0 160 55" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="160" height="55" rx="10" fill="#8C3494" />
          <g transform="translate(14, 5)">
            <circle cx="22" cy="22" r="16" stroke="#ffffff" strokeWidth="2" strokeDasharray="3 1.5" opacity="0.8" />
            <path d="M22 7 L27 18 L27 29 L22 34 L17 29 L17 18 Z" fill="#ffffff" />
            <path d="M22 7 L25 13 L19 13 Z" fill="#FFE500" />
            <path d="M17 23 L11 29 L17 28 Z" fill="#ffffff" />
            <path d="M27 23 L33 29 L27 28 Z" fill="#ffffff" />
            <text x="50" y="28" fill="#ffffff" fontFamily="sans-serif" fontSize="18" fontWeight="950"> Rocket</text>
          </g>
        </svg>
      );
    case "Upay":
      return (
        <svg className="w-full h-full object-contain p-1" viewBox="0 0 160 55" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="160" height="55" rx="10" fill="#005C9A" />
          <g transform="translate(15, 5)">
            <circle cx="22" cy="22" r="16" fill="#ffffff" />
            <path d="M14 18 L14 26 C14 31, 26 31, 26 26 L26 18" stroke="#005C9A" strokeWidth="4.5" strokeLinecap="round" fill="none" />
            <circle cx="26" cy="14" r="3.5" fill="#FFE500" />
            <text x="48" y="28" fontFamily="sans-serif" fontSize="20" fontWeight="950">
              <tspan fill="#38BDF8">up</tspan><tspan fill="#FFE500">ay</tspan>
            </text>
          </g>
        </svg>
      );
    case "Cash on Delivery":
      return (
        <svg className="w-full h-full object-contain p-1" viewBox="0 0 160 55" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="160" height="55" rx="10" fill="#059669" />
          <g transform="translate(10, 5) scale(0.95)" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none">
            <path d="M12 15 L5 15 L5 25 L23 25 L23 15 Z" fill="#059669" opacity="0.3" stroke="none" />
            <path d="M12 15 L5 15 L5 25 L23 25 L23 15 Z" />
            <path d="M23 18 L31 18 L36 23 L36 25 L23 25 Z" />
            <circle cx="10" cy="29" r="3" fill="#ffffff" />
            <circle cx="28" cy="29" r="3" fill="#ffffff" />
            <text x="44" y="22" fill="#ffffff" stroke="none" fontFamily="sans-serif" fontSize="14" fontWeight="800">C.O.D.</text>
          </g>
        </svg>
      );
    default:
      return null;
  }
};

// ==========================================
// INTERACTIVE COMPACT IN-CHAT LIVE ORDER TRACKER
// ==========================================
interface InteractiveTrackerProps {
  shopSettings: any;
  chatTheme: 'dark' | 'light';
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export function ChatMessageInteractiveTracker({ shopSettings, chatTheme, showToast }: InteractiveTrackerProps) {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [searchResult, setSearchResult] = useState<any>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleDeepTrack = async () => {
    if (!phoneNumber.trim()) {
      showToast("দয়া করে প্রিমিয়াম অর্ডার আইডি অথবা মোবাইল লিখুন!", "error");
      return;
    }
    setLoading(true);
    setHasSearched(false);
    
    // Simulate minor delay of elegant royal courier lookup
    await new Promise(r => setTimeout(r, 1000));
    
    try {
      const res = await fetch(`/api/orders?phone=${encodeURIComponent(phoneNumber.trim())}&orderId=${encodeURIComponent(phoneNumber.trim())}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.orders && data.orders.length > 0) {
          setSearchResult(data.orders[0]);
        } else {
          // Standard custom mock trace for demo booking orders
          const fakeCode = phoneNumber.trim().toLowerCase();
          setSearchResult({
            orderId: fakeCode.startsWith("ord-") ? fakeCode.toUpperCase() : "ORD-" + Math.floor(Math.random() * 8000 + 1000),
            name: "সম্মানিত রাজকীয় ক্রেতা",
            phone: phoneNumber,
            address: "গুলশান ২, ঢাকা",
            items: [{ name: "রাজকীয় জরির কাজ সিল্ক পাঞ্জাবী", quantity: 1, size: "40" }],
            subtotal: 4200,
            total: 4300,
            status: "shipped", 
            trxId: "BK91X05M",
            date: new Date().toLocaleDateString('bn-BD')
          });
        }
      } else {
        throw new Error("api trace issue");
      }
    } catch(e) {
      const fakeCode = phoneNumber.trim().toLowerCase();
      setSearchResult({
        orderId: fakeCode.startsWith("ord-") ? fakeCode.toUpperCase() : "ORD-" + Math.floor(Math.random() * 8000 + 1000),
        name: "সম্মানিত মেম্বার",
        phone: phoneNumber,
        address: "ধানমণ্ডি, ঢাকা",
        items: [{ name: "বেনারসি কাতান গর্জিয়াস হ্যান্ডলুম শাড়ি", quantity: 1, size: "ফ্রি সাইজ" }],
        subtotal: 8500,
        total: 8600,
        status: "confirmed", 
        trxId: "NG88E401",
        date: new Date().toLocaleDateString('bn-BD')
      });
    } finally {
      setLoading(false);
      setHasSearched(true);
    }
  };

  const getStepStatusIcon = (step: string, currentStatus: string) => {
    const states = ["submitted", "confirmed", "shipped", "delivered"];
    const stepIdx = states.indexOf(step);
    const currentIdx = states.indexOf(currentStatus || "submitted");
    if (stepIdx <= currentIdx) return "✓";
    return stepIdx + 1;
  };

  const getStepColor = (step: string, currentStatus: string) => {
    const states = ["submitted", "confirmed", "shipped", "delivered"];
    const stepIdx = states.indexOf(step);
    const currentIdx = states.indexOf(currentStatus || "submitted");
    if (stepIdx < currentIdx) return "bg-emerald-600 text-white border-emerald-600Line";
    if (stepIdx === currentIdx) return "bg-emerald-500 text-[#0c1317] border-double border-4 border-yellow-400 animate-pulse font-extrabold";
    return "bg-neutral-800 text-neutral-500 border-neutral-700";
  };

  return (
    <div className={`p-4 rounded-2xl border ${
      chatTheme === 'dark' ? 'bg-[#182229] border-emerald-900/40 text-neutral-200 shadow-inner' : 'bg-neutral-50 border-neutral-200 text-neutral-850 shadow-sm'
    }`}>
      <h5 className={`text-[11px] font-black uppercase tracking-wider mb-2.5 flex items-center gap-1.5 ${
        chatTheme === 'dark' ? 'text-yellow-405' : 'text-emerald-950'
      }`}>
        📦 লাইভ ক্যাটালগ এবং বুকিং ট্র্যাকিং সিস্টেম
      </h5>
      
      {!hasSearched ? (
        <div className="space-y-2">
          <p className="text-[10px] leading-relaxed text-neutral-400">
            অর্ডার আইডি (যেমন ord-1485) কিংবা অর্ডার দেওয়ার সময় ব্যবহৃত ফোন নাম্বারটি লিখুন:
          </p>
          <div className="flex gap-2">
            <input 
              type="text" 
              placeholder="017XXXXXXXX অথবা ord-ID"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className={`flex-1 p-2 py-1.5 rounded-xl text-xs border focus:outline-none focus:ring-1 ${
                chatTheme === 'dark' 
                  ? 'bg-[#2a3942] border-neutral-700 text-white focus:ring-emerald-700' 
                  : 'bg-white border-neutral-300 text-neutral-800 focus:ring-emerald-900/50'
              }`}
            />
            <button 
              onClick={handleDeepTrack}
              disabled={loading}
              className="bg-emerald-900 hover:bg-emerald-800 text-white text-[10px] p-2 px-4 rounded-xl font-extrabold cursor-pointer transition uppercase"
            >
              {loading ? "খোঁজা হচ্ছে..." : "ট্র্যাক করুন"}
            </button>
          </div>
        </div>
      ) : searchResult ? (
        <div className="space-y-4 animate-fade-in text-[11px]">
          <div className="flex justify-between items-start border-b border-dashed border-neutral-700/25 pb-2">
            <div>
              <p className="font-bold">আইডি: <span className="font-mono text-yellow-400">{searchResult.orderId}</span></p>
              <p className="text-[9px] text-neutral-400">অর্ডার তারিখ: {searchResult.date}</p>
            </div>
            <div className="text-right">
              <p className="text-[9px] text-neutral-400">ক্রেতা: {searchResult.name}</p>
              <p className="text-[9px] text-neutral-403">মোট বিল: <span className="font-bold text-emerald-400">৳{searchResult.total.toLocaleString()}</span></p>
            </div>
          </div>

          {/* DELIVER TIMELINE TRACK */}
          <div className="space-y-3.5 Relative relative pl-1.5">
            {[
              { key: "submitted", title: "অর্ডার দাখিল করা হয়েছে", desc: "আমরা আপনার পেমেন্ট ভেরিফিকেশন রিকোয়েস্ট পেয়েছি" },
              { key: "confirmed", title: "কনফার্মড এবং প্রসেসিং", desc: "আমাদের তাঁতিরা পোশাকটি রেডি করে রানিং স্পেসিফিকেশন চেক করছে" },
              { key: "shipped", title: "কুরিয়ার কন্টেইনারে হস্তান্তর", desc: "পাঠাও/রেডেক্স পার্সেল সেন্টারে পণ্যটি রুট করা হয়েছে" },
              { key: "delivered", title: "ডেলিভারড সুদ্ধি", desc: "আপনার ঠিকানায় পার্সেলটি সফলভাবে হস্তান্তর সম্পূর্ণ হয়েছে" }
            ].map((st, sIdx) => {
              const active = getStepStatusIcon(st.key, searchResult.status) === "✓";
              const isCurrent = searchResult.status === st.key;
              return (
                <div key={st.key} className="flex gap-3 relative">
                  {/* Timeline segment connector */}
                  {sIdx < 3 && (
                    <div className={`absolute left-3.5 top-6 bottom-[-20px] w-[2px] ${
                      active ? 'bg-emerald-600' : 'bg-neutral-800'
                    }`} />
                  )}
                  
                  <span className={`w-7 h-7 rounded-full border flex items-center justify-center shrink-0 text-xs font-bold ${
                    getStepColor(st.key, searchResult.status)
                  }`}>
                    {getStepStatusIcon(st.key, searchResult.status)}
                  </span>
                  
                  <div>
                    <h6 className={`font-bold text-xs ${
                      active ? 'text-white' : 'text-neutral-500'
                    } ${isCurrent ? 'text-emerald-400 font-extrabold' : ''}`}>
                      {st.title} {isCurrent && "• (চলতি অবস্থা)"}
                    </h6>
                    <p className="text-[10px] text-neutral-400 leading-normal mt-0.5">{st.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 border-t border-dashed border-neutral-700/25 flex justify-between items-center text-[9px] text-neutral-400">
            <span>ট্রাঞ্জেকশন আইডি: <strong className="font-mono text-white">{searchResult.trxId}</strong></span>
            <button 
              onClick={() => setHasSearched(false)}
              className="text-emerald-400 hover:underline font-bold"
            >
              পুনরায় খুঁজুন
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-3 text-center py-2.5">
          <p className="text-red-400 text-[10px]">দুঃখিত! এই আইডি বা নাম্বার দিয়ে কোনো একটিভ অর্ডার কালেকশন খুঁজে পাওয়া যায়নি।</p>
          <button 
            onClick={() => setHasSearched(false)}
            className="text-emerald-400 hover:underline font-bold text-xs cursor-pointer"
          >
            আবার ট্রাই করুন
          </button>
        </div>
      )}
    </div>
  );
}

export default function App() {
  // Page Routing & Navigation
  const [currentTab, setCurrentTab] = useState<Category | 'All' | 'LazyChat'>('All');
  const [searchQuery, setSearchQuery] = useState("");
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [cart, setCart] = useState<{ product: Product; size: SizeOption; quantity: number }[]>([]);
  
  // UI Panels
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);

  // App Database & Server State
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [adminToken, setAdminToken] = useState<string | null>(localStorage.getItem("admin_token"));
  const [loading, setLoading] = useState(true);

  // Dynamic Contact & Payment Settings from Admin
  const [shopSettings, setShopSettings] = useState({
    merchantPhone: "01836437598",
    supportPhone: "01836437598",
    whatsAppNumber: "8801836437598",
    bkashNumber: "01836437598",
    nagadNumber: "01836437598",
    rocketNumber: "01836437598",
    upayNumber: "01836437598",
    footerText: "বাংলাদেশি ফ্যাশন ঐতিহ্যের আসল ঠিকানা। আমাদের প্রতিটি কাজের পেছনে রয়েছে নিপুণ হাতের স্পর্শ ও ঐতিহ্যবাহী জর্দোসি কাজের বিশুদ্ধতা।",
    telegramBotToken: "",
    telegramChatId: "",
    enableTelegramNotifications: false
  });

  // checkout details
  const [checkoutName, setCheckoutName] = useState("");
  const [checkoutPhone, setCheckoutPhone] = useState("");
  const [checkoutAddress, setCheckoutAddress] = useState("");
  const [checkoutPayment, setCheckoutPayment] = useState<PaymentMethod>("bKash");
  const [checkoutTrxId, setCheckoutTrxId] = useState("");
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [checkoutSuccessMessage, setCheckoutSuccessMessage] = useState<string | null>(null);
  const [latestOrderWhatsAppLink, setLatestOrderWhatsAppLink] = useState<string | null>(null);
  const [brokenLogos, setBrokenLogos] = useState<Record<string, boolean>>({});

  // Hero Slider Index
  const [heroIndex, setHeroIndex] = useState(0);
  const heroSlides = [
    {
      title: "Royal Shahi Heritage Collection",
      subtitle: "PREMIUM SILK & HANDCRAFTED WEAVES",
      desc: "Experience elite Bengali craftsmanship with intricate Chanderi Zari work and pure Katan sarees.",
      bg: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=1500"
    },
    {
      title: "Aura of Imperial Bride",
      subtitle: "GOLD EMBROIDERED VELVET LEHENGAS",
      desc: "Draped in majestic gold-embroidered velvet, tailored for elite celebrations and wedding rituals.",
      bg: "https://images.unsplash.com/photo-1610030469668-93535c17b6b3?auto=format&fit=crop&q=80&w=1500"
    },
    {
      title: "Classic Contemporary Luxury",
      subtitle: "EMERALD SUEDE & HIGHEST WOOL CUTS",
      desc: "Exquisite tailored Tuxedos and Italian handcrafted luxury lockbags meant for distinguished wardrobes.",
      bg: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&q=80&w=1500"
    }
  ];

  // Admin authentication form
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // Product Create/Edit Form (Admin)
  const [adminProductMode, setAdminProductMode] = useState<'create' | 'edit'>('create');
  const [adminProductId, setAdminProductId] = useState("");
  const [adminProdName, setAdminProdName] = useState("");
  const [adminProdPrice, setAdminProdPrice] = useState("");
  const [adminProdDiscPrice, setAdminProdDiscPrice] = useState("");
  const [adminProdDesc, setAdminProdDesc] = useState("");
  const [adminProdCategory, setAdminProdCategory] = useState<Category>("Men");
  const [adminProdStock, setAdminProdStock] = useState("");
  const [adminProdImages, setAdminProdImages] = useState<string[]>(["", "", "", ""]);
  const [adminProdSizes, setAdminProdSizes] = useState<SizeOption[]>(["M", "L", "XL"]);

  // LazyChat AI State
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      sender: "assistant",
      text: "আসসালামু আলাইকুম স্যার/ম্যাম! Luxury Fashion BD তে আপনাকে স্বাগতম। আমি LazyChat AI, আপনার পার্সোনাল স্টাইল কোঅর্ডিনেটর। আমাদের পাঞ্জাবী, রাজকীয় শাড়ি, আধুনিক লেহেঙ্গা কিংবা লাক্সারি হ্যান্ডব্যাগ দেখতে যেকোনো কিছু লিখে জিজ্ঞেস করতে পারেন!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'read'
    },
    {
      id: "voice-intro",
      sender: "assistant",
      text: "আপনি চাইলে সরাসরি ভয়েস ও পাঠাতে পারেন, অথবা নিচের কুইক রিপ্লাই দিয়ে আমাকে নির্দেশ করতে পারেন!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      voiceUrl: "mock-intro-voice",
      voiceDuration: "0:12",
      status: 'read'
    }
  ]);
  const [isAiTyping, setIsAiTyping] = useState(false);
  const [chatTheme, setChatTheme] = useState<'dark' | 'light'>('dark');
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);
  const [voicePlayProgress, setVoicePlayProgress] = useState<Record<string, number>>({});
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Active Admin Tab
  const [adminTab, setAdminTab] = useState<'products' | 'orders' | 'analytics' | 'settings'>('analytics');
  const [analytics, setAnalytics] = useState<any>(null);

  // Deletion confirm safety without window block
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [orderDeleteConfirmId, setOrderDeleteConfirmId] = useState<string | null>(null);
  const [adminOrderSearchQuery, setAdminOrderSearchQuery] = useState("");

  // Customer Tracking States
  const [isTrackModalOpen, setIsTrackModalOpen] = useState(false);
  const [userOrderTrackQuery, setUserOrderTrackQuery] = useState("");
  const [userTrackedOrders, setUserTrackedOrders] = useState<any[]>([]);
  const [trackLoading, setTrackLoading] = useState(false);
  const [trackSearched, setTrackSearched] = useState(false);

  // Visual Search / Camera States
  const [isVisualSearchOpen, setIsVisualSearchOpen] = useState(false);
  const [vsScanning, setVsScanning] = useState(false);
  const [vsResult, setVsResult] = useState<string | null>(null);

  // Custom high-end Toast notification state
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
  };

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 4500);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Voice recording & playback simulation engine
  useEffect(() => {
    let interval: any;
    if (playingVoiceId) {
      interval = setInterval(() => {
        setVoicePlayProgress(prev => {
          const current = prev[playingVoiceId] || 0;
          if (current >= 100) {
            setPlayingVoiceId(null);
            clearInterval(interval);
            return { ...prev, [playingVoiceId]: 0 };
          }
          return { ...prev, [playingVoiceId]: current + 12 };
        });
      }, 350);
    }
    return () => clearInterval(interval);
  }, [playingVoiceId]);

  useEffect(() => {
    let interval: any;
    if (isRecordingVoice) {
      setRecordingSeconds(0);
      interval = setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    } else {
      setRecordingSeconds(0);
    }
    return () => clearInterval(interval);
  }, [isRecordingVoice]);

  useEffect(() => {
    fetchProducts();
    fetchSettings();
    if (adminToken) {
      fetchOrders();
      fetchAnalytics();
    }
    
    // Auto slide hero banner hourly rotation simulation
    const slideTimer = setInterval(() => {
      setHeroIndex(prev => (prev + 1) % heroSlides.length);
    }, 4500);
    return () => clearInterval(slideTimer);
  }, []);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages, isAiTyping, isChatOpen]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/products?_t=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        setProducts(data);
        localStorage.setItem("local_products", JSON.stringify(data));
      } else {
        throw new Error("HTTP error " + res.status);
      }
    } catch (err) {
      console.warn("Using offline local products fallback:", err);
      const guestProds = localStorage.getItem("local_products");
      if (guestProds) {
        setProducts(JSON.parse(guestProds));
      } else {
        setProducts(LOCAL_SEED_PRODUCTS);
        localStorage.setItem("local_products", JSON.stringify(LOCAL_SEED_PRODUCTS));
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchOrders = async () => {
    try {
      const res = await fetch(`/api/orders?_t=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
        localStorage.setItem("local_orders", JSON.stringify(data));
      } else {
        throw new Error("HTTP error " + res.status);
      }
    } catch (err) {
      console.warn("Using offline local orders fallback:", err);
      const guestOrders = localStorage.getItem("local_orders");
      setOrders(guestOrders ? JSON.parse(guestOrders) : []);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const res = await fetch(`/api/analytics?_t=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        setAnalytics(data);
        localStorage.setItem("local_analytics", JSON.stringify(data));
      } else {
        throw new Error("HTTP error " + res.status);
      }
    } catch (err) {
      console.warn("Using offline local analytics fallback:", err);
      const localProds = JSON.parse(localStorage.getItem("local_products") || "[]");
      const localOrds = JSON.parse(localStorage.getItem("local_orders") || "[]");
      
      const totalSales = localOrds
        .filter((o: any) => o.status === "Delivered")
        .reduce((sum: number, o: any) => sum + o.amount, 0);
      
      const pCount = localOrds.filter((o: any) => o.status === "Pending").length;
      const cCount = localOrds.filter((o: any) => o.status === "Confirmed").length;
      const sCount = localOrds.filter((o: any) => o.status === "Shipped").length;
      const dCount = localOrds.filter((o: any) => o.status === "Delivered").length;
      const stockOut = localProds.filter((p: any) => p.stock <= 0).length;
      const lowStock = localProds.filter((p: any) => p.stock > 0 && p.stock < 5).length;
      
      const fallbackAnalytics = {
        totalSales,
        pendingCount: pCount,
        confirmedCount: cCount,
        shippedCount: sCount,
        deliveredCount: dCount,
        stockOutCount: stockOut,
        lowStockCount: lowStock,
        categoryCount: localProds.reduce((acc: any, p: any) => {
          acc[p.category] = (acc[p.category] || 0) + 1;
          return acc;
        }, {})
      };
      setAnalytics(fallbackAnalytics);
    }
  };

  const fetchSettings = async () => {
    try {
      const res = await fetch(`/api/settings?_t=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        setShopSettings(data);
        localStorage.setItem("local_settings", JSON.stringify(data));
      } else {
        throw new Error("HTTP error " + res.status);
      }
    } catch (err) {
      console.warn("Using offline local settings fallback:", err);
      const guestSettings = localStorage.getItem("local_settings");
      setShopSettings(guestSettings ? JSON.parse(guestSettings) : DEFAULT_SETTINGS);
    }
  };

  const handleUpdateSettings = async (updated: typeof shopSettings) => {
    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated)
      });
      if (res.ok) {
        const data = await res.json();
        setShopSettings(data.settings);
        localStorage.setItem("local_settings", JSON.stringify(data.settings));
        showToast("সব তথ্য সফলভাবে আপডেট করা হয়েছে!", "success");
      } else {
        throw new Error("Failed server update");
      }
    } catch (err) {
      console.warn("Saving settings to localStorage offline:", err);
      setShopSettings(updated);
      localStorage.setItem("local_settings", JSON.stringify(updated));
      showToast("সব তথ্য সফলভাবে আপডেট করা হয়েছে (অফলাইন মোড)!", "success");
    }
  };

  // Handle Admin Login
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    
    const cleanedUser = (loginUsername || "").trim().toUpperCase();
    const cleanedPass = (loginPassword || "").trim();

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: cleanedUser, password: cleanedPass })
      });
      const data = await res.json();
      if (data.success) {
        localStorage.setItem("admin_token", data.token);
        setAdminToken(data.token);
        setIsAdminOpen(true);
        fetchOrders();
        fetchAnalytics();
      } else {
        setLoginError(data.message || "ভুল ইউজারনেম অথবা পাসওয়ার্ড দেওয়া হয়েছে। আবার চেষ্টা করুন।");
      }
    } catch (err) {
      console.warn("Checking admin password via client fallback:", err);
      if (cleanedUser === "ROBIUL HOSSEN" && cleanedPass === "As123456@") {
        const mockToken = "secure-admin-token-" + Date.now();
        localStorage.setItem("admin_token", mockToken);
        setAdminToken(mockToken);
        setIsAdminOpen(true);
        fetchOrders();
        fetchAnalytics();
        showToast("লগইন সফল হয়েছে (অফলাইন মোড)!", "success");
      } else {
        setLoginError("ভুল ইউজারনেম অথবা পাসওয়ার্ড দেওয়া হয়েছে। আবার চেষ্টা করুন।");
      }
    }
  };

  const handleAdminLogout = () => {
    localStorage.removeItem("admin_token");
    setAdminToken(null);
    setLoginUsername("");
    setLoginPassword("");
  };

  // Add / Edit Product (Admin Submit)
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const imgs = adminProdImages.filter(link => link.trim() !== "");
    const payload = {
      name: adminProdName,
      price: parseFloat(adminProdPrice),
      discountPrice: adminProdDiscPrice ? parseFloat(adminProdDiscPrice) : undefined,
      description: adminProdDesc,
      images: imgs.length > 0 ? imgs : ["https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=800"],
      stock: parseInt(adminProdStock) || 0,
      category: adminProdCategory,
      sizes: adminProdSizes
    };

    try {
      const url = adminProductMode === 'create' ? "/api/products" : `/api/products/${adminProductId}/update`;
      const method = "POST";
      
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      
      if (res.ok) {
        fetchProducts();
        fetchAnalytics();
        resetProductForm();
        showToast(adminProductMode === 'create' ? "Product Successfully Created!" : "Product Successfully Updated!", "success");
      } else {
        throw new Error("HTTP error " + res.status);
      }
    } catch (err) {
      console.warn("Using offline handleSaveProduct fallback:", err);
      const guestProdsStr = localStorage.getItem("local_products");
      let guestProds: Product[] = guestProdsStr ? JSON.parse(guestProdsStr) : LOCAL_SEED_PRODUCTS;
      
      if (adminProductMode === 'create') {
        const newProduct: Product = {
          ...payload,
          id: "prod-" + Date.now(),
          createdAt: new Date().toISOString()
        } as any;
        guestProds.unshift(newProduct);
      } else {
        guestProds = guestProds.map(p => {
          if (p.id === adminProductId) {
            return {
              ...p,
              ...payload,
              images: imgs.length > 0 ? imgs : p.images
            } as any;
          }
          return p;
        });
      }
      
      localStorage.setItem("local_products", JSON.stringify(guestProds));
      setProducts(guestProds);
      fetchAnalytics();
      resetProductForm();
      showToast(adminProductMode === 'create' ? "Product Successfully Created (Offline Mode)!" : "Product Successfully Updated (Offline Mode)!", "success");
    }
  };

  const resetProductForm = () => {
    setAdminProductMode('create');
    setAdminProductId("");
    setAdminProdName("");
    setAdminProdPrice("");
    setAdminProdDiscPrice("");
    setAdminProdDesc("");
    setAdminProdCategory("Men");
    setAdminProdStock("");
    setAdminProdImages(["", "", "", ""]);
    setAdminProdSizes(["M", "L", "XL"]);
  };

  const loadProductToEdit = (prod: Product) => {
    setAdminProductMode('edit');
    setAdminProductId(prod.id);
    setAdminProdName(prod.name);
    setAdminProdPrice(prod.price.toString());
    setAdminProdDiscPrice(prod.discountPrice ? prod.discountPrice.toString() : "");
    setAdminProdDesc(prod.description);
    setAdminProdCategory(prod.category);
    setAdminProdStock(prod.stock.toString());
    
    // Fill up to 4 image slots
    const imgs = [...prod.images];
    while (imgs.length < 4) imgs.push("");
    setAdminProdImages(imgs);
    setAdminProdSizes(prod.sizes);
  };

  const handleLocalImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files) as File[];
      const copy = [...adminProdImages];
      
      let changed = false;
      let slotIdx = 0;
      
      const readOne = (index: number) => {
        if (index >= files.length) {
          if (changed) {
            setAdminProdImages([...copy]);
          }
          return;
        }
        
        const file = files[index];
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            const base64Url = event.target.result as string;
            let targetIdx = copy.findIndex((img) => !img || img.trim() === "");
            if (targetIdx === -1) {
              targetIdx = slotIdx % 4;
              slotIdx++;
            }
            copy[targetIdx] = base64Url;
            changed = true;
          }
          readOne(index + 1);
        };
        reader.readAsDataURL(file);
      };
      
      readOne(0);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    try {
      const res = await fetch(`/api/products/${id}/delete`, { method: "POST" });
      if (res.ok) {
        setDeleteConfirmId(null);
        fetchProducts();
        fetchAnalytics();
      } else {
        throw new Error("HTTP error " + res.status);
      }
    } catch (err) {
      console.warn("Using offline handleDeleteProduct fallback:", err);
      const guestProdsStr = localStorage.getItem("local_products");
      if (guestProdsStr) {
        const guestProds = JSON.parse(guestProdsStr).filter((p: any) => p.id !== id);
        localStorage.setItem("local_products", JSON.stringify(guestProds));
        setProducts(guestProds);
      }
      setDeleteConfirmId(null);
      fetchAnalytics();
      showToast("পণ্যটি সফলভাবে মুছে ফেলা হয়েছে (অফলাইন মোড)!", "success");
    }
  };

  // Change Order Status (Admin action)
  const handleUpdateOrderStatus = async (id: string, newStatus: OrderStatus) => {
    try {
      const res = await fetch(`/api/orders/${id}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        fetchOrders();
        fetchAnalytics();
        setToast({ message: `অর্ডার ${id} সফলভাবে '${newStatus}' করা হয়েছে।`, type: 'success' });
      } else {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.message || "সার্ভার রেসপন্স ত্রুটিপূর্ণ ছিল");
      }
    } catch (err: any) {
      console.warn("Using offline handleUpdateOrderStatus fallback:", err);
      const guestOrdsStr = localStorage.getItem("local_orders");
      if (guestOrdsStr) {
        const updatedOrds = JSON.parse(guestOrdsStr).map((o: any) => {
          if (o.id === id) {
            return { ...o, status: newStatus };
          }
          return o;
        });
        localStorage.setItem("local_orders", JSON.stringify(updatedOrds));
        setOrders(updatedOrds);
        fetchAnalytics();
        setToast({ message: `অর্ডার ${id} সফলভাবে '${newStatus}' করা হয়েছে (অফলাইন মোড)।`, type: 'success' });
      } else {
        setToast({ message: `স্ট্যাটাস পরিবর্তন করা যায়নি: ${err.message || 'নেটওয়ার্ক সংযোগ পাননি'}`, type: 'error' });
      }
    }
  };

  // Delete Order (Admin action)
  const handleDeleteOrder = async (id: string) => {
    try {
      const res = await fetch(`/api/orders/${id}/delete`, {
        method: "POST"
      });
      if (res.ok) {
        setOrderDeleteConfirmId(null);
        fetchOrders();
        fetchAnalytics();
        setToast({ message: `অর্ডার ${id} সফলভাবে ডিলিট করা হয়েছে।`, type: 'success' });
      } else {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.message || "সার্ভার রেসপন্স ত্রুটিপূর্ণ ছিল");
      }
    } catch (err: any) {
      console.warn("Using offline handleDeleteOrder fallback:", err);
      const guestOrdsStr = localStorage.getItem("local_orders");
      if (guestOrdsStr) {
        const updatedOrds = JSON.parse(guestOrdsStr).filter((o: any) => o.id !== id);
        localStorage.setItem("local_orders", JSON.stringify(updatedOrds));
        setOrders(updatedOrds);
        fetchAnalytics();
        setOrderDeleteConfirmId(null);
        setToast({ message: `অর্ডার ${id} সফলভাবে ডিলিট করা হয়েছে (অফলাইন মোড)।`, type: 'success' });
      } else {
        setToast({ message: `অর্ডার মুছতে ব্যর্থ হয়েছে: ${err.message || 'নেটওয়ার্ক সংযোগ পাননি'}`, type: 'error' });
      }
    }
  };

  // Track customer order status
  const handleTrackOrder = async (searchQueryString: string) => {
    if (!searchQueryString.trim()) return;
    setTrackLoading(true);
    setTrackSearched(true);
    try {
      const res = await fetch(`/api/orders/track/${encodeURIComponent(searchQueryString.trim())}`);
      if (res.ok) {
        const data = await res.json();
        setUserTrackedOrders(data.orders || []);
      } else {
        throw new Error("HTTP error " + res.status);
      }
    } catch (err) {
      console.warn("Using offline handleTrackOrder fallback:", err);
      const guestOrdsStr = localStorage.getItem("local_orders");
      const guestOrds = guestOrdsStr ? JSON.parse(guestOrdsStr) : [];
      const trimmedQuery = searchQueryString.trim().toLowerCase();
      const matched = guestOrds.filter((o: any) => 
        o.id.toLowerCase().includes(trimmedQuery) || 
        o.phone.includes(trimmedQuery)
      );
      setUserTrackedOrders(matched);
    } finally {
      setTrackLoading(false);
    }
  };

  // Toggle Wishlist
  const toggleWishlist = (id: string) => {
    setWishlist(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  // Add to Cart helper
  const addToCart = (product: Product, size: SizeOption, qty: number = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id && item.size === size);
      if (existing) {
        return prev.map(item => 
          (item.product.id === product.id && item.size === size) 
            ? { ...item, quantity: item.quantity + qty } 
            : item
        );
      }
      return [...prev, { product, size, quantity: qty }];
    });
    // Trigger slide open cart automatically for interactive delight
    setIsCartOpen(true);
  };

  // Remove from cart
  const removeFromCart = (productId: string, size: SizeOption) => {
    setCart(prev => prev.filter(item => !(item.product.id === productId && item.size === size)));
  };

  // Sum up total cart price
  const getCartSubtotal = () => {
    return cart.reduce((sum, item) => {
      const price = item.product.discountPrice || item.product.price;
      return sum + (price * item.quantity);
    }, 0);
  };

  // Handle Checkout submission
  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkoutName || !checkoutPhone || !checkoutAddress) {
      showToast("Please fill in your primary details (Name, Phone Number, Delivery Address).", "error");
      return;
    }

    if (checkoutPayment !== "Cash on Delivery") {
      if (!checkoutTrxId) {
        showToast("অনুগ্রহ করে মোবাইল ব্যাংকিং ট্রানজেকশন আইডি (Transaction ID) প্রদান করুন।", "error");
        return;
      }
      
      const trx = checkoutTrxId.trim().toUpperCase();
      const hasLetter = /[A-Z]/.test(trx);
      const hasDigit = /[0-9]/.test(trx);
      const isAlphanumeric = /^[A-Z0-9]{8,14}$/.test(trx);
      const sequentialDigits = /0123|1234|2345|3456|4567|5678|6789/.test(trx);
      const repetitiveChars = /(.)\1{3,}/.test(trx); // e.g. "AAAA", "1111"
      const dummyKeywords = ["TEST", "FAKE", "NONE", "NULL", "EMPTY", "OKAY", "YES", "OK", "CORRECT", "PAYMENT", "BKASH", "NAGAD"];

      if (
        !isAlphanumeric || 
        !hasLetter || 
        !hasDigit || 
        sequentialDigits || 
        repetitiveChars || 
        dummyKeywords.includes(trx)
      ) {
        showToast("🚫 ভুল ট্রানজেকশন আইডি! বিকাশ/নগদ/রকেটের সঠিক ট্রানজেকশন আইডি সাধারণত ৮ থেকে ১৪ অক্ষরের হয়ে থাকে (যেমন BK32JD78A5)।", "error");
        return;
      }
    }

    setLoading(true);
    let successfulCount = 0;
    const placedOrderIds: string[] = [];

    for (const item of cart) {
      const finalPrice = item.product.discountPrice || item.product.price;
      const orderPayload = {
        userName: checkoutName,
        phone: checkoutPhone,
        address: checkoutAddress,
        productId: item.product.id,
        size: item.size,
        paymentMethod: checkoutPayment,
        transactionId: checkoutTrxId,
        amount: finalPrice * item.quantity
      };

      try {
        const res = await fetch("/api/orders", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(orderPayload)
        });
        if (res.ok) {
          successfulCount++;
          const data = await res.json();
          if (data && data.order && data.order.id) {
            placedOrderIds.push(data.order.id);
          }
        } else {
          throw new Error("HTTP error " + res.status);
        }
      } catch (err) {
        console.warn("Failed to place order line on server, using local storage fallback:", err);
        const guestOrdsStr = localStorage.getItem("local_orders");
        const guestOrds = guestOrdsStr ? JSON.parse(guestOrdsStr) : [];
        const localProduct = products.find(p => p.id === item.product.id) || item.product;
        
        const mockOrderId = "ORD-" + Math.floor(100000 + Math.random() * 900000);
        const localOrder = {
          id: mockOrderId,
          userName: checkoutName,
          phone: checkoutPhone,
          address: checkoutAddress,
          productId: item.product.id,
          productName: localProduct.name,
          size: item.size,
          paymentMethod: checkoutPayment,
          transactionId: checkoutTrxId,
          status: "Pending",
          amount: finalPrice * item.quantity,
          createdAt: new Date().toISOString()
        };
        
        guestOrds.unshift(localOrder);
        localStorage.setItem("local_orders", JSON.stringify(guestOrds));
        
        // Decrement stock locally too!
        const guestProdsStr = localStorage.getItem("local_products");
        if (guestProdsStr) {
          const guestProds = JSON.parse(guestProdsStr).map((p: any) => {
            if (p.id === item.product.id) {
              return { ...p, stock: Math.max(0, p.stock - item.quantity) };
            }
            return p;
          });
          localStorage.setItem("local_products", JSON.stringify(guestProds));
        }
        
        placedOrderIds.push(mockOrderId);
        successfulCount++;
        
        // Send Client-Side Telegram notification if configured and server is not responding!
        if (shopSettings.enableTelegramNotifications && shopSettings.telegramBotToken && shopSettings.telegramChatId) {
          try {
            const token = shopSettings.telegramBotToken.trim();
            const chatId = shopSettings.telegramChatId.trim();
            const text = `🛍️ *নতুন অর্ডার (অফলাইন মোড)*\n\n` +
              `🆔 অর্ডার আইডি: \`${mockOrderId}\`\n` +
              `👤 গ্রাহক: \`${checkoutName}\`\n` +
              `📞 মোবাইল: \`${checkoutPhone}\`\n` +
              `📍 ঠিকানা: \`${checkoutAddress}\`\n` +
              `👕 পণ্য: \`${localProduct.name}\` [Size: ${item.size}] (Qty: ${item.quantity})\n` +
              `💵 মূল্য: \`৳${(finalPrice * item.quantity).toLocaleString()} BDT\`\n` +
              `💳 পেমেন্ট: \`${checkoutPayment}\` (TrxID: \`${checkoutTrxId || 'N/A'}\`)\n\n` +
              `⚠️ এটি ক্লায়েন্ট-সাইড থেকে সরাসরি পাঠানো হয়েছে।`;
            
            fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                chat_id: chatId,
                text,
                parse_mode: "Markdown"
              })
            }).catch(e => console.error("Direct Telegram notify failed:", e));
          } catch (teleErr) {
            console.error("Direct Telegram notify error:", teleErr);
          }
        }
      }
    }

    setLoading(false);
    if (successfulCount > 0) {
      const orderIdsStr = placedOrderIds.join(", ");
      
      // Build dynamic WhatsApp message
      const itemsList = cart.map(item => {
        const pPrice = item.product.discountPrice || item.product.price;
        return `• ${item.product.name} [Size: ${item.size}] (${item.quantity}x) - ৳${(pPrice * item.quantity).toLocaleString()}`;
      }).join("\n");
      
      const totalPrice = cart.reduce((sum, item) => sum + ((item.product.discountPrice || item.product.price) * item.quantity), 0);
      const pm = checkoutPayment === "Cash on Delivery" 
        ? "Cash on Delivery (ক্যাশ অন ডেলিভারি)" 
        : `${checkoutPayment} (TrxID: ${checkoutTrxId})`;

      const waMsg = `আসসালামু আলাইকুম! Luxury Fashion BD তে একটি নতুন অর্ডার করা হয়েছে 🛍️✨\n\n` +
        `🆔 *অর্ডার ট্র্যাকিং কোড:* ${orderIdsStr || "N/A"}\n\n` +
        `👤 *কাস্টমারের নাম:* ${checkoutName}\n` +
        `📞 *মোবাইল নাম্বার:* ${checkoutPhone}\n` +
        `📍 *ডেলিভারি ঠিকানা:* ${checkoutAddress}\n\n` +
        `👕 *অর্ডারকৃত পণ্য তালিকা:*\n${itemsList}\n\n` +
        `💵 *সর্বমোট মূল্য:* ৳${totalPrice.toLocaleString()} BDT\n` +
        `💳 *পেমেন্ট পদ্ধতি:* ${pm}\n\n` +
        `অর্ডারটি নিশ্চিত করার জন্য অনুরোধ করা হলো। ধন্যবাদ! ❤️`;

      const encodedText = encodeURIComponent(waMsg);
      const cleansedNum = shopSettings.whatsAppNumber.replace(/[^0-9]/g, "");
      const waLink = `https://wa.me/${cleansedNum}?text=${encodedText}`;
      
      setLatestOrderWhatsAppLink(waLink);

      setCheckoutSuccessMessage(`বাংলদেশি ফ্যামিলিতে স্বাগতম! আপনার অর্ডারটি সফলভাবে দাখিল করা হয়েছে (পেন্ডিং স্ট্যাটাস)। আপনার অর্ডার ট্র্যাকিং আইডি কোড: ${orderIdsStr || "N/A"}। পেমেন্ট পদ্ধতি: ${checkoutPayment === "Cash on Delivery" ? "ক্যাশ অন ডেলিভারি" : checkoutPayment}। আমাদের এডমিন প্যানেল আপনার ট্রানজেকশন আইডি দ্রুত ভেরিফাই করে প্রসেস করবে। আমরা শীঘ্রই ${checkoutPhone} নাম্বারে যোগাযোগ করব।`);
      setCart([]);
      setIsCheckoutOpen(false);
      fetchProducts(); // refresh stock numbers
    } else {
      showToast("An unexpected issue occurred placing your order. Please try again.", "error");
    }
  };

  // Get active gateway payment number
  const getPaymentNumber = () => {
    if (checkoutPayment === "bKash") return shopSettings.bkashNumber || shopSettings.merchantPhone;
    if (checkoutPayment === "Nagad") return shopSettings.nagadNumber || shopSettings.merchantPhone;
    if (checkoutPayment === "Rocket") return shopSettings.rocketNumber || shopSettings.merchantPhone;
    if (checkoutPayment === "Upay") return shopSettings.upayNumber || shopSettings.merchantPhone;
    return shopSettings.merchantPhone;
  };

  // Copy support number
  const copyAccountToClipboard = () => {
    const num = getPaymentNumber();
    navigator.clipboard.writeText(num);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  // Trigger WhatsApp Chat directly
  const triggerWhatsApp = () => {
    const cleansedNum = shopSettings.whatsAppNumber.replace(/[^0-9]/g, "");
    window.open(`https://wa.me/${cleansedNum}`, "_blank");
  };

  // LazyChat AI Assist Call
  const handleSendChatMessage = async (e?: React.FormEvent, customMsg?: string, isVoiceSim?: boolean, attachedImg?: string) => {
    if (e) e.preventDefault();
    const finalInput = customMsg ? customMsg.trim() : chatInput.trim();
    if (!finalInput && !attachedImg) return;

    const userMsgText = finalInput;
    const userMsgId = "user-" + Date.now();
    const formattedTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newUserMsg: ChatMessage = {
      id: userMsgId,
      sender: "user",
      text: userMsgText || (attachedImg ? "📷 সংযুক্ত ছবি" : ""),
      timestamp: formattedTime,
      status: 'sent',
      voiceUrl: isVoiceSim ? "mock-user-voice" : undefined,
      voiceDuration: isVoiceSim ? `0:0${Math.floor(Math.random() * 5) + 4}` : undefined,
      imageUrl: attachedImg
    };

    setChatMessages(prev => [...prev, newUserMsg]);
    if (!customMsg) setChatInput("");
    setIsAiTyping(true);

    // Simulated progressive double-ticks of WhatsApp
    setTimeout(() => {
      setChatMessages(prev => prev.map(m => m.id === userMsgId ? { ...m, status: 'delivered' } : m));
    }, 600);

    try {
      const conversationHistory = chatMessages.map(m => ({
        sender: m.sender,
        text: m.text
      }));

      // Direct Order Tracking Query Handler inside custom conversational flow
      const lowerText = userMsgText.toLowerCase();
      if (lowerText.includes("track") || lowerText.includes("অর্ডার ট্র্যাক") || lowerText.includes("ট্র্যাক") || lowerText.includes("অর্ডার খুজ")) {
        setChatMessages(prev => prev.map(m => m.id === userMsgId ? { ...m, status: 'read' } : m));
        await new Promise(r => setTimeout(r, 1200));
        
        const trackerPromptMsg: ChatMessage = {
          id: "tracking-widget-ai-" + Date.now(),
          sender: "assistant",
          text: "আপনার অর্ডারটি লাইভ ট্র্যাক করতে নিচে অর্ডার ট্র্যাকিং আইডি (যেমন: ord-1845) অথবা বুকিং ফোন নাম্বারটি লিখুন:",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'read'
        };
        setChatMessages(prev => [...prev, trackerPromptMsg]);
        setIsAiTyping(false);
        return;
      }

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsgText,
          history: conversationHistory
        })
      });

      // Mark user message as read
      setChatMessages(prev => prev.map(m => m.id === userMsgId ? { ...m, status: 'read' } : m));

      if (res.ok) {
        const data = await res.json();
        const assistantMsg: ChatMessage = {
          id: "ai-" + Date.now(),
          sender: "assistant",
          text: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestedProducts: data.suggestedProducts,
          status: 'read'
        };

        // Attach luxury simulated voice messages to recommend products with royal accent
        if (data.suggestedProducts && data.suggestedProducts.length > 0 && Math.random() > 0.4) {
          assistantMsg.voiceUrl = "ai-recommend-voice";
          assistantMsg.voiceDuration = "0:15";
          assistantMsg.text = "আমি আপনার পছন্দের ক্যাটাগরির উপর ভিত্তি করে বিশেষ একটি ভয়েস স্টাইল গাইড নোট তৈরি করেছি। প্লে করে কাপড় ও সুতা কাজের বিবরণ শুনতে পারেন! এছাড়া নিচে সাজেস্টেড পোশাকগুলো সরাসরি অর্ডার করুন:";
        }

        setChatMessages(prev => [...prev, assistantMsg]);
      } else {
        throw new Error("Chat server error");
      }
    } catch (err) {
      console.warn("Using offline handleSendChatMessage fallback:", err);
      // Mark user ticks as read
      setChatMessages(prev => prev.map(m => m.id === userMsgId ? { ...m, status: 'read' } : m));
      
      let replyText = "ধন্যবাদ আপনার সুন্দর বার্তার জন্য। আমরা bKash/Nagad/Rocket পেমেন্ট ভেরিফাই করে খুব শীঘ্রই আপনার সাথে যোগাযোগ করছি।";
      const q = userMsgText.toLowerCase();
      let matchedProds: Product[] = [];
      const isPunjabiQuery = q.includes("পাঞ্জাবী") || q.includes("punjabi") || q.includes("men") || q.includes("ছেলে");
      const isSareeQuery = q.includes("শাড়ি") || q.includes("saree") || q.includes("লেহেঙ্গা") || q.includes("lehenga") || q.includes("women") || q.includes("মেয়ে");
      
      if (isPunjabiQuery) {
        replyText = "আসসালামু আলাইকুম! আমাদের রাজকীয় ডিজাইনের প্রিমিয়াম পাঞ্জাবী কালেকশন দেখতে পারেন। পাঞ্জাবীগুলো উন্নত কোয়ালিটির চন্দেরী সিল্ক সুতা দিয়ে নিখুঁত ঐতিহ্যবাহী হাতের কাজ সংবলিত।";
        matchedProds = products.filter(p => p.category === "Men");
      } else if (isSareeQuery) {
        replyText = "আসসালামু আলাইকুম! আমাদের এখানে বেনারসি কাতান শাড়ি এবং রাজকীয় ভেলভেটের ব্রাইডাল লেহেঙ্গা কালেকশন রয়েছে। উৎসবের দিনে আপনাকে করে তুলবে অত্যন্ত মার্জিত এবং রাজকীয়!";
        matchedProds = products.filter(p => p.category === "Women");
      } else if (q.includes("পেমেন্ট") || q.includes("বিকাশ") || q.includes("নগদ") || q.includes("payment")) {
        replyText = `আমাদের বিকাশ/নগদ/রকেট পেমেন্ট নাম্বার হলো: ${shopSettings.merchantPhone} । আপনি প্রিমিয়াম নাম্বারে পেমেন্ট করে শুধু ট্রানজেকশন আইডি দিয়ে অর্ডার কনফার্ম করতে পারেন।`;
      } else if (q.includes("ডেলিভারি") || q.includes("delivery") || q.includes("চার্জ")) {
        replyText = `আমরা ঢাকা সিটিতে ৬০ টাকা এবং ঢাকার বাইরে মাত্র ১০০ টাকা চার্জে হোম ডেলিভারি দিয়ে থাকি। সাধারণত ২-৩ দিনের মধ্যে আপনার ঠিকানায় পোশাক পৌঁছে যাবে।`;
      }
      
      const assistantMsg: ChatMessage = {
        id: "ai-fallback-" + Date.now(),
        sender: "assistant",
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedProducts: matchedProds.slice(0, 3),
        status: 'read'
      };

      if (isPunjabiQuery || isSareeQuery) {
        assistantMsg.voiceUrl = "ai-fallback-voice";
        assistantMsg.voiceDuration = "0:14";
      }

      setChatMessages(prev => [...prev, assistantMsg]);
    } finally {
      setIsAiTyping(false);
    }
  };

  // Filtered Products list
  const filteredProducts = products.filter(p => {
    const matchesTab = currentTab === 'All' || p.category === currentTab;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  if (currentTab === 'LazyChat') {
    return (
      <div className={`h-screen w-screen flex flex-col ${chatTheme === 'dark' ? 'bg-[#030a05] text-white' : 'bg-[#e5ddd5] text-neutral-850'} overflow-hidden relative font-sans transition-colors duration-300`} id="lazychat-fullscreen-vibe">
        
        {/* PREMIUM GOLD-CHROME NEON GLASSMORPHIC HEADER BAR */}
        <header className={`backdrop-blur-xl border-b ${chatTheme === 'dark' ? 'bg-neutral-950/90 border-emerald-900/40 shadow-[0_4px_30px_rgba(0,0,0,0.4)]' : 'bg-white/94 border-neutral-200 shadow-sm'} px-4 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between shrink-0 select-none z-30 transition-all`}>
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 sm:w-12 sm:h-12 rounded-full flex items-center justify-center font-serif font-black text-lg sm:text-2xl border ${chatTheme === 'dark' ? 'bg-emerald-950 text-yellow-400 border-yellow-500/25' : 'bg-neutral-100 text-emerald-950 border-emerald-950/20'} shadow-lg transform hover:scale-105 transition-all`}>
              L
            </div>
            <div>
              <h1 className="font-serif font-black text-xs sm:text-sm md:text-base uppercase tracking-tight leading-none flex items-center gap-1.5">
                <span className={chatTheme === 'dark' ? 'text-white' : 'text-neutral-900'}>L'Aura</span> 
                <span className={`text-[10px] border px-1.5 py-0.5 rounded-full font-bold font-sans ${chatTheme === 'dark' ? 'text-yellow-400 border-yellow-500/20 bg-yellow-500/5' : 'text-emerald-900 border-emerald-900/10 bg-emerald-50'}`}>AI PRO</span>
              </h1>
              <p className={`text-[9px] sm:text-[10px] font-medium tracking-wider uppercase mt-1 ${chatTheme === 'dark' ? 'text-neutral-400' : 'text-neutral-550'}`}>
                Premium Luxury Outfit Lounge
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-3">
            {/* LIGHT-DARK CHAT SWITCH */}
            <button
              onClick={() => setChatTheme(prev => prev === 'dark' ? 'light' : 'dark')}
              className={`p-2 rounded-xl border transition-all ${chatTheme === 'dark' ? 'bg-white/5 border-white/10 text-yellow-500 hover:bg-white/10' : 'bg-neutral-100 border-neutral-205 text-neutral-750 hover:bg-neutral-200'} cursor-pointer`}
              title="Toggle Light / Dark mode themes"
            >
              {chatTheme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-emerald-900" />}
            </button>

            {/* RETURN STORE BUTTON */}
            <button 
              onClick={() => {
                setCurrentTab('All');
                setSearchQuery("");
              }}
              className={`text-[10px] sm:text-xs font-bold px-3 py-2 rounded-xl transition-all border cursor-pointer flex items-center gap-1 shrink-0 ${
                chatTheme === 'dark' 
                  ? 'text-neutral-200 hover:text-yellow-450 hover:bg-white/10 border-white/10 bg-white/5' 
                  : 'text-neutral-800 hover:text-emerald-955 hover:bg-neutral-150 border-neutral-200 bg-neutral-100'
              }`}
              title="Return to store showroom gallery view"
            >
              ← দোকান গ্যালারী (Showroom)
            </button>

            {/* TRASH DISCARD BUTTON (RESETS CHAT) */}
            <button
              onClick={() => {
                if (confirm("আপনি কি চ্যাট হিস্ট্রি মুছে দিয়ে প্রথম থেকে শুরু করতে চান?")) {
                  setChatMessages([
                    {
                      id: "welcome-" + Date.now(),
                      sender: "assistant",
                      text: "আসসালামু আলাইকুম স্যার/ম্যাম! পুনরায় স্বাগতম। আমি আপনার পার্সোনাল স্টাইল কোঅর্ডিনেটর LazyChat AI। আজ আপনার জন্য পাঞ্জাবী, রাজকীয় শাড়ি নাকি ব্রাইডাল লেহেঙ্গা কী খুঁজবো?",
                      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                      status: 'read'
                    }
                  ]);
                  showToast("চ্যাট হিস্ট্রি রিসেট করা হয়েছে", 'info');
                }
              }}
              className={`p-2 rounded-xl border transition-all ${chatTheme === 'dark' ? 'bg-red-950/20 hover:bg-red-950/40 border-red-900/25 text-red-400' : 'bg-red-50 hover:bg-red-100 border-red-200 text-red-600'} cursor-pointer`}
              title="Reset configuration and clear workspace"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            {/* CART SHORTCUT IN THE CHATBAR */}
            <button 
              onClick={() => setIsCartOpen(true)}
              className={`relative p-2 rounded-xl border transition-all ${chatTheme === 'dark' ? 'bg-white/5 border-white/10 hover:bg-white/10' : 'bg-neutral-100 border-neutral-200 hover:bg-neutral-200'} cursor-pointer`}
              title="Shopping Bag"
            >
              <ShoppingBag className="w-4 h-4" />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-yellow-500 text-neutral-950 font-black text-[9px] w-4.5 h-4.5 rounded-full flex items-center justify-center shadow-md animate-bounce">
                  {cart.length}
                </span>
              )}
            </button>
          </div>
        </header>

        {/* FULL PAGE DUAL-COLUMN LAYOUT: BENTO SPLIT WINDOW */}
        <main className="flex-grow overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch relative">
          
          {/* LEFT BENTO RAIL COLUMN: DESIGN COUTURIER & QUICK PANEL */}
          <section className={`hidden lg:flex lg:col-span-4 p-6 sm:p-8 flex-col justify-between space-y-6 overflow-y-auto scrollbar-hidden border-r ${
            chatTheme === 'dark' 
              ? 'bg-[#021307]/90 border-emerald-900/40 text-[#c9dfcf]' 
              : 'bg-neutral-50 border-neutral-200 text-neutral-700'
          }`}>
            <div className="space-y-6">
              {/* Profile card of VIP Lounge */}
              <div className={`p-4 rounded-2xl border flex items-center gap-3.5 shadow-sm transform hover:scale-[1.01] transition-all duration-300 ${
                chatTheme === 'dark' ? 'bg-[#04210e]/70 border-[#1bf35e]/15' : 'bg-white border-neutral-200'
              }`}>
                <div className="relative">
                  <span className={`w-12 h-12 rounded-full flex items-center justify-center text-xl shadow-md border ${chatTheme === 'dark' ? 'bg-emerald-900 border-[#1bf35e]/20 text-yellow-400' : 'bg-neutral-100 border-emerald-900/10 text-emerald-950'}`}>
                    👑
                  </span>
                  <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-neutral-900 animate-pulse animate-repeat" />
                </div>
                <div>
                  <h3 className={`text-sm font-black font-serif tracking-wide ${chatTheme === 'dark' ? 'text-white' : 'text-neutral-900'}`}>
                    L'AURA COUTURE AI
                  </h3>
                  <p className="text-[10px] text-emerald-500 font-bold tracking-widest uppercase flex items-center gap-1.5">
                    ● রাজকীয় ফ্যাশন অ্যাসিস্ট্যান্ট
                  </p>
                </div>
              </div>

              {/* VIP Welcome intro box */}
              <div className="space-y-3">
                <h4 className={`text-[11px] font-black uppercase tracking-widest ${chatTheme === 'dark' ? 'text-yellow-400' : 'text-emerald-905'}`}>
                  আসসালামু আলাইকুম মেম্বার!
                </h4>
                <p className="text-xs leading-relaxed font-light">
                  L'Aura Premium AI লাউঞ্জে আপনাকে স্বাগতম। চন্দ্রি সুতা সিল্ক থ্রেড ওয়ার্ক পাঞ্জাবী, ঢাকাই জামদানি, হ্যান্ডলুম কাতান সিল্ক শাড়ি কিংবা ট্র্যাডিশনাল ব্যাগস কালেকশনের নিখুঁত সাইজ, কাপড়ের রিয়াল ছবি, ভিডিও কিংবা বিকাশ পেমেন্ট পদ্ধতি নিয়ে কনফিউজড? যেকোনো প্রশ্ন বাংলায় চ্যাট বক্সে লিখে আমাকে জানান। 
                </p>
              </div>

              {/* LIVE BUSINESS CONTACT SPECS */}
              <div className={`p-4 rounded-2xl border space-y-3.5 ${chatTheme === 'dark' ? 'bg-[#042010]/40 border-emerald-900/30' : 'bg-white border-neutral-200'}`}>
                <h5 className={`text-[10px] font-bold uppercase tracking-wider ${chatTheme === 'dark' ? 'text-yellow-405' : 'text-emerald-950'}`}>
                  💳 ইনস্ট্যান্ট বিকাশ/নগদ পেমেন্ট নাম্বারস:
                </h5>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className={`p-2.5 rounded-xl border flex flex-col justify-center ${chatTheme === 'dark' ? 'bg-neutral-900/40 border-emerald-900/20' : 'bg-neutral-50 border-neutral-150'}`}>
                    <span className="text-pink-600 font-extrabold font-sans">bKash (Personal)</span>
                    <strong className={`font-mono text-[12px] ${chatTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>{shopSettings.bkashNumber}</strong>
                  </div>
                  <div className={`p-2.5 rounded-xl border flex flex-col justify-center ${chatTheme === 'dark' ? 'bg-neutral-900/40 border-emerald-900/20' : 'bg-neutral-50 border-neutral-150'}`}>
                    <span className="text-orange-500 font-extrabold font-sans">Nagad (Personal)</span>
                    <strong className={`font-mono text-[12px] ${chatTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>{shopSettings.nagadNumber}</strong>
                  </div>
                </div>
                
                <div className="pt-2 border-t border-dashed border-neutral-700/20 text-[10px] space-y-1.5">
                  <p className="flex items-center gap-2">
                    <CheckCircle className={`w-3.5 h-3.5 shrink-0 ${chatTheme === 'dark' ? 'text-[#1bf35e]' : 'text-emerald-700'}`} />
                    <span>১০০% অথেন্টিক ঢাকাই তাঁতিদের সুতা কাজ</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <CheckCircle className={`w-3.5 h-3.5 shrink-0 ${chatTheme === 'dark' ? 'text-[#1bf35e]' : 'text-emerald-700'}`} />
                    <span>সারাদেশে ক্যাশ অন ডেলিভারি হোম সার্ভিস</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Bottom info disclaimer */}
            <div className={`pt-4 border-t ${chatTheme === 'dark' ? 'border-emerald-900/40' : 'border-neutral-200'} text-[9px] flex items-center justify-between`}>
              <span>L'AURA BD EXCLUSIVES v3.6</span>
              <span className="text-emerald-500 font-bold">SECURE ENCRYPTED 256-BIT</span>
            </div>
          </section>

          {/* RIGHT COL: AMAZING WHATSAPP-STYLE CHAT ENGINE FRAME */}
          <section className="col-span-1 lg:col-span-8 flex flex-col justify-between h-full overflow-hidden relative">
            
            {/* WHATSAPP wallpaper BACKGROUND CANVAS CONTAINER */}
            <div 
              className={`flex-grow overflow-y-auto p-4 sm:p-6 space-y-4 relative justify-between transition-colors duration-300 ${
                chatTheme === 'dark' 
                  ? 'bg-[#0f171e]' 
                  : 'bg-[#efeae2]'
              }`}
              style={{
                backgroundImage: chatTheme === 'dark' 
                  ? `radial-gradient(ellipse at center, rgba(16, 185, 129, 0.05) 0%, transparent 100%)`
                  : `url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')`,
                backgroundBlendMode: 'overlay'
              }}
            >
              
              {/* WhatsApp custom theme disclaimer banner */}
              <div className="flex justify-center select-none py-1 animate-fade-in relative z-10">
                <span className={`px-4 py-1 text-[9px] rounded-lg shadow-xs border font-medium ${
                  chatTheme === 'dark' 
                    ? 'bg-[#182229] border-neutral-800 text-[#8696a0]' 
                    : 'bg-[#ffeecf] border-yellow-200 text-neutral-700'
                }`}>
                  🔒 Messages and files are processed securely on L'Aura private servers.
                </span>
              </div>

              {/* CONVERSTATIONAL MESSAGES FLOW BUBBLE LIST */}
              <div className="space-y-4 max-w-4xl mx-auto pb-10">
                {chatMessages.map((msg) => {
                  const isUser = msg.sender === 'user';
                  const tickIndicator = msg.status === 'read' ? (
                    <span className="text-emerald-400 font-extrabold tracking-tighter" title="Message read">✓✓</span>
                  ) : msg.status === 'delivered' ? (
                    <span className="text-neutral-400 font-bold tracking-tighter" title="Message delivered">✓✓</span>
                  ) : (
                    <span className="text-neutral-400 font-light tracking-tighter" title="Sending">✓</span>
                  );

                  return (
                    <div 
                      key={msg.id} 
                      className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} group animate-fade-in`}
                    >
                      {/* Active profile logo if assistant */}
                      <div className="flex items-end gap-2.5 max-w-[85%] md:max-w-[70%]">
                        {!isUser && (
                          <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm shadow-md shrink-0 border ${
                            chatTheme === 'dark' ? 'bg-[#04210e] border-emerald-900/30' : 'bg-white border-neutral-200'
                          }`}>
                            🤖
                          </span>
                        )}

                        <div className={`shadow flex flex-col justify-between transition-all duration-150 ${
                          isUser 
                            ? chatTheme === 'dark'
                              ? 'bg-[#005c4b] text-white rounded-2xl rounded-tr-none border border-emerald-850/20'
                              : 'bg-[#d9fdd3] text-[#111b21] rounded-2xl rounded-tr-none border border-green-200/40'
                            : chatTheme === 'dark'
                              ? 'bg-[#202c33] text-[#e9edef] rounded-2xl rounded-tl-none border border-neutral-800'
                              : 'bg-white text-[#111b21] rounded-2xl rounded-tl-none border border-neutral-200'
                        }`}>
                          
                          {/* Photo attachment representation */}
                          {msg.imageUrl && (
                            <div className="p-1 px-1.5 pt-1.5 select-none shrink-0 rounded-t-2xl overflow-hidden aspect-video bg-black/10">
                              <img src={msg.imageUrl} referrerPolicy="no-referrer" alt="Attached preview" className="w-full max-h-48 object-cover rounded-xl" />
                            </div>
                          )}

                          {/* TEXT & VOICE NOTES CONTAINER BODY */}
                          <div className="p-3 sm:p-4 pb-1">
                            {!msg.voiceUrl ? (
                              <p className="whitespace-pre-line text-xs sm:text-sm font-light leading-relaxed tracking-wide select-text">
                                {msg.text}
                              </p>
                            ) : (
                              /* SPECTACULAR WHATSAPP VOICE NOTE MESSAGE ASSISTANT COMPARTMENT */
                              <div className="space-y-2">
                                <p className="text-xs text-neutral-400 leading-tight mb-2 italic">
                                  {msg.text}
                                </p>
                                
                                <div className="flex items-center gap-3 py-1">
                                  <button
                                    onClick={() => {
                                      if (playingVoiceId === msg.id) {
                                        setPlayingVoiceId(null);
                                      } else {
                                        setPlayingVoiceId(msg.id);
                                        setVoicePlayProgress(prev => ({ ...prev, [msg.id]: 0 }));
                                      }
                                    }}
                                    className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 shadow transition transform hover:scale-105 active:scale-95 cursor-pointer ${
                                      chatTheme === 'dark' 
                                        ? 'bg-[#005c4b] text-white hover:bg-[#006e5a]' 
                                        : 'bg-[#e2f9ec] text-[#005c4b] hover:bg-neutral-200'
                                    }`}
                                    title="Play simulated voice narration guiding premium"
                                  >
                                    {playingVoiceId === msg.id ? (
                                      <span className="w-3 h-3 flex gap-0.5 justify-center items-center">
                                        <span className="w-1 h-3.5 bg-white rounded-full animate-pulse"></span>
                                        <span className="w-1 h-3.5 bg-white rounded-full animate-pulse [animation-delay:0.2s]"></span>
                                      </span>
                                    ) : (
                                      <Play className="w-4 h-4 fill-current ml-0.5" />
                                    )}
                                  </button>

                                  <div className="flex-1 space-y-1 min-w-[130px] sm:min-w-[170px]">
                                    {/* Simulated audio waveforms bars animation representation */}
                                    <div className="flex items-end gap-[2px] h-6 overflow-hidden max-w-full relative justify-start">
                                      {Array.from({ length: 28 }).map((_, waveIdx) => {
                                        const progressFilled = (voicePlayProgress[msg.id] || 0) > (waveIdx / 28) * 100;
                                        const waveHeight = 2 + (waveIdx % 5) * 4 + (Math.sin(waveIdx * 0.4) * 3);
                                        return (
                                          <span 
                                            key={waveIdx} 
                                            style={{ height: `${Math.max(3, waveHeight)}px` }}
                                            className={`w-[3px] rounded-full transition-colors duration-200 ${
                                              progressFilled 
                                                ? chatTheme === 'dark' ? 'bg-[#1bf35e]' : 'bg-[#005c4b]' 
                                                : chatTheme === 'dark' ? 'bg-neutral-600' : 'bg-neutral-300'
                                            } ${playingVoiceId === msg.id ? 'animate-pulse' : ''}`}
                                          />
                                        );
                                      })}
                                    </div>
                                    
                                    <div className="flex justify-between items-center text-[9px] text-[#8696a0]">
                                      <span>
                                        {playingVoiceId === msg.id 
                                          ? `0:0${Math.min(9, Math.round(((voicePlayProgress[msg.id] || 0) / 100) * 15))}`
                                          : `0:00`
                                        } / {msg.voiceDuration}
                                      </span>
                                      <Mic className={`w-3 h-3 ${chatTheme === 'dark' ? 'text-emerald-400' : 'text-emerald-700'}`} />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}

                            {/* CUSTOM CONVERSATIONAL INTEGRATED LIVE ORDER TRACKER IN SCREEN */}
                            {msg.id.startsWith("tracking-widget-ai") && (
                              <div className="mt-4 pt-3 text-left select-none max-w-sm">
                                <ChatMessageInteractiveTracker 
                                  shopSettings={shopSettings} 
                                  chatTheme={chatTheme}
                                  showToast={showToast}
                                />
                              </div>
                            )}

                          </div>

                          {/* RECOMENDED PRODUCTS INTERNAL SHOWN TILES */}
                          {msg.suggestedProducts && msg.suggestedProducts.length > 0 && (
                            <div className={`p-3 pt-3.5 border-t bg-black/5 flex flex-col space-y-3 rounded-b-2xl max-w-full overflow-hidden ${
                              chatTheme === 'dark' ? 'border-neutral-800' : 'border-neutral-200'
                            }`}>
                              <p className={`text-[10px] uppercase font-bold tracking-wider flex items-center gap-1.5 ${chatTheme === 'dark' ? 'text-yellow-400' : 'text-emerald-950'}`}>
                                <Sparkles className="w-3.5 h-3.5 text-yellow-500 animate-bounce" /> রাজকীয় সিলেকশন (Recommended Outfits):
                              </p>
                              
                              <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-style shrink-0 scroll-smooth max-w-full">
                                {msg.suggestedProducts.map((sp) => (
                                  <div 
                                    key={sp.id} 
                                    className={`w-[13rem] shrink-0 border rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between transform hover:translate-y-[-2px] transition duration-200 text-left ${
                                      chatTheme === 'dark' ? 'bg-[#182229] border-neutral-800' : 'bg-white border-neutral-200'
                                    }`}
                                  >
                                    <div className="relative aspect-video overflow-hidden bg-neutral-900 shrink-0">
                                      <img src={sp.images[0]} referrerPolicy="no-referrer" className="w-full h-full object-cover" alt={sp.name} />
                                      {sp.discountPrice && (
                                        <span className="absolute top-2 left-2 bg-red-650 text-white text-[8px] font-bold px-1.5 py-0.5 rounded shadow z-10">BESTSELL</span>
                                      )}
                                    </div>
                                    
                                    <div className="p-2.5 flex-grow flex flex-col justify-between">
                                      <div>
                                        <h4 className={`text-[11px] font-serif font-black line-clamp-1 leading-tight ${chatTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>{sp.name}</h4>
                                        <p className="text-[10px] text-neutral-400 mt-0.5 italic">{sp.category} Couture</p>
                                      </div>
                                      
                                      <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-neutral-800/10">
                                        <div className="flex flex-col">
                                          {sp.discountPrice ? (
                                            <>
                                              <span className="text-[12px] font-black text-emerald-500">৳{sp.discountPrice.toLocaleString()}</span>
                                              <span className="text-[8px] text-neutral-400 line-through">৳{sp.price.toLocaleString()}</span>
                                            </>
                                          ) : (
                                            <span className={`text-[12px] font-black ${chatTheme === 'dark' ? 'text-white' : 'text-emerald-950'}`}>৳{sp.price.toLocaleString()}</span>
                                          )}
                                        </div>
                                        
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            addToCart(sp, sp.sizes[0] || "M");
                                            showToast(`${sp.name} কাটে যোগ করা হয়েছে!`, "success");
                                          }}
                                          className="p-1 px-2.5 bg-emerald-900 hover:bg-emerald-850 font-black text-[9px] font-sans text-white rounded-lg flex items-center transition cursor-pointer"
                                          title="Add this tailored suite to your order list"
                                        >
                                          কিনুন
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* BOTTOM TIMESTAMP AND FLAGS */}
                          <div className="flex items-center justify-end px-3 py-1 select-none gap-1 self-end">
                            <span className="text-[9px] text-[#8696a0] font-sans tracking-tight">{msg.timestamp}</span>
                            {isUser && tickIndicator}
                          </div>

                        </div>
                      </div>
                    </div>
                  );
                })}

                {/* Simulated AI typing indicator */}
                {isAiTyping && (
                  <div className="flex items-end gap-2.5 animate-pulse max-w-[80%] select-none">
                    <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm shadow-md shrink-0 border ${
                      chatTheme === 'dark' ? 'bg-[#04210e] border-emerald-900/30' : 'bg-white border-neutral-200'
                    }`}>
                      🤖
                    </span>
                    <div className={`p-4 rounded-2xl rounded-tl-none flex items-center gap-2 border shadow-sm ${
                      chatTheme === 'dark' ? 'bg-[#202c33] border-neutral-800' : 'bg-white border-neutral-150'
                    }`}>
                      <span className="w-2 h-2 bg-emerald-555 rounded-full animate-bounce"></span>
                      <span className="w-2 h-2 bg-emerald-555 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                      <span className="w-2 h-2 bg-emerald-555 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                      <span className="text-xs text-neutral-400 pl-1">স্টাইলিস্ট টাইপ করছে...</span>
                    </div>
                  </div>
                )}
                
                <div ref={chatEndRef} />
              </div>

            </div>

            {/* FLOATING ACTION SUGGESTED FAQ CUES BAR */}
            <section className={`px-4 py-2 border-t overflow-x-auto shrink-0 flex items-center gap-1.5 scrollbar-hidden ${
              chatTheme === 'dark' ? 'bg-[#1f2c34]/75 border-emerald-900/40' : 'bg-neutral-100/90 border-neutral-200'
            }`}>
              <div className="max-w-4xl mx-auto flex gap-2 w-full select-none justify-start items-center shrink-0 min-w-max">
                <span className={`text-[10px] font-extrabold uppercase mr-1 flex items-center gap-1 ${chatTheme === 'dark' ? 'text-yellow-400' : 'text-emerald-950'}`}>
                  ⭐ দ্রুত নির্দেশ:
                </span>
                {[
                  { text: "আসসালামু আলাইকুম! পুরুষদের স্টাইলিশ পাঞ্জাবী স্টক দেখাও।", key: "🕺 পাঞ্জাবী স্টক" },
                  { text: "উৎসবের জন্য ব্রাইডাল সিল্ক কাতান শাড়ি ও জামদানি কালেকশন দেখান।", key: "👗 শাড়ি কালেকশন" },
                  { text: "ঢাকা সিটি এবং ঢাকার বাইরে পণ্যের হোম ডেলিভারি চার্জ কত?", key: "🚚 ডেলিভারি চার্জ" },
                  { text: "বিকাশ ও নগদে পেমেন্ট করার নিয়ম কি?", key: "💳 পেমেন্ট নিয়ম" },
                  { text: "আমার অর্ডার ট্র্যাক করতে চাই।", key: "📦 আমার অর্ডার ট্রাক" }
                ].map((tag, tIdx) => (
                  <button
                    key={tIdx}
                    onClick={() => handleSendChatMessage(undefined, tag.text)}
                    className={`px-3 py-1.5 rounded-full text-[11px] font-bold border transition-all hover:scale-[1.01] active:scale-[0.98] cursor-pointer flex items-center truncate ${
                      chatTheme === 'dark' 
                        ? 'bg-[#2a3942] hover:bg-[#374248] text-white/90 border-neutral-700/50' 
                        : 'bg-white hover:bg-neutral-200 text-neutral-850 border-neutral-250 shadow-xs'
                    }`}
                  >
                    {tag.key}
                  </button>
                ))}
              </div>
            </section>

            {/* MASTER INPUT MESSAGE SENDER CONSOLE FRAME */}
            <footer className={`p-3.5 sm:p-4.5 border-t shrink-0 flex justify-between select-none ${
              chatTheme === 'dark' ? 'bg-[#101d25] border-emerald-900/40' : 'bg-white border-neutral-200'
            }`}>
              <div className="max-w-4xl mx-auto flex gap-2 w-full items-center relative">
                
                {/* ATTACHMENT MOCK GARMENT PAPERCLIP */}
                <button
                  type="button"
                  onClick={() => {
                    const samples = [
                      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=800",
                      "https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?auto=format&fit=crop&q=80&w=800",
                      "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&q=80&w=800"
                    ];
                    const selectedImg = samples[Math.floor(Math.random() * samples.length)];
                    handleSendChatMessage(undefined, "ডিজাইনার পাঞ্জাবির এই রেশমি কাজের ছবি রেফারেন্স দিলাম। আপনাদের তাঁতিরা কি এমন নকশাকাটা কাজ দিতে পারবে?", false, selectedImg);
                    showToast("📷 রেফারেন্স ছবি সংযুক্ত করে পাঠানো হয়েছে!", "success");
                  }}
                  className={`p-3 rounded-xl border transition-all transform active:scale-95 cursor-pointer ${
                    chatTheme === 'dark' ? 'bg-[#2a3942] border-neutral-700 text-neutral-350 hover:text-white' : 'bg-neutral-100 border-neutral-200 text-neutral-600 hover:bg-neutral-200'
                  }`}
                  title="Attach luxury apparel sample reference photo"
                >
                  <Paperclip className="w-4.5 h-4.5" />
                </button>

                {/* PRIMARY CHAT INPUT EXPANSION */}
                <form 
                  onSubmit={handleSendChatMessage} 
                  className="flex-grow flex gap-2 items-center"
                >
                  <input 
                    type="text" 
                    placeholder={isRecordingVoice ? `🔴 ভয়েস রেকর্ড হচ্ছে: 0:${recordingSeconds < 10 ? '0' + recordingSeconds : recordingSeconds}... ট্যাপ করে বন্ধ করুন` : "মোবাইল নম্বর লিখুন বা আপনার পছন্দের কাপড়ের নকশা নিয়ে জিজ্ঞেস করুন..."}
                    value={chatInput}
                    disabled={isRecordingVoice}
                    onChange={(e) => setChatInput(e.target.value)}
                    className={`flex-grow px-4 sm:px-5 py-3 text-xs sm:text-sm rounded-xl border focus:outline-none transition-all shadow-inner ${
                      chatTheme === 'dark' 
                        ? 'border-neutral-800 bg-[#2a3942] text-white focus:bg-[#374248] focus:ring-1 focus:ring-emerald-700' 
                        : 'border-neutral-200 bg-neutral-50 text-[#111b21] focus:bg-white focus:ring-1 focus:ring-emerald-900/50'
                    } ${isRecordingVoice ? 'text-red-500 placeholder-red-500 font-bold bg-red-950/10' : ''}`}
                  />
                  
                  {/* MAIN SEND FORM OVERLAY */}
                  {!isRecordingVoice && (chatInput.trim() || isAiTyping) ? (
                    <button 
                      type="submit"
                      className="bg-emerald-800 hover:bg-emerald-750 active:scale-95 text-white p-3.5 rounded-xl shadow-lg transition-transform shrink-0 cursor-pointer"
                      title="Send your dress inquiry"
                    >
                      <Send className="w-4.5 h-4.5 text-white" />
                    </button>
                  ) : null}
                </form>

                {/* VOICE MICROPHONE RECORDING ACTIONS TOGGLE */}
                <button
                  type="button"
                  onClick={() => {
                    if (isRecordingVoice) {
                      setIsRecordingVoice(false);
                      handleSendChatMessage(undefined, "আসসালামু আলাইকুম! রেশমি কাতান শাড়ির কাস্টমাইজেশন নিয়ে একটি জরুরি অডিও প্রশ্ন পাঠালাম।", true);
                      showToast("🎤 ভয়েস নোটটি পাঠানো হয়েছে!", "success");
                    } else {
                      setIsRecordingVoice(true);
                      showToast("🎤 ভয়েস পোস্টিং স্টার্ট হয়েছে। আপনার প্রশ্ন বলুন...", "info");
                    }
                  }}
                  className={`p-3 rounded-xl border transition-all duration-200 transform active:scale-95 cursor-pointer ${
                    isRecordingVoice 
                      ? 'bg-red-600 border-red-500 text-white animate-pulse' 
                      : chatTheme === 'dark'
                        ? 'bg-[#2a3942] border-neutral-700 text-neutral-300 hover:text-white'
                        : 'bg-neutral-100 border-neutral-200 text-neutral-600 hover:bg-neutral-200'
                  }`}
                  title={isRecordingVoice ? "Press to send recorded voice request" : "Hold or click to record simulated voice note inquiry"}
                >
                  <Mic className="w-4.5 h-4.5" />
                </button>

              </div>
            </footer>

          </section>

        </main>

        {/* --- DYNAMIC INTERACTIVE FLOATING PANELS FOR DIALOGS AND ACTIONS --- */}
        {selectedProduct && (
          <div id="product-details-modal" className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none">
            <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fade-in relative text-neutral-800 border border-neutral-200">
              <button 
                onClick={() => setSelectedProduct(null)}
                className="absolute right-4 top-4 p-2 rounded-full bg-neutral-100 hover:bg-neutral-202 text-neutral-600 transition z-20 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 md:p-8">
                <div className="space-y-4">
                  <div className="bg-neutral-50 rounded-2xl p-2 border border-neutral-200">
                    <ProductImageGallery images={selectedProduct.images} name={selectedProduct.name} />
                  </div>
                  <div className="bg-emerald-50 rounded-xl p-3 text-center border border-emerald-900/5">
                    <p className="text-[10px] text-emerald-900 uppercase font-extrabold tracking-wider">🌟 Handloom authentic material assurance • 100% Cotton Velvet thread work</p>
                  </div>
                </div>
                <div className="flex flex-col justify-between">
                  <div>
                    <span className="text-xs bg-emerald-105 text-emerald-900 px-3 py-1 rounded inline-block font-extrabold uppercase tracking-widest mb-2">{selectedProduct.category}</span>
                    <h2 className="font-serif font-bold text-2xl text-neutral-900 mb-2 leading-tight">{selectedProduct.name}</h2>
                    <div className="flex items-center gap-2 text-xs mb-4">
                      {selectedProduct.stock > 0 ? (
                        <span className="text-emerald-700 font-semibold">● IN STOCK ({selectedProduct.stock} items remaining)</span>
                      ) : (
                        <span className="text-red-650 font-bold">● TEMPORARILY OUT OF STOCK</span>
                      )}
                    </div>
                    
                    <div className="flex items-baseline gap-3 mb-6 bg-neutral-50 p-3 rounded-2xl border border-neutral-100">
                      {selectedProduct.discountPrice ? (
                        <>
                          <span className="text-2xl font-black text-emerald-950">৳{selectedProduct.discountPrice.toLocaleString()}</span>
                          <span className="text-sm text-neutral-400 line-through">৳{selectedProduct.price.toLocaleString()}</span>
                          <span className="text-xs bg-red-100 text-red-600 font-bold px-2 py-0.5 rounded ml-auto">SAVE ৳{(selectedProduct.price - selectedProduct.discountPrice).toLocaleString()}</span>
                        </>
                      ) : (
                        <span className="text-2xl font-black text-emerald-950">৳{selectedProduct.price.toLocaleString()}</span>
                      )}
                    </div>

                    <div className="space-y-2 mb-6">
                      <p className="text-xs font-semibold text-neutral-600">Tailored Size Reference Option:</p>
                      <div className="flex gap-2">
                        {selectedProduct.sizes.map((s) => (
                          <button 
                            key={s} 
                            className="w-10 h-10 border rounded-lg text-xs font-bold hover:bg-emerald-900 hover:text-white transition flex items-center justify-center cursor-pointer border-neutral-200"
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>

                    <p className="text-neutral-655 text-sm leading-relaxed mb-6 font-light">
                      {selectedProduct.description}
                    </p>
                  </div>

                  <button
                    disabled={selectedProduct.stock === 0}
                    onClick={() => {
                      addToCart(selectedProduct, selectedProduct.sizes[0] || "M");
                      showToast(`${selectedProduct.name} added to cart!`, "success");
                    }}
                    className="w-full bg-emerald-950 hover:bg-emerald-900 text-white font-extrabold py-3.5 rounded-xl uppercase tracking-wider text-xs transition cursor-pointer flex items-center justify-center gap-2"
                  >
                    শপিং ব্যাগে যোগ করুন (Add to Bag)
                  </button>
                </div>
              </div>
            </div>
          </div>
        )

        /* Dynamic order tracking modal */}
        {isTrackModalOpen && (
          <div id="track-order-modal-backdrop" className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg p-5 max-w-lg w-full text-neutral-800 relative">
              <button onClick={() => setIsTrackModalOpen(false)} className="absolute right-3 top-3 text-neutral-400 hover:text-red-500 cursor-pointer"><X className="w-4 h-4" /></button>
              <h3 className="font-serif font-bold text-lg mb-3">আপনার অর্ডার ট্র্যাক করুন</h3>
              <div className="flex gap-2">
                <input type="text" placeholder="মোবাইল নাম্বার দিন" value={userOrderTrackQuery} onChange={(e) => setUserOrderTrackQuery(e.target.value)} className="flex-1 p-2 border rounded text-xs text-neutral-900" />
                <button onClick={() => handleTrackOrder(userOrderTrackQuery)} className="bg-emerald-900 text-white px-3 font-bold rounded text-xs cursor-pointer font-sans">খুঁজুন</button>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic premium visual toast notifier */}
        {toast && (
          <div className="fixed bottom-6 left-6 z-50 bg-[#051c0d] border border-yellow-500/20 text-yellow-300 text-xs font-bold px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 animate-fade-in select-none">
            <Sparkles className="w-4 h-4 text-yellow-400 animate-pulse" />
            <span>{toast.message}</span>
          </div>
        )}

        {isCartOpen && (
          <div id="quick-cart-sidebar-backdrop" className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex justify-end">
            <div className="bg-neutral-900 border-l border-emerald-900/30 text-white w-full max-w-md h-full flex flex-col shadow-2xl animate-slide-in-right">
              <div className="p-4 border-b border-white/10 flex items-center justify-between bg-emerald-950">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-6 h-6 text-yellow-500" />
                  <h3 className="font-serif font-bold text-lg">আপনার শপিং ব্যাগ</h3>
                </div>
                <button onClick={() => setIsCartOpen(false)} className="p-1 px-2 hover:bg-white/10 rounded text-neutral-300"><X className="w-5 h-5" /></button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {cart.length === 0 ? (
                  <div className="text-center py-20 text-neutral-400">
                    <ShoppingBag className="w-12 h-12 text-neutral-200 mx-auto mb-3" />
                    <p className="font-serif text-neutral-600 mb-1">আপনার ব্যাগটি খালি রয়েছে</p>
                  </div>
                ) : (
                  cart.map((item, index) => {
                    const finalPrice = item.product.discountPrice || item.product.price;
                    return (
                      <div key={index} className="flex gap-3 p-3 rounded-lg border border-neutral-100 relative group bg-neutral-50/50">
                        <img src={item.product.images[0]} referrerPolicy="no-referrer" alt={item.product.name} className="w-16 h-16 object-cover rounded bg-neutral-100" />
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-bold text-neutral-900 truncate">{item.product.name}</h4>
                          <p className="text-[10px] text-emerald-850 font-black">SIZE: {item.size}</p>
                          <div className="flex items-center justify-between mt-2">
                            <span className="text-xs text-neutral-550">Qty: {item.quantity}</span>
                            <span className="text-xs font-bold text-emerald-900">৳{(finalPrice * item.quantity).toLocaleString()}</span>
                          </div>
                        </div>
                        <button onClick={() => removeFromCart(item.product.id, item.size)} className="absolute top-2 right-2 p-1 text-neutral-400 hover:text-red-650 opacity-0 group-hover:opacity-100 transition"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    );
                  })
                )}
              </div>
              <div className="p-4 border-t border-neutral-100 bg-neutral-50 space-y-3">
                <div className="flex justify-between items-center text-sm font-semibold text-neutral-900">
                  <span>Subtotal:</span>
                  <span className="text-lg font-black text-emerald-950">৳{getCartSubtotal().toLocaleString()}</span>
                </div>
                <button
                  disabled={cart.length === 0}
                  onClick={() => {
                    setIsCartOpen(false);
                    setIsCheckoutOpen(true);
                  }}
                  className="w-full bg-emerald-900 hover:bg-emerald-850 disabled:bg-neutral-300 text-white text-xs font-bold py-3.5 rounded tracking-widest uppercase transition"
                >
                  PROCEED TO CHECKOUT ৳{getCartSubtotal().toLocaleString()}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Global checkout modal overlay */}
        {isCheckoutOpen && (
          <div id="checkout-modal" className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-white rounded-lg max-w-2xl w-full shadow-2xl p-6 md:p-8 relative max-h-[90vh] overflow-y-auto my-10 border border-emerald-900/10 text-neutral-800">
              <button onClick={() => setIsCheckoutOpen(false)} className="absolute right-4 top-4 p-2 rounded-full bg-neutral-100 hover:bg-neutral-250"><X className="w-5 h-5" /></button>
              <h3 className="font-serif font-bold text-2xl text-emerald-950 border-b pb-4 mb-6">প্রিমিয়াম পেমেন্ট ও ডেলিভারি তথ্য</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold uppercase text-neutral-600 block mb-1">আপনার নাম (Full Name) *</label>
                  <input type="text" value={checkoutName} onChange={(e) => setCheckoutName(e.target.value)} className="w-full p-2.5 rounded border border-neutral-250 text-xs" required />
                </div>
                <div>
                  <label className="text-xs font-bold uppercase text-neutral-600 block mb-1">ফোন নাম্বার (Phone Number) *</label>
                  <input type="text" value={checkoutPhone} onChange={(e) => setCheckoutPhone(e.target.value)} className="w-full p-2.5 rounded border border-neutral-250 text-xs" required />
                </div>
                <div>
                  <label className="text-xs font-bold uppercase text-neutral-600 block mb-1">শিপিং ঠিকানা (Shipping Address) *</label>
                  <textarea value={checkoutAddress} onChange={(e) => setCheckoutAddress(e.target.value)} className="w-full p-2.5 rounded border border-neutral-250 text-xs h-16" required />
                </div>
                <div className="bg-emerald-50 border border-emerald-950/5 p-4 rounded-lg">
                  <span className="text-xs font-extrabold uppercase text-emerald-950 block mb-2">ম্যানুয়াল পেমেন্ট গেটওয়ে (বিকাশ / নগদ)</span>
                  <div className="space-y-1.5 text-xs text-neutral-700">
                    <p>১. পেমেন্ট নাম্বার: <strong className="font-mono text-emerald-900">{shopSettings.merchantPhone}</strong> (বিকাশ/নগদ পার্সোনাল)</p>
                    <p>২. মোট পরিশোধযোগ্য পরিমাণ: <strong>৳{(getCartSubtotal() + 100).toLocaleString()}</strong> (৳১০০ ডেলিভারি সহ)</p>
                    <p>৩. টাকা পাঠিয়ে নিচের ঘরে ট্রান্সজেকশন আইডি দিন:</p>
                  </div>
                  <input type="text" placeholder="TrxID (যেমন: K7D5M92X)" value={checkoutTrxId} onChange={(e) => setCheckoutTrxId(e.target.value)} className="w-full p-2 rounded border border-neutral-200 text-xs mt-3 bg-white" />
                </div>
                <button onClick={(e) => handlePlaceOrder(e)} className="w-full bg-emerald-900 hover:bg-emerald-850 text-white font-bold py-3.5 rounded text-xs uppercase transition mt-4">অর্ডার নিশ্চিত করুন (Confirm Order)</button>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic order tracking modal */}
        {isTrackModalOpen && (
          <div id="track-order-modal-backdrop" className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg p-5 max-w-lg w-full text-neutral-800 relative">
              <button onClick={() => setIsTrackModalOpen(false)} className="absolute right-3 top-3 text-neutral-400 hover:text-red-500"><X className="w-4 h-4" /></button>
              <h3 className="font-serif font-bold text-lg mb-3">আপনার অর্ডার ট্র্যাক করুন</h3>
              <div className="flex gap-2">
                <input type="text" placeholder="মোবাইল নাম্বার দিন" value={userOrderTrackQuery} onChange={(e) => setUserOrderTrackQuery(e.target.value)} className="flex-1 p-2 border rounded text-xs" />
                <button onClick={() => handleTrackOrder(userOrderTrackQuery)} className="bg-emerald-900 text-white px-3 font-bold rounded text-xs">খুঁজুন</button>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic premium visual toast notifier */}
        {toast && (
          <div className="fixed bottom-6 left-6 z-50 bg-[#051c0d] border border-yellow-500/20 text-yellow-300 text-xs font-bold px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 animate-fade-in">
            <Sparkles className="w-4 h-4 text-yellow-400 animate-pulse" />
            <span>{toast.message}</span>
          </div>
        )}

      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50 font-sans text-neutral-800 flex flex-col selection:bg-emerald-800 selection:text-white">
      
      {/* 1. TOP HEADER / ANNOUNCEMENT BAR */}
      <div id="announcement-bar" className="bg-emerald-950 text-white py-2 px-4 text-center text-xs tracking-wider border-b border-yellow-600/30 font-medium">
        ✨ 
        <span className="gold-gradient-text font-serif font-semibold ml-1">EXCLUSIVE EID & WEDDING OFFER:</span> 
        GET UP TO 30% PRICE DISCOUNT ON SELECT ROYAL ATTIRAL. DELIVERY NATIONWIDE!
      </div>

      {/* 2. REALTIME NAVIGATION HEADER */}
      <header id="app-header" className="sticky top-0 z-40 bg-white/90 backdrop-blur-md shadow-sm border-b border-emerald-900/10 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          
          {/* Brand Logo & Name */}
          <div id="company-brand" className="flex items-center gap-2 cursor-pointer" onClick={() => { setCurrentTab('All'); setSearchQuery(""); }}>
            <span className="w-10 h-10 rounded-full bg-emerald-900 flex items-center justify-center shadow-lg shadow-emerald-900/20 text-yellow-500 font-serif font-extrabold text-2xl border border-yellow-500/35">L</span>
            <div>
              <h1 className="font-serif font-black text-2xl uppercase tracking-tighter text-emerald-950 leading-none">
                L'AURA <span className="font-sans font-light text-sm tracking-widest block text-emerald-700/80 uppercase font-semibold">Luxury BD</span>
              </h1>
            </div>
          </div>

          {/* Desktop Search Engine */}
          <div id="desktop-search" className="hidden md:flex flex-1 max-w-md relative">
            <input 
              type="text" 
              placeholder="পাঞ্জাবী, জামদানি শাড়ি, ব্রাইডাল লেহেঙ্গা..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-20 py-2.5 rounded-full border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-emerald-800 text-sm bg-neutral-50/50"
            />
            <Search className="absolute left-3.5 top-3 text-neutral-400 w-4.5 h-4.5" />
            
            {/* Camera icon button for visual search */}
            <button 
              onClick={() => setIsVisualSearchOpen(true)}
              className="absolute right-3.5 top-2 p-1.5 text-emerald-800 hover:text-emerald-950 hover:scale-110 transition bg-emerald-50 hover:bg-emerald-100 rounded-full"
              title="ক্যামেরা দিয়ে পোশাক খুঁজুন (Visual Search)"
            >
              <Camera className="w-4 h-4 cursor-pointer" />
            </button>
            
            {searchQuery && (
              <button onClick={() => setSearchQuery("")} className="absolute right-12 top-3 text-neutral-400 hover:text-red-600 text-xs font-semibold">Clear</button>
            )}
          </div>

          {/* Utility Action Buttons */}
          <div id="utility-nav" className="flex items-center gap-3">
            
            {/* Order Tracking Button */}
            <button 
              id="track-order-trigger-btn"
              onClick={() => {
                setIsTrackModalOpen(true);
                setUserOrderTrackQuery("");
                setUserTrackedOrders([]);
                setTrackSearched(false);
              }}
              className="p-2.5 rounded-full bg-emerald-50 text-emerald-900 border border-emerald-100 hover:bg-emerald-100 transition-all duration-300 flex items-center gap-1.5 text-xs font-bold shadow-xs cursor-pointer"
              title="অর্ডার ট্র্যাক করুন"
            >
              <Truck className="w-4 h-4 text-emerald-800 shrink-0" />
              <span className="hidden md:inline">অর্ডার ট্র্যাক (Track)</span>
            </button>

            {/* Live Admin Access Key */}
            <button 
              id="admin-trigger-btn"
              onClick={() => setIsAdminOpen(true)}
              className={`p-2.5 rounded-full border transition-all duration-300 flex items-center gap-1.5 text-xs font-medium ${
                adminToken 
                  ? "bg-emerald-950 text-yellow-400 border-emerald-900 shadow-md" 
                  : "bg-neutral-100 text-neutral-600 border-neutral-200 hover:bg-neutral-200"
              }`}
              title="Admin Panel Portal"
            >
              <Shield className="w-4 h-4" />
              <span className="hidden sm:inline">{adminToken ? "Admin Control" : "Admin Login"}</span>
            </button>

            {/* Wishlist Button */}
            <button 
              id="wishlist-trigger-btn"
              onClick={() => {
                // Instantly filter by wishlist
                if (wishlist.length === 0) {
                  showToast("Your wishlist is currently empty. Click on the heart icon of a premium design item to add!", "info");
                  return;
                }
                const firstId = wishlist[0];
                const matchingProd = products.find(p => p.id === firstId);
                if (matchingProd) {
                  setSelectedProduct(matchingProd);
                }
              }}
              className="p-2.5 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 transition relative"
            >
              <Heart className={`w-4.5 h-4.5 ${wishlist.length > 0 ? "fill-red-500 text-red-500" : ""}`} />
              {wishlist.length > 0 && (
                <span id="wishlist-count" className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full w-4.5 h-4.5 text-[9px] font-bold flex items-center justify-center animate-bounce">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Premium Shopping Cart trigger */}
            <button 
              id="cart-trigger-btn"
              onClick={() => setIsCartOpen(true)}
              className="p-2.5 rounded-full bg-emerald-950 text-white hover:bg-emerald-900 transition-all duration-300 flex items-center gap-2 px-4 shadow-md shadow-emerald-950/20 ring-1 ring-emerald-500/40"
            >
              <ShoppingBag className="w-4.5 h-4.5 text-yellow-500" />
              <span className="text-xs font-semibold uppercase tracking-wider hidden sm:inline">৳{getCartSubtotal().toLocaleString()}</span>
              <span id="cart-count-badge" className="bg-yellow-500 text-emerald-950 rounded-full w-4.5 h-4.5 text-[10px] font-bold flex items-center justify-center">
                {cart.reduce((sum, item) => sum + item.quantity, 0)}
              </span>
            </button>

          </div>
        </div>

        {/* Mobile Search Engine */}
        <div id="mobile-search" className="px-4 pb-3 md:hidden">
          <div className="relative">
            <input 
              type="text" 
              placeholder="পাঞ্জাবী, জামদানি শাড়ি, ব্রাইডাল লেহেঙ্গা..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-16 py-2.5 rounded-full border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-emerald-800 text-xs bg-neutral-50/50"
            />
            <Search className="absolute left-3.5 top-3.5 text-neutral-400 w-4 h-4" />
            <button 
              onClick={() => setIsVisualSearchOpen(true)}
              className="absolute right-3.5 top-2 p-1.5 text-emerald-800 hover:text-emerald-950 transition bg-emerald-50 rounded-full"
              title="ক্যামেরা দিয়ে পোশাক খুঁজুন"
            >
              <Camera className="w-3.5 h-3.5" />
            </button>
            {searchQuery && (
              <button onClick={() => setSearchQuery("")} className="absolute right-12 top-3.5 text-neutral-400 hover:text-red-650 text-xs font-semibold">Clear</button>
            )}
          </div>
        </div>

        {/* Categories Tab Navigation Bar */}
        <div id="category-bar" className="border-t border-neutral-100 bg-white/70 py-2.5 overflow-x-auto">
          <div className="max-w-7xl mx-auto px-4 flex items-center justify-center gap-1.5 md:gap-3 whitespace-nowrap min-w-max">
            {['All', 'Men', 'Women', 'Kids', 'Accessories', 'LazyChat'].map((cat) => (
              <button
                key={cat}
                id={`cat-btn-${cat.toLowerCase()}`}
                onClick={() => setCurrentTab(cat as any)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider transition-all duration-200 ${
                  currentTab === cat 
                    ? "bg-emerald-900 text-yellow-400 shadow-sm font-bold border border-yellow-700/20" 
                    : cat === 'LazyChat'
                      ? "text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-900/10"
                      : "text-neutral-600 hover:bg-neutral-100 hover:text-emerald-955"
                }`}
              >
                {cat === 'All' ? "✨ ALL ROYAL COUTURE" : 
                 cat === 'LazyChat' ? "🤖 LAZYCHAT AI" : 
                 cat.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* 3. HERO SLIDER CORNER */}
      {currentTab !== 'LazyChat' && (
        <section id="hero-banner" className="relative h-[25rem] sm:h-[30rem] overflow-hidden bg-emerald-950 text-white">
          {heroSlides.map((slide, sIdx) => (
            <div
              key={sIdx}
              id={`hero-slide-${sIdx}`}
              className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                sIdx === heroIndex ? "opacity-100 z-10" : "opacity-0 z-0"
              }`}
            >
              {/* Background Image Overlaid Dark Ambient */}
              <div 
                className="absolute inset-0 bg-cover bg-center transition-transform duration-10000 hover:scale-105"
                style={{ backgroundImage: `linear-gradient(to right, rgba(6, 40, 20, 0.95) 20%, rgba(6, 40, 20, 0.45) 70%, rgba(6, 40, 20, 0.95) 100%), url(${slide.bg})` }}
              />
              
              <div className="absolute inset-0 flex items-center z-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
                  <div className="max-w-xl animate-fade-in">
                    <span className="text-yellow-400 text-xs md:text-sm font-semibold tracking-widest uppercase mb-2 block">{slide.subtitle}</span>
                    <h2 className="text-3xl md:text-5xl font-serif font-black leading-tight mb-4 gold-gradient-text tracking-wide h-24 md:h-32">
                      {slide.title}
                    </h2>
                    <p className="text-neutral-300 text-sm md:text-base leading-relaxed mb-6 font-light">
                      {slide.desc}
                    </p>
                    
                    <div className="flex gap-3">
                      <button 
                        onClick={() => {
                          const targetCat = slide.subtitle.includes("SIRE") || slide.title.includes("Saree") ? "Women" : "Men";
                          setCurrentTab(targetCat);
                          const section = document.getElementById("products-catalog-section");
                          if (section) section.scrollIntoView({ behavior: "smooth" });
                        }}
                        className="bg-yellow-500 text-emerald-950 font-bold px-6 py-3 rounded-md text-xs tracking-widest uppercase hover:bg-yellow-400 transition"
                      >
                        Explore Outfit
                      </button>
                      <button 
                        onClick={triggerWhatsApp}
                        className="bg-transparent border border-white hover:bg-white/10 text-white font-semibold px-6 py-3 rounded-md text-xs tracking-widest uppercase transition flex items-center gap-2"
                      >
                        WhatsApp Concierge
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Manual Slides Controllers */}
          <button 
            type="button"
            onClick={() => setHeroIndex(prev => (prev - 1 + heroSlides.length) % heroSlides.length)} 
            className="absolute left-4 top-1/2 -translate-y-1/2 z-30 p-2 rounded-full bg-black/30 hover:bg-black/60 text-white transition-all"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button 
            type="button"
            onClick={() => setHeroIndex(prev => (prev + 1) % heroSlides.length)} 
            className="absolute right-4 top-1/2 -translate-y-1/2 z-30 p-2 rounded-full bg-black/30 hover:bg-black/60 text-white transition-all"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
          
          {/* Indicators dot bar */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-30 flex gap-2">
            {heroSlides.map((_, dotIdx) => (
              <button
                key={dotIdx}
                type="button"
                onClick={() => setHeroIndex(dotIdx)}
                className={`w-2.5 h-2.5 rounded-full transition-all ${
                  dotIdx === heroIndex ? "bg-yellow-400 w-6" : "bg-white/40"
                }`}
              />
            ))}
          </div>
        </section>
      )}

      {/* 4. SUCCESS ORDER NOTIFICATION TOASTER */}
      {checkoutSuccessMessage && (
        <div id="checkout-success-toaster" className="bg-emerald-950 border-y-2 border-yellow-500 text-yellow-300 py-6 px-4 animate-fade-in relative">
          <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-stretch md:items-center gap-5">
            <div className="flex items-start gap-4 flex-1">
              <Sparkles className="w-10 h-10 shrink-0 text-yellow-400 animate-pulse mt-1" />
              <div className="flex-1">
                <h3 className="font-serif font-black text-xl text-white mb-1.5 tracking-wide">🎉 আপনার অর্ডারটি সফলভাবে দাখিল করা হয়েছে!</h3>
                <p className="text-xs text-neutral-100 leading-relaxed font-light">{checkoutSuccessMessage}</p>
                <p className="text-[11px] text-emerald-400 mt-2 font-bold flex items-center gap-1.5">
                  ✅ দ্রুততম ডেলিভারি নিশ্চিত করতে সরাসরি আমাদের হোয়াটসঅ্যাপ নাম্বারে মেসেজটি সেন্ড করার অনুরোধ জানাচ্ছি।
                </p>
              </div>
            </div>
            
            {latestOrderWhatsAppLink && (
              <div className="flex flex-col justify-center items-center shrink-0 gap-1.5">
                <a 
                  href={latestOrderWhatsAppLink} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-emerald-500 hover:bg-emerald-400 text-neutral-900 border border-green-300 hover:scale-105 active:scale-95 font-extrabold px-5 py-3 rounded-md text-xs tracking-wide shadow-lg shadow-emerald-950/40 transition-all duration-150 cursor-pointer flex items-center gap-2 font-sans text-center uppercase"
                >
                  <Phone className="w-4 h-4 fill-neutral-900 text-neutral-900" />
                  হোয়াটসঅ্যাপে আমাদের জানান
                </a>
                <span className="text-[9px] text-neutral-400">মেসেজ সেন্ড দিয়ে অর্ডার বুক করুন</span>
              </div>
            )}
            
            <button 
              onClick={() => {
                setCheckoutSuccessMessage(null);
                setLatestOrderWhatsAppLink(null);
              }}
              className="absolute top-2 right-2 md:relative md:top-auto md:right-auto p-1.5 text-neutral-400 hover:text-white bg-black/40 rounded transition self-start"
              title="Close success toast"
            >
              <X className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>
      )}

      {/* 5. PRIMARY SHOPPING MAIN MODULES */}
      <main className={currentTab === 'LazyChat' ? "flex-1 w-full bg-neutral-150/40 py-6 px-2 sm:px-6 lg:px-8 max-w-7xl mx-auto" : "flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full"} id="products-catalog-section">
        
        {currentTab === 'LazyChat' ? (
          /* LARGE FULL-PAGE LAZYCHAT AI CONCIERGE WORKSPACE */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch bg-white rounded-3xl border border-neutral-200/50 p-3 sm:p-5 shadow-2xl h-[80vh] lg:h-[84vh] min-h-[620px] max-h-[920px] overflow-hidden" id="full-page-lazychat-console">
            
            {/* Left Column: Personal Style Guide & Smart Prompting */}
            <div className="lg:col-span-4 bg-emerald-950 text-white p-5 sm:p-7 rounded-2xl flex flex-col justify-between space-y-5 relative overflow-y-auto h-full scrollbar-hidden shadow-xl border border-emerald-900/40">
              <div className="absolute right-0 top-0 opacity-5 w-48 h-48 transform translate-x-8 -translate-y-8">
                <Sparkles className="w-full h-full text-white" />
              </div>
              
              <div className="space-y-5 relative z-10 w-full">
                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center border border-yellow-400/25 shadow-lg">
                  <Sparkles className="w-6 h-6 text-yellow-450 animate-pulse" />
                </div>
                <div>
                  <span className="text-[10px] text-yellow-400 font-extrabold tracking-widest uppercase block mb-1">Luxury Personal Stylist</span>
                  <h3 className="font-serif font-black text-2xl tracking-wide text-white">LazyChat AI Concierge</h3>
                  <p className="text-xs text-neutral-300 font-light mt-2 leading-relaxed">
                    আসসালামু আলাইকুম! আমাদের রাজকীয় শাড়ি, লাক্সারি পাঞ্জাবী, আধুনিক লেহেঙ্গা কিংবা হ্যান্ডব্যাগ কালেকশনের যেকোনো পোশাকের নিখুঁত বিবরণ এবং আপনার পছন্দসই সাজ সাজাতে আমি সাহায্য করবো।
                  </p>
                </div>

                <div className="pt-4 border-t border-white/10 space-y-3">
                  <p className="text-[10px] font-bold text-yellow-400 uppercase tracking-widest flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-yellow-400" /> দ্রুত এআই অ্যাসিস্ট্যান্স পেতে নিচের যেকোনো একটিতে ট্যাপ করুন:
                  </p>
                  <div className="flex flex-col gap-2">
                    {[
                      { text: "আসসালামু আলাইকুম! পুরুষদের স্টাইলিশ ডিজাইনার পাঞ্জাবী দেখতে চাই।", label: "🕺 পুরুষদের পাঞ্জাবী কালেকশন" },
                      { text: "উৎসব ও বিয়ের জন্য মেয়েদের আকর্ষণীয় জামদানি, কাতান শাড়ি ও নকশী লেহেঙ্গা দেখান।", label: "👗 শাড়ি ও লেহেঙ্গা সিলেকশন" },
                      { text: "অর্ডার করার নিয়ম এবং বিকাশ/নগদে কিভাবে পেমেন্ট করবো?", label: "💳 পেমেন্ট ও বুকিং নিয়ম" },
                      { text: "ডেলিভারি চার্জ কত এবং ঢাকার বাইরে অর্ডারের কাপড় ডেলিভারি পেতে কতদিন লাগবে?", label: "🚚 ডেলিভারি ও হোম সার্ভিস" }
                    ].map((btn, bIdx) => (
                      <button
                        key={bIdx}
                        type="button"
                        onClick={() => handleSendChatMessage(undefined, btn.text)}
                        className="w-full text-left bg-white/5 hover:bg-white/15 active:scale-[0.98] border border-white/10 text-white/95 text-[11px] py-3 px-4 rounded-xl font-medium transition-all duration-150 flex items-center justify-between group cursor-pointer"
                      >
                        <span className="truncate pr-2">{btn.label}</span>
                        <ChevronRight className="w-4 h-4 text-yellow-500 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center gap-3 relative z-10">
                <div className="w-3 h-3 bg-emerald-450 rounded-full animate-ping shrink-0" />
                <div className="text-[11px] text-neutral-300">
                  <span className="font-bold text-white block mb-0.5">সরাসরি ফোন ও সাহায্য</span>
                  হোয়াটসঅ্যাপ হেল্পলাইন: <span className="text-yellow-400 font-extrabold font-mono tracking-wider">{shopSettings.merchantPhone}</span>
                </div>
              </div>
            </div>

            {/* Right Column: Immersive Messages Stream Hub */}
            <div className="lg:col-span-8 flex flex-col justify-between border border-neutral-150 rounded-2xl bg-neutral-50/50 overflow-hidden h-full">
              
              {/* Active Header bar of full chat screen */}
              <div className="bg-neutral-900 text-white px-5 py-4 flex items-center justify-between border-b border-yellow-500/10 shadow-sm relative z-10 shrink-0">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="w-10 h-10 rounded-full bg-emerald-950 border border-yellow-500/20 flex items-center justify-center shadow">
                      <Sparkles className="w-5 h-5 text-yellow-400" />
                    </div>
                    <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 rounded-full border-2 border-neutral-900"></span>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold tracking-wider uppercase text-yellow-400">LazyChat Premium AI Lounge</h4>
                    <p className="text-[10px] text-neutral-400">পার্সোনাল এআই ফ্যাশন কো-অর্ডিনেটর • ২৪/৭ সক্রিয়</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => {
                      setCurrentTab("All");
                    }}
                    className="p-1 px-3 py-1.5 rounded-lg border border-neutral-700 bg-neutral-800 hover:bg-neutral-750 text-[10px] font-bold text-neutral-100 flex items-center gap-1 transition-all cursor-pointer"
                    title="Return to the premium store catalog"
                  >
                    শপ এ ফিরে যান (Catalog)
                  </button>
                  <button 
                    onClick={triggerWhatsApp}
                    className="p-1 px-3 py-1.5 rounded-lg bg-emerald-900 hover:bg-emerald-850 text-[10px] font-bold text-white flex items-center gap-1 transition-all cursor-pointer"
                    title="WhatsApp support contact"
                  >
                    <Phone className="w-3 w-3 text-green-400" /> WhatsApp
                  </button>
                </div>
              </div>

              {/* Chat Message Flow Board */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
                {chatMessages.map((msg) => {
                  const isUser = msg.sender === 'user';
                  return (
                    <div key={msg.id} className={`flex flex-col ${isUser ? "items-end" : "items-start"} animate-fade-in`}>
                      
                      <div className={`p-4 sm:p-5 max-w-[85%] rounded-2xl text-xs sm:text-sm leading-relaxed ${
                        isUser 
                          ? "bg-emerald-950 text-white rounded-tr-none shadow-md" 
                          : "bg-white text-neutral-850 shadow-md border border-neutral-100 rounded-tl-none"
                      }`}>
                        <div className="flex items-start gap-2.5">
                          {!isUser && (
                            <div className="w-6 h-6 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-900 flex items-center justify-center shrink-0 text-[10px] shadow-sm">
                              🤖
                            </div>
                          )}
                          <p className="whitespace-pre-line flex-1 pt-0.5">{msg.text}</p>
                        </div>
                        
                        {/* suggested products rendering if exists */}
                        {msg.suggestedProducts && msg.suggestedProducts.length > 0 && (
                          <div className="mt-4 pt-4 border-t border-dashed border-neutral-200 space-y-3">
                            <p className="text-[11px] uppercase font-bold text-emerald-900 flex items-center gap-1 tracking-wide">
                              <Sparkles className="w-3.5 h-3.5 text-yellow-500 animate-pulse shrink-0" /> আপনার পছন্দের ডিজাইনার পোশাক সিলেক্ট করুন:
                            </p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                              {msg.suggestedProducts.map((sp) => (
                                <div 
                                  key={sp.id} 
                                  onClick={() => {
                                    setSelectedProduct(sp);
                                  }}
                                  className="bg-white hover:border-emerald-700 border border-neutral-200/80 p-3 rounded-xl cursor-pointer transition-all hover:scale-[1.01] text-left flex flex-col justify-between shadow-sm hover:shadow-md group"
                                >
                                  <div>
                                    <div className="relative aspect-[4/3] rounded-lg overflow-hidden bg-neutral-100">
                                      <img src={sp.images[0]} referrerPolicy="no-referrer" className="w-full h-full object-cover group-hover:scale-105 transition duration-300" alt={sp.name} />
                                      {sp.discountPrice && (
                                        <span className="absolute top-1 left-1 bg-red-650 text-white text-[8px] font-bold px-1.5 py-0.5 rounded shadow">SALE</span>
                                      )}
                                    </div>
                                    <p className="text-[11px] text-neutral-850 font-bold line-clamp-1 mt-2.5 tracking-tight leading-tight">{sp.name}</p>
                                    <p className="text-[9px] text-neutral-450 line-clamp-1 mt-0.5">{sp.category}</p>
                                  </div>
                                  
                                  <div className="mt-3 pt-2.5 border-t border-neutral-100 flex items-center justify-between">
                                    <div>
                                      {sp.discountPrice ? (
                                        <div className="flex flex-col">
                                          <span className="text-[11px] text-emerald-950 font-black">৳{sp.discountPrice.toLocaleString()}</span>
                                          <span className="text-[8px] text-neutral-400 line-through">৳{sp.price.toLocaleString()}</span>
                                        </div>
                                      ) : (
                                        <span className="text-[11px] text-emerald-900 font-black">৳{sp.price.toLocaleString()}</span>
                                      )}
                                    </div>
                                    
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        addToCart(sp, sp.sizes[0] || "M");
                                        showToast(`${sp.name} added to cart successfully!`, "success");
                                      }}
                                      className="p-1 px-3 bg-emerald-900 hover:bg-emerald-850 text-white font-extrabold text-[9px] rounded-lg flex items-center gap-1 transition-colors uppercase whitespace-nowrap cursor-pointer z-10 hover:scale-105 shadow-xs"
                                      title="Add to Shopping Cart"
                                    >
                                      কিনুন (Buy)
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-1 text-[9px] text-neutral-400 mt-1.5 px-2">
                        <span>{msg.timestamp}</span>
                        <span className="flex items-center text-[#3ca9df] font-black text-xs select-none tracking-tighter" title="Message Read">
                          ✓✓
                        </span>
                      </div>

                    </div>
                  );
                })}

                {/* simulated AI typing indicator */}
                {isAiTyping && (
                  <div className="flex flex-col items-start animate-pulse">
                    <div className="bg-white p-4 rounded-xl border border-neutral-150 flex items-center gap-2 shadow-xs">
                      <span className="w-2 h-2 bg-emerald-900 rounded-full animate-bounce"></span>
                      <span className="w-2 h-2 bg-emerald-900 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                      <span className="w-2 h-2 bg-emerald-900 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                      <span className="text-xs text-neutral-500 font-medium pl-1">LazyChat AI চমৎকার পোশাক খুঁজে আনছে...</span>
                    </div>
                  </div>
                )}
                
                <div ref={chatEndRef} />
              </div>

              {/* Input message form sender */}
              <form onSubmit={handleSendChatMessage} className="p-3.5 bg-white border-t border-neutral-100 flex gap-2 items-center shrink-0">
                <input 
                  type="text" 
                  placeholder="আপনার পছন্দের পোশাকের নাম, ডিজাইন কিংবা কাস্টমাইজেশন নিয়ে জিজ্ঞেস করুন..." 
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  className="flex-grow pl-4 pr-3 py-3 text-xs md:text-sm rounded-xl border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-emerald-950 text-neutral-800 bg-neutral-0 focus:bg-white transition-all shadow-xs"
                />
                <button 
                  type="submit"
                  className="bg-emerald-950 hover:bg-emerald-900 active:scale-95 text-white p-3.5 rounded-xl shadow-md transition-all shrink-0 cursor-pointer"
                  title="Send input message query to AI"
                >
                  <Send className="w-4.5 h-4.5 text-white" />
                </button>
              </form>

            </div>

          </div>
        ) : (
          /* STANDARD CATALOGUE OR CATEGORY VIEW */
          <>
            {/* Section title */}
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 border-b border-neutral-200 pb-5">
              <div>
                <span className="text-emerald-900 font-bold uppercase tracking-widest text-xs">Curated Haute Collection</span>
                <h2 className="text-3xl font-serif font-semibold text-emerald-950 mt-1">
                  {currentTab === 'All' ? "Exclusive Bangladeshi Originals" : `${currentTab} Couture Specials`}
                </h2>
              </div>
              
              {/* Searching stats */}
              {searchQuery && (
                <div className="text-xs bg-neutral-200/60 rounded-full px-3 py-1.5 flex items-center gap-1.5">
                  <RotateCcw className="w-3.5 h-3.5 text-neutral-500 cursor-pointer hover:rotate-45 transition" onClick={() => setSearchQuery("")} />
                  <span>Showing search results for: <strong>"{searchQuery}"</strong> ({filteredProducts.length} items found)</span>
                </div>
              )}
            </div>

            {/* 6. LOADER IF DATA FETCHING */}
            {loading ? (
              <div className="py-24 text-center">
                <div className="inline-block w-10 h-10 border-3 border-emerald-900 border-t-yellow-400 rounded-full animate-spin mb-3"></div>
                <p className="text-neutral-500 text-xs uppercase tracking-widest font-bold">L'Aura Collection Loading...</p>
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-20 bg-white rounded-lg border border-neutral-100">
                <ShoppingBag className="w-12 h-12 text-muted mx-auto mb-3 text-neutral-300" />
                <p className="text-neutral-500 font-serif text-lg mb-3">দুঃখিত! এই ক্যাটাগরিতে এই মুহূর্তে পর্যাপ্ত প্রোডাক্ট নেই।</p>
                <p className="text-neutral-400 text-sm max-w-md mx-auto font-light mb-6">আমাদের ডিজাইনার কালেকশন ও পাঞ্জাবি স্টক নিয়মিত রিফিল করা হচ্ছে। কাস্টম পোশাকের রিকুয়েস্ট করতে আমাদের LazyChat AI এর সাহায্য নিন!</p>
                <button 
                  onClick={() => { setCurrentTab('All'); setSearchQuery(""); }}
                  className="bg-emerald-900 hover:bg-emerald-850 text-white font-medium px-5 py-2.5 rounded text-xs uppercase tracking-wider"
                >
                  Show All Couture
                </button>
              </div>
            ) : (
              /* 7. BALANCED PRODUCT GRID SYSTEM */
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4" id="product-grid">
                {filteredProducts.map((p) => {
                  const discountPercent = p.discountPrice 
                    ? Math.round(((p.price - p.discountPrice) / p.price) * 100) 
                    : 0;

                  return (
                    <div 
                      key={p.id}
                      id={`product-card-${p.id}`}
                      className="group bg-white rounded-md overflow-hidden shadow-xs hover:shadow-md transition-all duration-300 border border-neutral-100/70 relative flex flex-col h-full transform hover:-translate-y-0.5"
                    >
                      
                      {/* Image wrapper */}
                      <div className="relative aspect-square overflow-hidden bg-neutral-150 cursor-pointer" onClick={() => setSelectedProduct(p)}>
                        <img 
                          src={p.images[0]} 
                          alt={p.name} 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />

                        {/* Discount & Stock Tag Overlay */}
                        {discountPercent > 0 && (
                          <span className="absolute top-1 left-1 bg-red-600 text-white text-[7px] sm:text-[8px] font-bold uppercase px-1 py-0.5 rounded shadow-xs">
                            -{discountPercent}%
                          </span>
                        )}

                        {p.stock === 0 ? (
                          <span className="absolute top-1 right-1 bg-neutral-900/90 text-neutral-100 text-[7px] sm:text-[8px] font-black uppercase px-1 py-0.5 rounded">
                            STOCK OUT
                          </span>
                        ) : p.stock < 5 ? (
                          <span className="absolute top-1 right-1 bg-yellow-500 text-emerald-950 text-[7px] sm:text-[8px] font-black uppercase px-1 py-0.5 rounded animate-pulse">
                            FEW LEFT
                          </span>
                        ) : null}

                        {/* Quick Interactive Wishlist icon on hover */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleWishlist(p.id);
                          }}
                          className="absolute bottom-1 right-1 bg-white/90 hover:bg-white p-1 rounded-full text-neutral-800 shadow transition-all duration-300"
                          title="Add to Wishlist"
                        >
                          <Heart className={`w-3 h-3 ${wishlist.includes(p.id) ? "fill-red-500 text-red-500" : "text-neutral-500"}`} />
                        </button>
                      </div>

                      {/* Information block */}
                      <div className="p-2 flex-1 flex flex-col justify-between bg-white text-sans">
                        <div>
                          <div className="flex items-center justify-between text-[7.5px] sm:text-[8px] uppercase tracking-normal text-emerald-800 font-bold mb-0.5">
                            <span>{p.category}</span>
                            <span>{p.stock > 0 ? `${p.stock}টি বাকি` : 'স্টক আউট'}</span>
                          </div>
                          
                          <h3 
                            onClick={() => setSelectedProduct(p)}
                            className="font-sans font-bold text-[10px] sm:text-xs text-neutral-900 hover:text-emerald-900 transition cursor-pointer line-clamp-2 leading-tight min-h-[1.75rem]"
                          >
                            {p.name}
                          </h3>
                          
                          {/* Short Description */}
                          <p className="hidden md:block text-neutral-400 text-[9px] font-light truncate leading-normal mt-0.5 mb-1">
                            {p.description}
                          </p>
                        </div>

                        {/* Price and Add button area */}
                        <div className="mt-1">
                          <div className="flex items-baseline gap-1 mb-1">
                            {p.discountPrice ? (
                              <>
                                <span className="text-[10px] sm:text-xs font-black text-emerald-900">৳{p.discountPrice.toLocaleString()}</span>
                                <span className="text-[8px] sm:text-[9px] text-neutral-400 line-through">৳{p.price.toLocaleString()}</span>
                              </>
                            ) : (
                              <span className="text-[10px] sm:text-xs font-black text-emerald-900">৳{p.price.toLocaleString()}</span>
                            )}
                          </div>

                          <button 
                            disabled={p.stock === 0}
                            onClick={() => addToCart(p, p.sizes[0] || "M")}
                            className="w-full bg-emerald-900 hover:bg-emerald-850 disabled:bg-neutral-300 disabled:cursor-not-allowed text-white font-extrabold text-[9px] py-1 rounded transition flex items-center justify-center gap-1 shadow-sm"
                          >
                            <ShoppingBag className="w-2.5 h-2.5 text-yellow-500 shrink-0" /> কিনুন (Buy)
                          </button>
                        </div>

                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Dynamic promotional discount visual strip */}
            <section id="promo-offer-section" className="mt-16 bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 text-white rounded-lg p-8 md:p-12 border border-yellow-600/20 shadow-xl overflow-hidden relative">
              <div className="absolute right-0 bottom-0 opacity-15 w-96 transform translate-x-20 translate-y-20">
                <ShoppingBag className="w-96 h-96 text-yellow-400" />
              </div>
              
              <div className="max-w-2xl relative z-10">
                <span className="text-yellow-400 font-bold uppercase tracking-widest text-xs bg-yellow-500/10 px-3 py-1 rounded inline-block mb-3 border border-yellow-500/20">PREMIUM CUSTOM COUTURE</span>
                <h2 className="text-3xl md:text-4xl font-serif font-bold text-white leading-tight mb-4 tracking-wide">
                  পাঞ্জাবী ও শাড়িতে বিশেষ ৩০% পর্যন্ত ছাড়
                </h2>
                <p className="text-neutral-300 text-sm md:text-base leading-relaxed mb-6 font-light">
                  আমাদের সকল পোশাক প্রিমিয়াম সিল্ক কটন ও গ্যারান্টিড রয়াল জর্দোসি নকশায় তৈরি। আপনি bKash, Nagad, Upay বা Rocket ম্যনুয়াল পেমেন্টের মাধ্যমে খুব দ্রুত অর্ডার সম্পূর্ণ করতে পারবেন। যেকোনো ক্রয়ের পর ট্রানজেকশন আইডি ইনপুট দিয়ে নিশ্চিত করুন।
                </p>
                <div className="inline-flex flex-wrap gap-4 items-center">
                  <button 
                    onClick={() => { setCurrentTab('Women'); }}
                    className="bg-yellow-500 text-emerald-950 font-bold px-5 py-2.5 rounded text-xs uppercase tracking-widest hover:bg-yellow-450 transition"
                  >
                    Festive Saree Collection
                  </button>
                  <button 
                    onClick={() => { setCurrentTab('Men'); }}
                    className="bg-white/10 border border-white hover:bg-white/20 text-white font-semibold px-5 py-2.5 rounded text-xs uppercase tracking-widest transition"
                  >
                    Royal Punjabi Styles
                  </button>
                </div>
              </div>
            </section>
          </>
        )}

      </main>

      {/* 8. DETAILED PRODUCT DISPLAY MODAL */}
      {selectedProduct && (
        <div id="product-details-modal" className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-fade-in relative">
            
            <button 
              onClick={() => setSelectedProduct(null)}
              className="absolute right-4 top-4 p-2 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 transition z-10"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 md:p-8">
              
              {/* Product interactive pictures gallery */}
              <div className="space-y-4">
                <div className="bg-neutral-50 rounded-lg p-2 border border-neutral-200">
                  <ProductImageGallery images={selectedProduct.images} name={selectedProduct.name} />
                </div>
                <div className="bg-emerald-50 rounded p-3 text-center border border-emerald-900/5">
                  <p className="text-[10px] text-emerald-900 uppercase font-extrabold tracking-wider">🌟 Handloom authentic material assurance • 100% Cotton Velvet thread work</p>
                </div>
              </div>

              {/* Product specifications panel */}
              <div className="flex flex-col justify-between">
                <div>
                  <span className="text-xs bg-emerald-100 text-emerald-900 px-3 py-1 rounded inline-block font-extrabold uppercase tracking-widest mb-2">
                    {selectedProduct.category}
                  </span>
                  
                  <h2 className="font-serif font-bold text-2xl text-neutral-900 mb-2 leading-tight">
                    {selectedProduct.name}
                  </h2>

                  {/* Stock counter */}
                  <div className="flex items-center gap-2 text-xs mb-4">
                    {selectedProduct.stock > 0 ? (
                      <span className="text-emerald-700 font-semibold">● IN STOCK ({selectedProduct.stock} items remaining)</span>
                    ) : (
                      <span className="text-red-600 font-bold">● TEMPORARILY OUT OF STOCK</span>
                    )}
                  </div>

                  {/* Price breakdown */}
                  <div className="flex items-baseline gap-3 mb-6 bg-neutral-50 p-3 rounded border border-neutral-100">
                    {selectedProduct.discountPrice ? (
                      <>
                        <span className="text-2xl font-black text-emerald-950">৳{selectedProduct.discountPrice.toLocaleString()}</span>
                        <span className="text-sm text-neutral-400 line-through">৳{selectedProduct.price.toLocaleString()}</span>
                        <span className="text-xs bg-red-100 text-red-600 font-bold px-2 py-0.5 rounded ml-auto">
                          SAVE ৳{(selectedProduct.price - selectedProduct.discountPrice).toLocaleString()} (BD Taka)
                        </span>
                      </>
                    ) : (
                      <span className="text-2xl font-black text-emerald-950">৳{selectedProduct.price.toLocaleString()}</span>
                    )}
                  </div>

                  <p className="text-neutral-600 text-sm leading-relaxed mb-6 font-light">
                    {selectedProduct.description}
                  </p>

                  {/* Interactive size options */}
                  <div className="mb-6">
                    <span className="text-xs font-bold text-neutral-700 uppercase tracking-wider block mb-2">Select Fit Size:</span>
                    <div className="flex gap-2">
                      {selectedProduct.sizes.map((sz) => (
                        <button
                          key={sz}
                          id={`size-btn-${sz}`}
                          className="w-10 h-10 rounded border border-neutral-300 hover:border-emerald-900 hover:bg-emerald-50 font-bold text-xs flex items-center justify-center transition focus:ring-2 focus:ring-emerald-900"
                        >
                          {sz}
                        </button>
                      ))}
                    </div>
                    <span className="text-[10px] text-neutral-400 mt-1.5 block">Standard South Asian regular standard measurements apply.</span>
                  </div>
                </div>

                {/* Operations button */}
                <div className="space-y-2.5">
                  <button
                    disabled={selectedProduct.stock === 0}
                    onClick={() => {
                      addToCart(selectedProduct, "M"); // Default to M or first size
                      setSelectedProduct(null);
                    }}
                    className="w-full bg-emerald-900 hover:bg-emerald-850 disabled:bg-neutral-300 disabled:cursor-not-allowed text-white font-bold py-3.5 rounded text-xs uppercase tracking-widest transition flex items-center justify-center gap-2"
                  >
                    <ShoppingBag className="w-4 h-4 text-yellow-500" /> ADD TO SHOPPING BAG
                  </button>
                  <button
                    onClick={() => {
                      toggleWishlist(selectedProduct.id);
                    }}
                    className="w-full border border-neutral-200 hover:border-neutral-300 bg-white hover:bg-neutral-50 text-neutral-800 font-bold py-2.5 rounded text-xs uppercase tracking-widest transition"
                  >
                    {wishlist.includes(selectedProduct.id) ? "❤️ SAVED IN WISHLIST" : "🤍 ADD TO MY WISHLIST"}
                  </button>
                </div>

              </div>
            </div>

          </div>
        </div>
      )}

      {/* 9. SLIDING SHOPPING CART PANEL */}
      {isCartOpen && (
        <div id="shopping-cart-drawer" className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-xs transition-opacity" onClick={() => setIsCartOpen(false)} />
          
          <div className="relative w-full max-w-md bg-white h-screen shadow-2xl flex flex-col justify-between z-10 animate-fade-in">
            
            {/* Header section */}
            <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-emerald-950 text-white">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-yellow-400" />
                <h3 className="font-serif font-bold text-lg tracking-wide">আপনার শপিং ব্যাগ</h3>
              </div>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="p-1 px-2 hover:bg-white/10 rounded text-neutral-300 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Items list scrollable */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {cart.length === 0 ? (
                <div className="text-center py-20 text-neutral-400">
                  <ShoppingBag className="w-12 h-12 text-neutral-200 mx-auto mb-3" />
                  <p className="font-serif text-neutral-600 mb-1">আপনার ব্যাগটি খালি রয়েছে</p>
                  <p className="text-xs font-light">আমাদের এক্সক্লুসিভ কালেকশন থেকে আপনার পছন্দের পোশাক ব্যাগে যুক্ত করুন!</p>
                </div>
              ) : (
                cart.map((item, index) => {
                  const finalPrice = item.product.discountPrice || item.product.price;
                  return (
                    <div key={`${item.product.id}-${item.size}-${index}`} className="flex gap-3 p-3 rounded-lg border border-neutral-100 relative group bg-neutral-50/50">
                      
                      <img 
                        src={item.product.images[0]} 
                        alt={item.product.name} 
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 object-cover rounded bg-neutral-100"
                      />
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-neutral-900 truncate">{item.product.name}</h4>
                        <p className="text-[10px] text-emerald-800 font-extrabold uppercase mt-0.5">SIZE: {item.size}</p>
                        
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-neutral-500">Qty: {item.quantity}</span>
                          <span className="text-xs font-bold text-emerald-900">৳{(finalPrice * item.quantity).toLocaleString()}</span>
                        </div>
                      </div>

                      <button 
                        onClick={() => removeFromCart(item.product.id, item.size)}
                        className="absolute top-2 right-2 p-1 text-neutral-400 hover:text-red-650 opacity-0 group-hover:opacity-100 transition duration-200"
                        title="Remove product"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>

                    </div>
                  );
                })
              )}
            </div>

            {/* Subtotal & Action strip */}
            <div className="p-4 border-t border-neutral-100 bg-neutral-50 space-y-3">
              <div className="flex justify-between items-center text-sm font-semibold text-neutral-900">
                <span>Subtotal BD Taka:</span>
                <span className="text-lg font-black text-emerald-950">৳{getCartSubtotal().toLocaleString()}</span>
              </div>
              <p className="text-[10px] text-neutral-400 leading-normal">
                📦 Standard home delivery. Orders are manually audited. Fast delivery in Dhaka (24 - 48 hours), other regions 3 to 4 days.
              </p>

              <button
                disabled={cart.length === 0}
                onClick={() => {
                  setIsCartOpen(false);
                  setIsCheckoutOpen(true);
                }}
                className="w-full bg-emerald-900 hover:bg-emerald-850 disabled:bg-neutral-300 disabled:cursor-not-allowed text-white text-xs font-bold py-3.5 rounded tracking-widest uppercase transition shadow"
              >
                PROCEED TO CHECKOUT ৳{getCartSubtotal().toLocaleString()}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* 10. REAL-TIME MANUAL CHECKOUT FORM */}
      {isCheckoutOpen && (
        <div id="checkout-modal" className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-lg max-w-2xl w-full shadow-2xl p-6 md:p-8 relative max-h-[90vh] overflow-y-auto my-10 border border-emerald-900/10">
            
            <button 
              onClick={() => setIsCheckoutOpen(false)}
              className="absolute right-4 top-4 p-2 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 transition"
              title="Close checkout"
            >
              <X className="w-4.5 h-4.5" />
            </button>

            <div className="text-center mb-6">
              <h3 className="font-serif font-black text-2xl text-emerald-950 mb-1">অর্ডার নিশ্চিতকরণ ও পেমেন্ট</h3>
              <p className="text-xs text-neutral-400 font-light">Please input your contact information and manual transaction reference ID below</p>
            </div>

            <form onSubmit={handlePlaceOrder} className="space-y-6">
              
              {/* Product order preview summary */}
              <div className="bg-neutral-50 p-4 rounded-md border border-neutral-100">
                <span className="text-[10px] text-neutral-400 uppercase tracking-widest font-bold block mb-2">Order Summary</span>
                {cart.map((it, idx) => (
                  <div key={idx} className="flex justify-between text-xs py-1 text-neutral-700 border-b border-dashed border-neutral-200 last:border-0 last:pb-0">
                    <span>{it.product.name} (Size {it.size}) x {it.quantity}</span>
                    <span className="font-bold text-emerald-950">৳{((it.product.discountPrice || it.product.price) * it.quantity).toLocaleString()}</span>
                  </div>
                ))}
                <div className="flex justify-between text-sm font-bold text-emerald-900 pt-3 mt-2 border-t border-neutral-200">
                  <span>Grand Total amount:</span>
                  <span>৳{getCartSubtotal().toLocaleString()} BDT</span>
                </div>
              </div>

              {/* Delivery info */}
              <div className="space-y-4">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-900 border-b border-neutral-100 pb-1">১. কাস্টমার ডেলিভারি তথ্য</h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 mb-1.5">কাস্টমারের নাম *</label>
                    <input 
                      type="text" 
                      required
                      placeholder="যেমন: রবিউল হক"
                      value={checkoutName}
                      onChange={(e) => setCheckoutName(e.target.value)}
                      className="w-full px-3 py-2 rounded border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-emerald-900 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 mb-1.5">মোবাইল নাম্বার *</label>
                    <input 
                      type="tel" 
                      required
                      placeholder="যেমন: 017xxxxxxxx"
                      value={checkoutPhone}
                      onChange={(e) => setCheckoutPhone(e.target.value)}
                      className="w-full px-3 py-2 rounded border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-emerald-900 text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-600 mb-1.5">সম্পূর্ণ ঠিকানা *</label>
                  <textarea 
                    rows={2}
                    required
                    placeholder="হোল্ডিং নং, রোড নং, থানা, জেলা"
                    value={checkoutAddress}
                    onChange={(e) => setCheckoutAddress(e.target.value)}
                    className="w-full px-3 py-2 rounded border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-emerald-900 text-sm"
                  />
                </div>
              </div>

              {/* Payment selection with official flow */}
              <div className="space-y-4">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-900 border-b border-neutral-100 pb-1">২. পেমেন্ট মেথড নির্বাচন করুন</h4>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {(['bKash', 'Nagad', 'Rocket', 'Upay', 'Cash on Delivery'] as PaymentMethod[]).map((method) => (
                    <button
                      type="button"
                      key={method}
                      onClick={() => setCheckoutPayment(method)}
                      className={`relative w-full h-24 rounded-xl flex flex-col items-center justify-between p-3.5 transition-all duration-300 active:scale-95 cursor-pointer bg-white border-2 hover:shadow-md ${
                        checkoutPayment === method 
                          ? "border-emerald-700 bg-emerald-50/10 ring-4 ring-emerald-950/10" 
                          : "border-neutral-200 hover:border-neutral-300"
                      }`}
                    >
                      {/* Logo Wrapper */}
                      <div className="w-full h-14 flex items-center justify-center overflow-hidden rounded-lg bg-neutral-50/50">
                        {!brokenLogos[method] ? (
                          <img 
                            src={PAYMENT_LOGOS[method]} 
                            alt={method} 
                            className="max-h-full max-w-full object-contain p-0.5 transform hover:scale-105 transition-transform duration-300"
                            referrerPolicy="no-referrer"
                            onError={() => setBrokenLogos(prev => ({ ...prev, [method]: true }))}
                          />
                        ) : (
                          renderPaymentLogoFallback(method)
                        )}
                      </div>
                      
                      {/* Sub-label */}
                      <div className="leading-none mt-1">
                        <span className="text-[11px] font-bold text-neutral-800">
                          {method === 'bKash' && 'বিকাশ (bKash)'}
                          {method === 'Nagad' && 'নগদ (Nagad)'}
                          {method === 'Rocket' && 'রকেট (Rocket)'}
                          {method === 'Upay' && 'উপায় (Upay)'}
                          {method === 'Cash on Delivery' && 'ক্যাশ অন ডেলিভারি'}
                        </span>
                      </div>

                      {/* Active indicator badge */}
                      {checkoutPayment === method ? (
                        <span className="absolute top-1.5 right-1.5 bg-emerald-700 text-white rounded-full p-0.5 shadow-md ring-2 ring-white animate-bounce-subtle">
                          <CheckCheck className="w-3 h-3 text-white" />
                        </span>
                      ) : (
                        <span className="absolute top-1.5 right-1.5 w-3 h-3 bg-neutral-100 rounded-full border border-neutral-300" />
                      )}
                    </button>
                  ))}
                </div>

                {/* Bangladesh Manual Payment Flow Guide */}
                {checkoutPayment !== "Cash on Delivery" ? (
                  <div className="bg-amber-50/70 border border-amber-200 p-4 rounded text-xs space-y-3.5">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="font-extrabold text-[#78350f]">ম্যানুয়াল পেমেন্ট করার নিয়মাবলী:</p>
                        <p className="text-[11px] text-amber-905 mt-0.5">১. আমাদের {checkoutPayment} নাম্বার <strong className="text-emerald-900 font-black">{getPaymentNumber()}</strong> এ Select Payment অপশন বা Send Money করুন।</p>
                        <p className="text-[11px] text-amber-905 mt-0.5">২. পেমেন্ট সম্পন্ন হলে নিচের বক্সে সঠিক <strong className="text-emerald-900 font-bold">Transaction ID</strong> টাইপ করে সাবমিট করুন।</p>
                      </div>
                      
                      {/* One Click Copy Button */}
                      <button
                        type="button"
                        onClick={copyAccountToClipboard}
                        className="bg-emerald-900 hover:bg-emerald-850 shrink-0 text-white rounded px-3 py-2 font-bold flex items-center gap-1 text-[11px] transition shadow"
                      >
                        {copiedNumber ? <Check className="w-3.5 h-3.5 text-yellow-500" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedNumber ? "Copied!" : "Copy No."}
                      </button>
                    </div>

                    <div>
                      <label className="block font-semibold text-neutral-700 mb-1.5">ট্রানজেকশন আইডি (Trans ID) ইনপুট দিন *</label>
                      <input 
                        type="text" 
                        required
                        placeholder="যেমন: BX9K87GHD9"
                        value={checkoutTrxId}
                        onChange={(e) => setCheckoutTrxId(e.target.value)}
                        className="w-full px-3 py-2 rounded border border-neutral-300 focus:outline-none focus:ring-1 focus:ring-emerald-900 font-mono text-sm bg-white text-emerald-950 uppercase"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="bg-emerald-50 text-emerald-900 border border-emerald-100 p-3 rounded text-xs">
                    🚚 আপনি ক্যাশ অন ডেলিভারি সিলেক্ট করেছেন। আপনার বাসার ঠিকানায় প্যাকেট পৌঁছানোর পর ডেলিভারি ম্যানের কাছে নগদ মূল্য পরিশোধ করবেন। অর্ডার প্রসেস করতে Transaction ID লাগবে না।
                  </div>
                )}
              </div>

              {/* Submit Buttons */}
              <div className="flex gap-3 pt-4 justify-end">
                <button
                  type="button"
                  onClick={() => setIsCheckoutOpen(false)}
                  className="px-5 py-2.5 rounded border border-neutral-300 text-neutral-700 hover:bg-neutral-100 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-900 hover:bg-emerald-850 text-white px-8 py-2.5 rounded text-xs font-extrabold uppercase tracking-widest transition shadow"
                >
                  Confirm Purchase ৳{getCartSubtotal().toLocaleString()}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* 10.5 PREMIUM VISUAL CAM/CAMERA SEARCH DIALOG */}
      {isVisualSearchOpen && (
        <div id="visual-search-modal" className="fixed inset-0 bg-black/75 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-emerald-950 flex flex-col relative animate-fade-in">
            {/* Header */}
            <div className="p-4 bg-emerald-950 text-white flex items-center justify-between border-b border-yellow-500/10 z-10">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-yellow-400 animate-bounce-subtle" />
                <h3 className="font-serif font-bold text-base tracking-wide">ক্যামেরা ও ভিজ্যুয়াল সার্চ (Visual Search)</h3>
              </div>
              <button 
                onClick={() => {
                  setIsVisualSearchOpen(false);
                  setVsScanning(false);
                  setVsResult(null);
                }}
                className="p-1 rounded-full hover:bg-white/10 text-neutral-300 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="p-6 space-y-6">
              
              {/* Scan box area wrapper */}
              <div className="bg-neutral-950 aspect-video rounded-xl overflow-hidden relative border border-neutral-800 flex flex-col items-center justify-center">
                
                {/* Viewfinder corner lines */}
                <span className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2 border-yellow-400"></span>
                <span className="absolute top-4 right-4 w-6 h-6 border-t-2 border-r-2 border-yellow-400"></span>
                <span className="absolute bottom-4 left-4 w-6 h-6 border-b-2 border-l-2 border-yellow-400"></span>
                <span className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2 border-yellow-400"></span>

                {vsScanning ? (
                  <>
                    {/* Pulsing laser beam effect */}
                    <span className="absolute inset-x-0 h-1 bg-yellow-400/80 shadow-[0_0_15px_#facc15] animate-scan-beam"></span>
                    <p className="text-yellow-400 text-xs font-mono tracking-widest animate-pulse font-bold mt-2">SCANNING ATTIRAL OUTFIT...</p>
                    <p className="text-[10px] text-neutral-400 mt-1 font-light">Analyzing fabric, embroidery density & fit pattern</p>
                  </>
                ) : vsResult ? (
                  <div className="text-center p-4">
                    <CheckCheck className="w-10 h-10 text-emerald-400 mx-auto mb-2 animate-bounce" />
                    <p className="text-white text-sm font-semibold">{vsResult}</p>
                    <p className="text-xs text-neutral-400 mt-1">প্রোডাক্ট ক্যাটালগ ফিল্টার করা হয়েছে!</p>
                  </div>
                ) : (
                  <div className="text-center p-4 text-neutral-400 space-y-3">
                    <Camera className="w-12 h-12 text-neutral-500 mx-auto mb-1 animate-pulse" />
                    <p className="text-xs">আপনার ডিভাইস থেকে পোশাকের ছবি আপলোড করুন</p>
                    <p className="text-[10px] text-neutral-500">অথবা নিচের দ্রুত ক্যাটাগরিগুলি ট্রাই করুন</p>
                  </div>
                )}
              </div>

              {/* Upload input option */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">১. ছবি আপলোড করুন (Upload Image)</label>
                <div className="relative group border-2 border-dashed border-neutral-300 hover:border-emerald-900 rounded-lg p-5 text-center cursor-pointer transition hover:bg-neutral-50">
                  <input 
                    type="file" 
                    accept="image/*"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        const file = e.target.files[0];
                        setVsScanning(true);
                        setVsResult(null);
                        
                        // Simulate camera deep search algorithm scan
                        setTimeout(() => {
                          setVsScanning(false);
                          // intelligently guess category based on name
                          const name = file.name.toLowerCase();
                          if (name.includes("saree") || name.includes("women") || name.includes("shari") || name.includes("sari") || name.includes("share")) {
                            setSearchQuery("Saree");
                            setVsResult("✨ শাড়ি কালেকশন সনাক্ত হয়েছে (Saree Detected)");
                          } else if (name.includes("panjabi") || name.includes("punjabi") || name.includes("men")) {
                            setSearchQuery("Punjabi");
                            setVsResult("✨ ছেলেদের পাঞ্জাবী কালেকশন সনাক্ত হয়েছে (Punjabi Detected)");
                          } else if (name.includes("bag") || name.includes("accessory") || name.includes("purse")) {
                            setSearchQuery("bag");
                            setVsResult("✨ ডিজাইনার হ্যান্ডব্যাগ সনাক্ত হয়েছে (Luxury Bag Detected)");
                          } else {
                            // default fallback search item matching
                            setSearchQuery("Punjabi");
                            setVsResult("✨ ছেলেদের রাজকীয় পাঞ্জাবী কালেকশন সনাক্ত হয়েছে (Punjabi Detected)");
                          }
                        }, 2500);
                      }
                    }}
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                  />
                  <div className="flex flex-col items-center gap-1.5 text-neutral-600">
                    <Upload className="w-5 h-5 text-emerald-950 group-hover:scale-110 transition shrink-0" />
                    <span className="text-xs font-semibold">ক্লিক করে ছবি নির্বাচন করুন</span>
                    <span className="text-[10px] text-neutral-400">JPG, PNG, WEBP (Max 5MB)</span>
                  </div>
                </div>
              </div>

              {/* Quick Preset Filters */}
              <div className="space-y-2 pt-2 border-t border-neutral-100">
                <span className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">২. দ্রুত ডেমো ভিজ্যুয়াল ম্যাচিং ট্রাই করুন:</span>
                <div className="grid grid-cols-3 gap-2">
                  <button 
                    onClick={() => {
                      setVsScanning(true);
                      setVsResult(null);
                      setTimeout(() => {
                        setVsScanning(false);
                        setSearchQuery("Punjabi");
                        setVsResult("✨ পাঞ্জাবী কালেকশন সনাক্ত হয়েছে!");
                      }, 1200);
                    }}
                    className="border border-neutral-200 hover:border-emerald-900 rounded p-2 text-center text-xs hover:bg-emerald-50/50 transition cursor-pointer font-medium"
                  >
                    🤵 পাঞ্জাবী (Punjabi)
                  </button>
                  <button 
                    onClick={() => {
                      setVsScanning(true);
                      setVsResult(null);
                      setTimeout(() => {
                        setVsScanning(false);
                        setSearchQuery("Saree");
                        setVsResult("✨ রাজকীয় সিল্ক শাড়ি সনাক্ত হয়েছে!");
                      }, 1200);
                    }}
                    className="border border-neutral-200 hover:border-emerald-950 rounded p-2 text-center text-xs hover:bg-emerald-50/50 transition cursor-pointer font-medium"
                  >
                    🥻 শাড়ি (Saree)
                  </button>
                  <button 
                    onClick={() => {
                      setVsScanning(true);
                      setVsResult(null);
                      setTimeout(() => {
                        setVsScanning(false);
                        setSearchQuery("bag");
                        setVsResult("✨ লাক্সারি হ্যান্ডব্যাগ সনাক্ত হয়েছে!");
                      }, 1200);
                    }}
                    className="border border-neutral-200 hover:border-emerald-900 rounded p-2 text-center text-xs hover:bg-emerald-50/50 transition cursor-pointer font-medium"
                  >
                    👜 ব্যাগ (Bags)
                  </button>
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex justify-end">
              <button 
                onClick={() => {
                  setIsVisualSearchOpen(false);
                  setVsScanning(false);
                  setVsResult(null);
                }}
                className="bg-emerald-950 hover:bg-emerald-900 text-white px-5 py-2 rounded text-xs font-bold cursor-pointer"
              >
                আউটফিট দেখুন
              </button>
            </div>
          </div>
         </div>
      )}

      {/* 10.6 REALTIME ORDER TRACKING MODAL */}
      {isTrackModalOpen && (
        <div id="order-tracking-modal" className="fixed inset-0 bg-black/75 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden border border-emerald-950 flex flex-col relative animate-fade-in max-h-[85vh]">
            
            {/* Header */}
            <div className="p-4 bg-emerald-950 text-white flex items-center justify-between border-b border-yellow-500/10 z-10">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-yellow-400" />
                <h3 className="font-serif font-bold text-base tracking-wide">অর্ডার ট্র্যাকিং সিস্টেম (Live Order Tracking)</h3>
              </div>
              <button 
                onClick={() => {
                  setIsTrackModalOpen(false);
                  setUserOrderTrackQuery("");
                  setUserTrackedOrders([]);
                  setTrackSearched(false);
                }}
                className="p-1 rounded-full hover:bg-white/10 text-neutral-300 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="p-6 space-y-6 overflow-y-auto flex-1">
              
              {/* Input Form Box */}
              <div className="bg-emerald-50/50 p-4 sm:p-5 rounded-xl border border-emerald-100 space-y-3">
                <label className="block text-xs font-black text-emerald-950 uppercase tracking-wider">মোবাইল নাম্বার অথবা অর্ডার আইডি দিন:</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input 
                      type="text" 
                      placeholder="যেমন: 017xxxxxxxx বা ord-1234" 
                      value={userOrderTrackQuery}
                      onChange={(e) => setUserOrderTrackQuery(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleTrackOrder(userOrderTrackQuery);
                        }
                      }}
                      className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-emerald-800 text-sm bg-white"
                    />
                    <Search className="absolute left-3 top-3.5 text-neutral-400 w-4 h-4" />
                  </div>
                  <button 
                    disabled={trackLoading}
                    onClick={() => handleTrackOrder(userOrderTrackQuery)}
                    className="bg-emerald-900 hover:bg-emerald-950 disabled:bg-neutral-300 text-white px-5 py-2.5 rounded-lg text-xs font-black transition cursor-pointer shrink-0"
                  >
                    {trackLoading ? "অনুসন্ধান চলছে..." : "ট্র্যাক করুন"}
                  </button>
                </div>
                <p className="text-[10px] text-neutral-500 font-light">আপনার পেমেন্ট করার পর প্রাপ্ত ৪ অঙ্কের অর্ডার আইডি অথবা মোবাইল নাম্বার দিয়ে খুজুন।</p>
              </div>

              {/* Loader */}
              {trackLoading && (
                <div className="py-12 text-center space-y-3">
                  <div className="inline-block w-8 h-8 border-4 border-emerald-900 border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-xs text-neutral-500 font-bold">লাইভ ডাটাবেজ থেকে আপনার তথ্য অনুসন্ধান করা হচ্ছে...</p>
                </div>
              )}

              {/* Empty placeholder or Not searched yet */}
              {!trackLoading && !trackSearched && (
                <div className="py-8 text-center text-neutral-400 space-y-2">
                  <Package className="w-12 h-12 text-neutral-300 mx-auto" />
                  <p className="text-xs">অর্ডারের লাইভ আপডেট ও ডেলিভারি স্ট্যাটাস জানতে উপরে ইনপুট দিন।</p>
                </div>
              )}

              {/* No items matching result */}
              {!trackLoading && trackSearched && userTrackedOrders.length === 0 && (
                <div className="py-10 text-center bg-red-50/50 rounded-xl border border-red-100 space-y-2">
                  <AlertCircle className="w-10 h-10 text-red-500 mx-auto" />
                  <p className="text-sm font-bold text-red-800">কোনো অর্ডার পাওয়া যায়নি!</p>
                  <p className="text-xs text-neutral-500 max-w-sm mx-auto">দুঃখিত, আপনার দেওয়া মোবাইল নাম্বার বা ৪ সংখ্যার অর্ডার আইডি দিয়ে কোনো অর্ডার সনাক্ত করা যায়নি। অনুগ্রহ করে সঠিক তথ্য প্রদান করুন।</p>
                </div>
              )}

              {/* Matched Orders List map */}
              {!trackLoading && trackSearched && userTrackedOrders.length > 0 && (
                <div className="space-y-6">
                  <p className="text-xs font-bold text-neutral-600 border-b pb-2">সর্বমোট {userTrackedOrders.length} টি অর্ডারের বিবরণ পাওয়া গেছে:</p>
                  
                  {userTrackedOrders.map((ord) => {
                    const statusSteps = ["Pending", "Confirmed", "Shipped", "Delivered"];
                    const currentStepIdx = statusSteps.indexOf(ord.status);
                    
                    return (
                      <div key={ord.id} className="border border-neutral-200 rounded-xl p-4 sm:p-5 bg-neutral-50/40 space-y-5 shadow-xs">
                        
                        {/* Header metadata row */}
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-neutral-150 pb-3">
                          <div>
                            <span className="bg-emerald-900 text-white font-mono font-black text-xs px-2.5 py-1 rounded inline-block mr-1">অর্ডার কোড: {ord.id}</span>
                            <span className="text-[10px] text-neutral-400 block sm:inline sm:ml-2">{new Date(ord.createdAt).toLocaleString()}</span>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${
                            ord.status === "Pending" ? "bg-amber-100 text-amber-800 border border-amber-200" :
                            ord.status === "Confirmed" ? "bg-emerald-100 text-emerald-800 border border-emerald-200 animate-pulse" :
                            ord.status === "Shipped" ? "bg-indigo-100 text-indigo-800 border border-indigo-200" :
                            "bg-neutral-200 text-neutral-800"
                          }`}>
                            {ord.status === "Pending" ? "পেন্ডিং (যাচাই চলছে)" :
                             ord.status === "Confirmed" ? "পেমেন্ট নিশ্চিত হয়েছে" :
                             ord.status === "Shipped" ? "কুরিয়ার কাস্টডিতে রয়েছে" :
                             "সফলভাবে ডেলিভার্ড হয়েছে"}
                          </span>
                        </div>

                        {/* STEPPER PROGRESS DESIGN */}
                        <div id="tracking-stepper" className="relative pt-4 pb-2">
                          {/* Connection line background */}
                          <div className="absolute top-[26px] left-[5%] right-[5%] h-1 bg-neutral-200 -z-10 rounded"></div>
                          {/* Active connection line overlay */}
                          <div 
                            className="absolute top-[26px] left-[5%] h-1 bg-emerald-600 -z-10 rounded transition-all duration-700"
                            style={{ width: `${(Math.max(0, currentStepIdx) / (statusSteps.length - 1)) * 90}%` }}
                          ></div>

                          {/* Steps circles representation */}
                          <div className="flex justify-between items-center px-1">
                            {statusSteps.map((step, idx) => {
                              const isActive = idx <= currentStepIdx;
                              const isCurrent = idx === currentStepIdx;
                              
                              return (
                                <div key={step} className="flex flex-col items-center flex-1 text-center relative">
                                  {/* Step Circle Bubble */}
                                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-extrabold text-xs transition duration-500 border-2 ${
                                    isCurrent ? "bg-emerald-950 border-yellow-500 text-white ring-4 ring-emerald-900/20 scale-110" :
                                    isActive ? "bg-emerald-800 border-emerald-900 text-white" :
                                    "bg-white border-neutral-300 text-neutral-400"
                                  }`}>
                                    {idx === 0 && <Clock className="w-4 h-4 shrink-0" />}
                                    {idx === 1 && <CheckCheck className="w-4 h-4 shrink-0" />}
                                    {idx === 2 && <Truck className="w-4 h-4 shrink-0" />}
                                    {idx === 3 && <ShoppingBag className="w-4 h-4 shrink-0" />}
                                  </div>

                                  {/* Step details captions */}
                                  <span className={`text-[9px] sm:text-[10px] mt-2 font-bold block ${isActive ? "text-emerald-950 font-black" : "text-neutral-400"}`}>
                                    {step === "Pending" ? "অর্ডার দাখিল" :
                                     step === "Confirmed" ? "পেমেন্ট কনফার্ম" :
                                     step === "Shipped" ? "শিপড (Courier)" :
                                     "ডেলিভার্ড"}
                                  </span>
                                  <span className="text-[8px] text-neutral-400 hidden sm:block">
                                    {step === "Pending" ? "Pending Approval" :
                                     step === "Confirmed" ? "Packaging Spec" :
                                     step === "Shipped" ? "In Dispatch" :
                                     "Completed"}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        {/* Order overview items tables */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-3">
                          <div className="bg-white p-3.5 rounded-lg border border-neutral-200 text-[11px] space-y-1">
                            <p className="font-extrabold text-emerald-900 mb-1 border-b pb-1">👗 অর্ডারকৃত পোশাকের বিবরণ:</p>
                            <p><strong>পোশাকের নাম:</strong> {ord.productName}</p>
                            <p><strong>সাইজ (Size Selection):</strong> <span className="bg-neutral-100 px-1.5 py-0.5 rounded font-bold font-mono text-xs">{ord.size}</span></p>
                            <p><strong>পেমেন্ট মেথড:</strong> {ord.paymentMethod === "Cash on Delivery" ? "ক্যাশ অন ডেলিভারি" : ord.paymentMethod}</p>
                            <p><strong>ট্রানজেকশন আইডি:</strong> <span className="font-mono text-yellow-750 font-bold bg-yellow-50 px-1 border rounded text-[10px] uppercase">{ord.transactionId || "N/A"}</span></p>
                            <p><strong>পরিশোধিত মূল্য:</strong> <strong className="text-emerald-900 text-xs">৳{ord.amount?.toLocaleString()} BDT</strong></p>
                          </div>

                          <div className="bg-white p-3.5 rounded-lg border border-neutral-200 text-[11px] space-y-1">
                            <p className="font-extrabold text-emerald-900 mb-1 border-b pb-1">🚚 ডেলিভারি ও কাস্টমার তথ্য:</p>
                            <p><strong>গ্রাহকের নাম:</strong> {ord.userName}</p>
                            <p><strong>যোগাযোগের নাম্বার:</strong> {ord.phone}</p>
                            <p><strong>ডেলিভারি ঠিকানা:</strong> {ord.address}</p>
                            <p className="text-[10px] text-neutral-400 italic pt-1 border-t mt-1">পেন্ডিং থাকলে আমাদের কাস্টমার প্রতিনিধি সর্বোচ্চ ১-৩ ঘন্টার মধ্যে আপনার পেমেন্ট ভেরিফাই করে কনফার্ম করবেন।</p>
                          </div>
                        </div>

                      </div>
                    );
                  })}
                </div>
              )}

            </div>

            {/* Footer */}
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex justify-end">
              <button 
                onClick={() => {
                  setIsTrackModalOpen(false);
                  setUserOrderTrackQuery("");
                  setUserTrackedOrders([]);
                  setTrackSearched(false);
                }}
                className="bg-emerald-950 hover:bg-emerald-900 text-white px-6 py-2 rounded text-xs font-bold cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 11. PERSISTENT LAZYCHAT AI MASSENGER SYSTEM */}
      <div id="ai-lazy-messenger" className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
        {isChatOpen ? (
          
          /* Chat Expanded Glassmorphism messenger interface */
          <div className="w-[20rem] sm:w-[23rem] h-[25rem] sm:h-[28rem] rounded-xl shadow-2xl glass-panel border border-emerald-900/10 flex flex-col justify-between overflow-hidden animate-fade-in relative ring-1 ring-emerald-500/20">
            
            {/* Header branding */}
            <div className="p-3.5 bg-emerald-950 text-white flex items-center justify-between border-b border-yellow-500/15">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-900 flex items-center justify-center border border-yellow-450/20 shadow">
                  <Sparkles className="w-4.5 h-4.5 text-yellow-400 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-xs font-bold tracking-tight">LazyChat AI Concierge</h4>
                  <p className="text-[9px] text-yellow-400">Online • Double Tick ✓✓ Enabled</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <button 
                  onClick={triggerWhatsApp}
                  className="p-1 px-2 rounded bg-emerald-900 hover:bg-emerald-800 text-[10px] text-white flex items-center gap-1 transition"
                  title="WhatsApp helpline support chat page"
                >
                  <Phone className="w-3 h-3" /> WhatsApp
                </button>
                <button 
                  onClick={() => setIsChatOpen(false)}
                  className="p-1 text-neutral-300 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Chat Messages flow stream */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-neutral-50/80">
              {chatMessages.map((msg) => {
                const isUser = msg.sender === 'user';
                return (
                  <div key={msg.id} className={`flex flex-col ${isUser ? "items-end" : "items-start"}`}>
                    
                    <div className={`p-3 max-w-[85%] rounded-lg text-xs leading-relaxed ${
                      isUser 
                        ? "bg-emerald-900 text-white rounded-br-none" 
                        : "bg-white text-neutral-850 shadow-xs border border-emerald-900/5 rounded-bl-none"
                    }`}>
                      <p>{msg.text}</p>
                      
                      {/* suggested products rendering if exists */}
                      {msg.suggestedProducts && msg.suggestedProducts.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-dotted border-neutral-200 space-y-2">
                          <p className="text-[10px] uppercase font-bold text-emerald-800">✨ Recommended Outfits:</p>
                          <div className="grid grid-cols-2 gap-2">
                            {msg.suggestedProducts.map((sp) => (
                              <div 
                                key={sp.id} 
                                onClick={() => {
                                  setSelectedProduct(sp);
                                  setIsChatOpen(false);
                                }}
                                className="bg-neutral-50 hover:bg-white border border-neutral-200 p-1.5 rounded cursor-pointer transition text-left"
                              >
                                <img src={sp.images[0]} referrerPolicy="no-referrer" className="w-full h-12 object-cover rounded" alt={sp.name} />
                                <p className="text-[9px] text-neutral-800 font-bold truncate mt-1">{sp.name}</p>
                                <p className="text-[8px] text-emerald-900 font-black">৳{(sp.discountPrice || sp.price).toLocaleString()}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-1 text-[9px] text-neutral-455 mt-1">
                      <span>{msg.timestamp}</span>
                      <span className="flex items-center text-[#53bdeb] font-black text-xs select-none tracking-tighter" title="Message Read">
                        ✓✓
                      </span>
                    </div>

                  </div>
                );
              })}

              {/* simulated AI typing indicator */}
              {isAiTyping && (
                <div className="flex flex-col items-start">
                  <div className="bg-white p-3 rounded-lg border border-neutral-100 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-emerald-900 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-emerald-900 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                    <span className="w-1.5 h-1.5 bg-emerald-900 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                  </div>
                  <span className="text-[8px] text-neutral-400 mt-1">AI coordinates outfit...</span>
                </div>
              )}
              
              <div ref={chatEndRef} />
            </div>

            {/* Input message form sender */}
            <form onSubmit={handleSendChatMessage} className="p-2 border-t border-neutral-200 bg-white flex gap-1.5 items-center">
              <input 
                type="text" 
                placeholder="পাঞ্জাবী দেখাও বা ডেলিভারি?" 
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                className="flex-grow pl-3 pr-2 py-2 text-xs rounded border border-neutral-200 focus:outline-none focus:ring-1 focus:ring-emerald-900 text-sm"
              />
              <button 
                type="submit"
                className="bg-emerald-900 hover:bg-emerald-850 text-white p-2 text-xs rounded shadow"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

          </div>
        ) : (
          
          /* Pulsing Luxury Launch Button */
          <button
            onClick={() => setIsChatOpen(true)}
            className="group bg-emerald-950 text-white p-4 rounded-full shadow-2xl flex items-center gap-2 hover:bg-emerald-900 transition-all duration-300 pointer-events-auto border border-yellow-500/20 relative animate-pulse"
            title="Ask LazyChat AI assistance"
          >
            <MessageSquare className="w-5 h-5 text-yellow-550 group-hover:rotate-12 transition-transform duration-300" />
            <span className="text-xs font-bold tracking-widest uppercase hidden md:inline ml-0.5">LAZYCHAT AI ASSISTANT</span>
            <span className="absolute -top-1 -right-1 bg-yellow-500 rounded-full text-[9px] text-emerald-950 px-1 font-bold">LIVE</span>
          </button>
        )}
      </div>

      {/* 12. ADMIN PORTAL COMPARTMENT PANEL */}
      {isAdminOpen && (
        <div id="admin-portal-modal" className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-lg max-w-5xl w-full shadow-2xl p-6 md:p-8 relative max-h-[90vh] overflow-y-auto my-10 border border-emerald-950">
            
            <button 
              onClick={() => setIsAdminOpen(false)}
              className="absolute right-4 top-4 p-2 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 transition"
              title="Close portal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-6 border-b border-neutral-100 pb-4">
              <Shield className="w-6 h-6 text-emerald-900 shrink-0" />
              <div>
                <h3 className="font-serif font-black text-xl text-neutral-900 uppercase">L'AURA MANAGERIAL PORTAL</h3>
                <p className="text-xs text-neutral-400 font-light">Role: Admin Authorized Panel</p>
              </div>
              {adminToken && (
                <button 
                  onClick={handleAdminLogout}
                  className="ml-auto bg-neutral-250 hover:bg-red-50 hover:text-red-700 font-bold px-4 py-1.5 rounded border border-neutral-200 text-xs transition uppercase"
                >
                  Logout Manager
                </button>
              )}
            </div>

            {/* IF NOT AUTHENTICATED -> RENDER LOGIN ATTEMPTS */}
            {!adminToken ? (
              <div className="max-w-md mx-auto py-8">
                {/* Visual highlight box for security authorization */}
                <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded mb-6 text-xs text-amber-900 leading-relaxed font-medium">
                  🔒 <strong className="font-extrabold uppercase text-amber-955">গুরুত্বপূর্ণ নিরাপত্তা নোটিশ:</strong> এই প্যানেলটি শুধুমাত্র ম্যানেজমেন্টের জন্য সংরক্ষিত। প্রবেশ তথ্য সম্পূর্ণ গোপনীয় এবং কোনো অবস্থাতেই শেয়ার করা যাবে না।
                </div>

                <p className="text-xs text-neutral-500 mb-6 text-center leading-relaxed">
                  নিচের ঘরে আপনার সঠিক ইউজারনেম ও পাসওয়ার্ড দিয়ে প্রবেশ করুন:
                </p>
                <form onSubmit={handleAdminLogin} className="space-y-4">
                  {loginError && (
                    <div className="bg-red-50 text-red-700 p-3 rounded text-xs flex items-center gap-2 border border-red-100 animate-pulse">
                      <AlertCircle className="w-4.5 h-4.5 shrink-0" />
                      <span>{loginError}</span>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-widest mb-1.5">ইউজারনেম (Username)</label>
                    <input 
                      type="text" 
                      required
                      placeholder="আপনার ইউজারনেম লিখুন"
                      value={loginUsername}
                      onChange={(e) => setLoginUsername(e.target.value)}
                      className="w-full px-3 py-2 rounded h-11 border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-emerald-900 text-sm font-semibold transition"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-widest mb-1.5">পাসওয়ার্ড (Password)</label>
                    <div className="relative">
                      <input 
                        type="password" 
                        required
                        placeholder="••••••••••••••"
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        className="w-full px-3 py-2 rounded h-11 border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-emerald-900 text-sm font-sans transition"
                      />
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full bg-emerald-950 hover:bg-emerald-900 active:scale-98 text-white font-black py-3.5 rounded text-xs tracking-widest uppercase transition mt-6 flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/10"
                  >
                    <Shield className="w-4 h-4 text-emerald-400" /> প্যানেলে সাইন-ইন করুন (Sign-In)
                  </button>
                </form>
              </div>
            ) : (
              
              /* IF AUTHENTICATED -> RENDER COMPLETE MANAGER TOOL */
              <div className="space-y-6">
                
                {/* Local Inner Tab control */}
                <div className="flex gap-2 border-b border-neutral-100 pb-3 overflow-x-auto">
                  <button 
                    onClick={() => setAdminTab('analytics')}
                    className={`px-4 py-2 rounded text-xs font-bold uppercase transition shrink-0 ${
                      adminTab === 'analytics' ? "bg-emerald-950 text-yellow-300" : "bg-neutral-100 text-neutral-600 hover:bg-neutral-200"
                    }`}
                  >
                    📊 Real-Time Analytics
                  </button>
                  <button 
                    onClick={() => setAdminTab('products')}
                    className={`px-4 py-2 rounded text-xs font-bold uppercase transition shrink-0 ${
                      adminTab === 'products' ? "bg-emerald-950 text-yellow-300" : "bg-neutral-100 text-neutral-600 hover:bg-neutral-200"
                    }`}
                  >
                    📦 Product Catalog Manager
                  </button>
                  <button 
                    onClick={() => setAdminTab('orders')}
                    className={`px-4 py-2 rounded text-xs font-bold uppercase transition shrink-0 ${
                      adminTab === 'orders' ? "bg-emerald-950 text-yellow-300" : "bg-neutral-100 text-neutral-600 hover:bg-neutral-200"
                    }`}
                  >
                    🛒 Customer Orders List ({orders.length})
                  </button>
                  <button 
                    onClick={() => setAdminTab('settings')}
                    className={`px-4 py-2 rounded text-xs font-bold uppercase transition shrink-0 ${
                      adminTab === 'settings' ? "bg-emerald-950 text-yellow-300" : "bg-neutral-100 text-neutral-600 hover:bg-neutral-200"
                    }`}
                  >
                    ⚙️ Shop Settings
                  </button>
                </div>

                {/* TAB A: REAL TIME ANALYTICS SECTION */}
                {adminTab === 'analytics' && (
                  <div className="space-y-6">
                    
                    {/* Visual cards row */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      
                      <div className="bg-emerald-50 border border-emerald-150 p-4 rounded-lg">
                        <span className="text-[10px] text-emerald-800 uppercase font-black block">MANUAL VERIFIED SALES</span>
                        <p className="text-2xl font-black text-emerald-955 font-serif mt-1">৳{analytics?.totalSales?.toLocaleString() || "0"}</p>
                        <span className="text-[9px] text-neutral-455">Excludes pending checks</span>
                      </div>

                      <div className="bg-neutral-50 p-4 rounded-lg border border-neutral-100">
                        <span className="text-[10px] text-neutral-500 uppercase font-bold block">ALL INCOMING REQUESTS</span>
                        <p className="text-2xl font-bold text-neutral-850 mt-1">{analytics?.totalOrders || "0"} Orders</p>
                        <span className="text-[9px] text-yellow-650 font-semibold">{analytics?.pending || "0"} Pending checks</span>
                      </div>

                      <div className="bg-red-50 p-4 rounded-lg border border-red-100">
                        <span className="text-[10px] text-red-800 uppercase font-extrabold block">STOCK CRITICAL ITEMS</span>
                        <p className="text-2xl font-black text-red-955 mt-1">{analytics?.stockOut || "0"} Out</p>
                        <span className="text-[9px] text-neutral-450">{analytics?.lowStock || "0"} running low</span>
                      </div>

                      <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-105">
                        <span className="text-[10px] text-yellow-800 uppercase font-extrabold block">ACTIVE SKU CATS</span>
                        <p className="text-2xl font-black text-yellow-950 mt-1">{analytics?.totalProducts || "0"} Designs</p>
                        <span className="text-[9px] text-neutral-450">Men, Women, Kids & Accessories</span>
                      </div>

                    </div>

                    {/* Category distribution */}
                    <div className="bg-neutral-50 p-5 rounded-lg border border-neutral-100">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-850 mb-3 block">Couture Categories Distribution</h4>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                        {analytics?.categoryCount && Object.keys(analytics.categoryCount).map((v) => (
                          <div key={v} className="bg-white p-3 rounded border border-neutral-150">
                            <span className="text-neutral-500 text-[10px] uppercase font-bold">{v}</span>
                            <p className="text-lg font-bold text-emerald-950 mt-1">{analytics.categoryCount[v]} SKU Items</p>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                )}

                {/* TAB B: PRODUCT CATALOG INVENTORY ENGINE */}
                {adminTab === 'products' && (
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    
                    {/* Add/Edit Left Side Form */}
                    <div className="bg-neutral-50 p-5 rounded-lg border border-neutral-200">
                      <h4 className="text-xs font-extrabold uppercase tracking-widest text-emerald-900 mb-4 pb-2 border-b border-neutral-200 flex items-center justify-between">
                        <span>{adminProductMode === 'create' ? "CREATE NEW ATTIRAL" : "EDIT COUTURE DESIGN"}</span>
                        {adminProductMode === 'edit' && (
                          <button onClick={resetProductForm} className="text-[9px] bg-red-650 text-white rounded px-2 py-0.5 cursor-pointer">Cancel Edit</button>
                        )}
                      </h4>

                      <form onSubmit={handleSaveProduct} className="space-y-4 text-xs font-medium">
                        
                        <div>
                          <label className="block text-neutral-600 mb-1 font-bold">Product Title *</label>
                          <input 
                            type="text" 
                            required
                            placeholder="যেমন: Pure Jamdani Saree"
                            value={adminProdName}
                            onChange={(e) => setAdminProdName(e.target.value)}
                            className="w-full px-2.5 py-2 rounded border border-neutral-300 focus:outline-none focus:ring-1 focus:ring-emerald-900 bg-white"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-neutral-600 mb-1 font-bold">Regular Price (৳) *</label>
                            <input 
                              type="number" 
                              required
                              placeholder="e.g. 15000"
                              value={adminProdPrice}
                              onChange={(e) => setAdminProdPrice(e.target.value)}
                              className="w-full px-2.5 py-2 rounded border border-neutral-300 focus:outline-none focus:ring-1 focus:ring-emerald-900 bg-white"
                            />
                          </div>
                          <div>
                            <label className="block text-neutral-600 mb-1 font-bold">Discount Price (৳)</label>
                            <input 
                              type="number" 
                              placeholder="e.g. 12000"
                              value={adminProdDiscPrice}
                              onChange={(e) => setAdminProdDiscPrice(e.target.value)}
                              className="w-full px-2.5 py-2 rounded border border-neutral-300 focus:outline-none focus:ring-1 focus:ring-emerald-900 bg-white"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-neutral-600 mb-1 font-bold">Category Classify *</label>
                            <select
                              value={adminProdCategory}
                              onChange={(e) => setAdminProdCategory(e.target.value as Category)}
                              className="w-full px-2.5 py-2 rounded border border-neutral-300 focus:outline-none focus:ring-1 focus:ring-emerald-950 bg-white"
                            >
                              {['Men', 'Women', 'Kids', 'Accessories'].map((cat) => (
                                <option key={cat} value={cat}>{cat}</option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-neutral-600 mb-1 font-bold">Available Stock Qty *</label>
                            <input 
                              type="number" 
                              required
                              placeholder="e.g. 24"
                              value={adminProdStock}
                              onChange={(e) => setAdminProdStock(e.target.value)}
                              className="w-full px-2.5 py-2 rounded border border-neutral-300 focus:outline-none focus:ring-1 focus:ring-emerald-950 bg-white"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-neutral-600 mb-1 font-bold">Product Description *</label>
                          <textarea 
                            rows={3}
                            required
                            placeholder="যেমন: ঐতিহ্যবাহী জামदानी কাজের বিশুদ্ধ সুতি শাড়ি..."
                            value={adminProdDesc}
                            onChange={(e) => setAdminProdDesc(e.target.value)}
                            className="w-full px-2.5 py-2 rounded border border-neutral-300 focus:outline-none focus:ring-1 focus:ring-emerald-950 bg-white"
                          />
                        </div>

                        {/* Sizes selector checklist */}
                        <div>
                          <label className="block text-neutral-600 mb-1.5 font-bold">Sizes Option Availability:</label>
                          <div className="flex gap-4">
                            {(['S', 'M', 'L', 'XL'] as SizeOption[]).map((sz) => (
                              <label key={sz} className="flex items-center gap-1 cursor-pointer">
                                <input 
                                  type="checkbox" 
                                  checked={adminProdSizes.includes(sz)}
                                  onChange={(e) => {
                                    if (e.target.checked) setAdminProdSizes([...adminProdSizes, sz]);
                                    else setAdminProdSizes(adminProdSizes.filter(s => s !== sz));
                                  }}
                                />
                                <span className="font-bold">{sz}</span>
                              </label>
                            ))}
                          </div>
                        </div>

                        {/* Drag and Drop Local Photo Uploader */}
                        <div className="space-y-1.5">
                          <label className="block text-neutral-650 font-bold mb-1">Upload Local Image Files directly:</label>
                          <div className="border border-dashed border-neutral-300 hover:border-emerald-950 rounded-lg p-3 text-center bg-neutral-50 hover:bg-neutral-100 transition relative">
                            <input 
                              type="file" 
                              accept="image/*" 
                              multiple 
                              onChange={handleLocalImageUpload} 
                              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                            />
                            <div className="flex flex-col items-center gap-1">
                              <Upload className="w-4 h-4 text-emerald-950" />
                              <span className="text-[10px] font-bold text-neutral-700">ডিভাইস থেকে পোশাকের ছবি যুক্ত করুন (Upload File)</span>
                              <span className="text-[9px] text-neutral-400">ক্লিক করুন অথবা এখানে ড্র্যাগ করে ফেলুন (সর্বোচ্চ ৪ টি ছবি)</span>
                            </div>
                          </div>
                          
                          {/* Rich mini preview list */}
                          <div className="flex gap-2.5 pt-1 overflow-x-auto">
                            {adminProdImages.map((img, idx) => (
                              <div key={idx} className="relative group w-12 h-12 rounded border border-neutral-200 bg-neutral-100 flex items-center justify-center shrink-0 overflow-hidden">
                                {img ? (
                                  <>
                                    <img src={img} referrerPolicy="no-referrer" alt="" className="w-full h-full object-cover" />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const copy = [...adminProdImages];
                                        copy[idx] = "";
                                        setAdminProdImages(copy);
                                      }}
                                      className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white"
                                    >
                                      <Trash2 className="w-3.5 h-3.5 text-white" />
                                    </button>
                                  </>
                                ) : (
                                  <span className="text-[9px] text-neutral-450 font-bold">#{idx + 1}</span>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Images array upload entry URLs */}
                        <div className="space-y-2">
                          <label className="block text-neutral-650 font-bold mb-1">Product Design Images (Include up to 4 URL Links):</label>
                          {adminProdImages.map((link, lidx) => (
                            <input 
                              key={lidx}
                              type="url" 
                              placeholder={`Image URL Link #${lidx + 1}`}
                              value={link}
                              onChange={(e) => {
                                const copy = [...adminProdImages];
                                copy[lidx] = e.target.value;
                                setAdminProdImages(copy);
                              }}
                              className="w-full px-2.5 py-1.5 rounded border border-neutral-300 text-[11px] focus:outline-none bg-white font-mono"
                            />
                          ))}
                          <span className="text-[9px] text-neutral-450 block">If left empty, high-resolution placeholder is appended.</span>
                        </div>

                        <button
                          type="submit"
                          className="w-full bg-emerald-900 hover:bg-emerald-850 text-white font-black py-3 rounded uppercase tracking-widest transition shadow mt-3 shrink-0 cursor-pointer text-xs"
                        >
                          {adminProductMode === 'create' ? "PUBLISH SKU ITEMS" : "APPLY EDIT CHANGES"}
                        </button>

                      </form>
                    </div>

                    {/* Products Grid list for Edit/Delete */}
                    <div className="lg:col-span-2 space-y-3">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-850 block pb-1.5">Registered SKUs ({products.length} Designs)</h4>
                      
                      <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-1">
                        {products.map((p) => (
                          <div key={p.id} className="p-3 bg-white border border-neutral-200 rounded flex gap-3 items-center justify-between text-xs">
                            <img src={p.images[0]} referrerPolicy="no-referrer" alt={p.name} className="w-12 h-12 object-cover rounded bg-neutral-100 font-serif text-[8px]" />
                            <div className="flex-1 min-w-0">
                              <h5 className="font-bold text-neutral-900 truncate">{p.name}</h5>
                              <p className="text-[10px] text-neutral-455 uppercase">{p.category} • Price: ৳{p.price.toLocaleString()} • Stock: {p.stock} remaining</p>
                            </div>
                            
                            <div className="flex gap-1 shrink-0">
                              {deleteConfirmId === p.id ? (
                                <div className="flex items-center gap-1 bg-red-50 p-1.5 rounded border border-red-200">
                                  <span className="text-[10px] text-red-655 font-bold px-1.5 font-sans">ডিলিট?</span>
                                  <button 
                                    onClick={() => handleDeleteProduct(p.id)}
                                    className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-[9px] font-black uppercase transition cursor-pointer"
                                  >
                                    হ্যাঁ
                                  </button>
                                  <button 
                                    onClick={() => setDeleteConfirmId(null)}
                                    className="px-2.5 py-1 bg-neutral-200 hover:bg-neutral-300 text-neutral-850 rounded text-[9px] font-bold uppercase transition cursor-pointer"
                                  >
                                    না
                                  </button>
                                </div>
                              ) : (
                                <>
                                  <button 
                                    onClick={() => loadProductToEdit(p)}
                                    className="p-2 text-indigo-700 bg-indigo-50 rounded hover:bg-indigo-100 text-[10px] flex items-center gap-1 font-semibold cursor-pointer transition"
                                    title="Edit Product Specs"
                                  >
                                    <Edit className="w-3.5 h-3.5" /> Edit
                                  </button>
                                  <button 
                                    onClick={() => setDeleteConfirmId(p.id)}
                                    className="p-2 text-red-600 bg-red-50 rounded hover:bg-red-100 text-[10px] flex items-center gap-1 font-semibold cursor-pointer transition"
                                    title="Delete SKU Item"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" /> Delete
                                  </button>
                                </>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                )}


                {/* TAB C: SECURE ORDERS STREAM LIST */}
                {adminTab === 'orders' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-800">Customers Manual Payments & Delivery logs</h4>
                      <button onClick={fetchOrders} className="bg-neutral-100 text-neutral-700 rounded px-3 py-1 font-semibold hover:bg-neutral-200 text-xs text-emerald-950">Refresh Orders</button>
                    </div>

                    {orders.length === 0 ? (
                      <div className="py-12 bg-neutral-50 rounded-lg text-center border text-neutral-400">
                        No orders recorded in live persistent database file yet.
                      </div>
                    ) : (
                      <div className="space-y-4 max-h-[60vh] overflow-y-auto">
                        {orders.map((ord) => (
                          <div 
                            key={ord.id} 
                            className={`p-5 rounded border text-xs relative ${
                              ord.status === "Pending" ? "border-amber-200 bg-amber-50/15" : 
                              ord.status === "Confirmed" ? "border-emerald-200 bg-emerald-50/15" : 
                              ord.status === "Shipped" ? "border-indigo-200 bg-indigo-50/15" :
                              "border-neutral-250 bg-neutral-50/40"
                            }`}
                          >
                            
                            {/* Inner Header info */}
                            <div className="flex flex-col sm:flex-row justify-between mb-4 gap-2 border-b border-neutral-150 pb-2">
                              <div>
                                <span className="font-mono font-bold bg-neutral-200/80 px-2 py-0.5 rounded mr-2 text-[10px]">{ord.id}</span>
                                <span className="text-[10px] text-neutral-400">{new Date(ord.createdAt).toLocaleString()}</span>
                              </div>
                              
                              {/* Order process buttons and Delivery Switch cycles */}
                              <div className="flex flex-wrap items-center gap-2">
                                <span className={`px-2.5 py-1 text-[10px] font-black rounded uppercase tracking-wider ${
                                  ord.status === "Pending" ? "bg-yellow-150 text-yellow-900 border border-yellow-300" :
                                  ord.status === "Confirmed" ? "bg-emerald-150 text-emerald-950 border border-emerald-300" :
                                  ord.status === "Shipped" ? "bg-indigo-150 text-indigo-950 border border-indigo-300" :
                                  "bg-neutral-200 text-neutral-800 border border-neutral-300"
                                }`}>
                                  {ord.status}
                                </span>

                                <div className="h-5 w-px bg-neutral-300 mx-1 hidden sm:block"></div>
                                
                                {/* 🚚 Direct delivery switch dropdown */}
                                <div className="flex items-center gap-1 bg-white px-2 py-1 rounded border border-neutral-250 shadow-xs">
                                  <span className="text-[10px] font-extrabold text-neutral-500 uppercase">ডেলিভারি সুইচ:</span>
                                  <select
                                    value={ord.status}
                                    onChange={(e) => handleUpdateOrderStatus(ord.id, e.target.value as any)}
                                    className="bg-transparent border-none text-[10px] font-black text-emerald-950 px-1 focus:outline-none cursor-pointer"
                                    title="অর্ডারের ডেলিভারি স্ট্যাটাস সরাসরি পরিবর্তন করুন"
                                  >
                                    <option value="Pending">Pending</option>
                                    <option value="Confirmed">Confirmed</option>
                                    <option value="Shipped">Shipped</option>
                                    <option value="Delivered">Delivered</option>
                                  </select>
                                </div>

                                <div className="h-5 w-px bg-neutral-300 mx-1 hidden sm:block"></div>
                                
                                {ord.status === "Pending" && (
                                  <button 
                                    onClick={() => handleUpdateOrderStatus(ord.id, "Confirmed")}
                                    className="bg-emerald-900 text-white rounded px-2.5 py-1 text-[10px] font-extrabold hover:bg-emerald-850 cursor-pointer transition"
                                  >
                                    Confirm Payment
                                  </button>
                                )}
                                {ord.status === "Confirmed" && (
                                  <button 
                                    onClick={() => handleUpdateOrderStatus(ord.id, "Shipped")}
                                    className="bg-indigo-805 text-white rounded px-2.5 py-1 text-[10px] font-extrabold hover:bg-indigo-750 cursor-pointer transition"
                                  >
                                    Ship Order
                                  </button>
                                )}
                                {ord.status === "Shipped" && (
                                  <button 
                                    onClick={() => handleUpdateOrderStatus(ord.id, "Delivered")}
                                    className="bg-neutral-800 text-white rounded px-2.5 py-1 text-[10px] font-extrabold hover:bg-neutral-750 cursor-pointer transition"
                                  >
                                    Delivered (কনফার্ম)
                                  </button>
                                )}
                              </div>
                            </div>

                            {/* Inner Details description */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1 bg-white p-3 rounded border border-neutral-150">
                                <p className="font-extrabold text-neutral-800 text-[10.5px]">👤 DELIVERY CONTACT DETAILS (গ্রাহকের তথ্য):</p>
                                <p><strong>Full Customer Name:</strong> {ord.userName}</p>
                                <p><strong>Active Contact Phone:</strong> <span className="font-bold text-emerald-900 bg-emerald-50 px-1 rounded">{ord.phone}</span></p>
                                <p><strong>Address:</strong> {ord.address}</p>
                              </div>

                              <div className="space-y-1 bg-white p-3 rounded border border-neutral-150">
                                <p className="font-extrabold text-emerald-950 text-[10.5px]">💳 PAYMENT & ORDER RECEIPT (পেমেন্ট ও অর্ডার বিবরণ):</p>
                                <p><strong>Product Ordered:</strong> {ord.productName} (Size: {ord.size})</p>
                                <p><strong>Manual Method:</strong> {ord.paymentMethod}</p>
                                  <p><strong>Transaction Reference ID:</strong> <span className="font-mono bg-yellow-50 px-1 text-xs text-yellow-800 font-extrabold border border-yellow-200 uppercase">{ord.transactionId || "N/A"}</span></p>
                                <p><strong>Amount Collected:</strong> <strong className="text-emerald-950">৳{ord.amount.toLocaleString()} BD Taka</strong></p>
                              </div>
                            </div>

                            {/* Customer Information Deletion / Purge Interface */}
                            {ord.status === "Delivered" ? (
                              <div className="mt-4 p-3.5 bg-red-50/50 border border-red-205 rounded-lg flex flex-col sm:flex-row gap-3 items-center justify-between">
                                <div className="text-left space-y-1">
                                  <p className="text-[11px] font-extrabold text-red-800 uppercase tracking-wide flex items-center gap-1">
                                    <span>✅ ডেলিভারি নিশ্চিত হয়েছে! (Delivery Confirmed)</span>
                                  </p>
                                  <p className="text-[10px] text-neutral-600 leading-normal font-medium">গ্রাহকের গোপনীয়তা ও ডাটা সুরক্ষার স্বার্থে, আপনি চাইলে এখন এই গ্রাহকের সকল তথ্য এবং ডেলিভারি ডিটেইলস ডাটাবেস থেকে স্থায়িভাবে ডিলিট করতে পারেন।</p>
                                </div>
                                
                                <div className="shrink-0">
                                  {orderDeleteConfirmId === ord.id ? (
                                    <div className="flex items-center gap-1.5 bg-white p-2 rounded border border-red-250 shadow-md">
                                      <span className="text-[10px] text-red-800 font-black">ডাটা ডিলিট নিশ্চিত?</span>
                                      <button 
                                        onClick={() => handleDeleteOrder(ord.id)}
                                        className="bg-red-700 hover:bg-red-800 text-white px-2.5 py-1.5 rounded font-black text-[9px] uppercase cursor-pointer transition-colors"
                                      >
                                        হ্যাঁ, অবশ্যই
                                      </button>
                                      <button 
                                        onClick={() => setOrderDeleteConfirmId(null)}
                                        className="bg-neutral-100 hover:bg-neutral-200 text-neutral-800 px-2 py-1.5 rounded text-[9px] font-bold cursor-pointer transition-colors"
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  ) : (
                                    <button 
                                      onClick={() => setOrderDeleteConfirmId(ord.id)}
                                      className="bg-red-600 hover:bg-red-700 active:scale-95 text-white px-3.5 py-2 rounded font-extrabold flex items-center gap-1.5 transition text-[10px] uppercase shadow-md shadow-red-900/10 cursor-pointer"
                                      title="গ্রাহকের সকল তথ্য ডিলিট করুন"
                                    >
                                      <Trash2 className="w-3.5 h-3.5 text-white" />
                                      কাস্টমার তথ্য ও অর্ডার মুছুন
                                    </button>
                                  )}
                                </div>
                              </div>
                            ) : (
                              <div className="mt-4 p-2 bg-neutral-100/60 border border-neutral-200 rounded text-center text-[10px] text-neutral-500 font-medium">
                                🔒 প্রথমে ডেলিভারি সম্পন্ন করুন (ডেলিভারি সুইচ থেকে <span className="font-bold text-neutral-700">"Delivered"</span> সিলেক্ট করুন), তারপর গ্রাহকের সকল গোপনীয় তথ্য ডিলিট করার অ্যাক্সেস উন্মুক্ত হবে।
                              </div>
                            )}

                          </div>
                        ))}
                      </div>
                    )}

                  </div>
                )}

                {/* TAB D: SHOP SETTINGS SECTION */}
                {adminTab === 'settings' && (
                  <div className="bg-white rounded-xl border border-neutral-100 p-6 shadow-sm space-y-6">
                    <div className="flex items-center justify-between border-b border-neutral-100 pb-4">
                      <div>
                        <h3 className="font-serif font-black text-lg text-emerald-950">⚙️ দোকান ও যোগাযোগ সেটিং</h3>
                        <p className="text-xs text-neutral-500 mt-1">Contact number, Account details, bKash/Nagad number এবং Footer text পরিবর্তন করতে পারেন</p>
                      </div>
                    </div>

                    <form onSubmit={(e) => {
                      e.preventDefault();
                      handleUpdateSettings(shopSettings);
                    }} className="space-y-6">
                      
                      {/* Section: Contact & Support */}
                      <div>
                        <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-widest border-l-4 border-emerald-950 pl-2 mb-4">📞 সাধারণ যোগাযোগ ও সাপোর্ট</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <label className="block text-xs font-black text-neutral-700 mb-1.5 font-sans">মার্চেন্ট ফোন নাম্বার (Merchant Phone)</label>
                            <input 
                              type="text" 
                              required
                              value={shopSettings.merchantPhone}
                              onChange={(e) => setShopSettings({...shopSettings, merchantPhone: e.target.value})}
                              className="w-full px-3.5 py-2 rounded-lg border border-neutral-200 text-xs focus:ring-1 focus:ring-emerald-950 text-emerald-950 font-mono focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-black text-neutral-700 mb-1.5 font-sans">সাপোর্ট ফোন নাম্বার (Support Phone)</label>
                            <input 
                              type="text" 
                              required
                              value={shopSettings.supportPhone || ""}
                              onChange={(e) => setShopSettings({...shopSettings, supportPhone: e.target.value})}
                              className="w-full px-3.5 py-2 rounded-lg border border-neutral-200 text-xs focus:ring-1 focus:ring-emerald-950 text-emerald-950 font-mono focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-black text-neutral-700 mb-1.5 font-sans">হোয়াটসঅ্যাপ নাম্বার (WhatsApp: e.g. 880183...)</label>
                            <input 
                              type="text" 
                              required
                              value={shopSettings.whatsAppNumber}
                              onChange={(e) => setShopSettings({...shopSettings, whatsAppNumber: e.target.value})}
                              className="w-full px-3.5 py-2 rounded-lg border border-neutral-200 text-xs focus:ring-1 focus:ring-emerald-950 text-emerald-950 font-mono focus:outline-none"
                            />
                            <p className="text-[10px] text-neutral-400 mt-1 font-sans">Country code সহ লিখবেন (যেমন: 8801836437598)</p>
                          </div>
                        </div>
                      </div>

                      {/* Section: Automated Mobile Wallets */}
                      <div>
                        <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-widest border-l-4 border-emerald-950 pl-2 mb-4">💸 মোবাইল ব্যাংকিং ওয়ালেট সমুহ (পেমেন্ট নাম্বার)</h4>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <div>
                            <label className="block text-xs font-black text-neutral-700 mb-1.5 font-sans">bKash ওয়ালেট নাম্বার</label>
                            <input 
                              type="text" 
                              required
                              value={shopSettings.bkashNumber || ""}
                              onChange={(e) => setShopSettings({...shopSettings, bkashNumber: e.target.value})}
                              className="w-full px-3.5 py-2 rounded-lg border border-neutral-200 text-xs focus:ring-1 focus:ring-emerald-950 text-emerald-950 font-mono focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-black text-neutral-700 mb-1.5 font-sans">Nagad ওয়ালেট নাম্বার</label>
                            <input 
                              type="text" 
                              required
                              value={shopSettings.nagadNumber || ""}
                              onChange={(e) => setShopSettings({...shopSettings, nagadNumber: e.target.value})}
                              className="w-full px-3.5 py-2 rounded-lg border border-neutral-200 text-xs focus:ring-1 focus:ring-emerald-950 text-emerald-950 font-mono focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-black text-neutral-700 mb-1.5 font-sans">Rocket ওয়ালেট নাম্বার</label>
                            <input 
                              type="text" 
                              required
                              value={shopSettings.rocketNumber || ""}
                              onChange={(e) => setShopSettings({...shopSettings, rocketNumber: e.target.value})}
                              className="w-full px-3.5 py-2 rounded-lg border border-neutral-200 text-xs focus:ring-1 focus:ring-emerald-950 text-emerald-950 font-mono focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-black text-neutral-700 mb-1.5 font-sans">Upay ওয়ালেট নাম্বার</label>
                            <input 
                              type="text" 
                              required
                              value={shopSettings.upayNumber || ""}
                              onChange={(e) => setShopSettings({...shopSettings, upayNumber: e.target.value})}
                              className="w-full px-3.5 py-2 rounded-lg border border-neutral-200 text-xs focus:ring-1 focus:ring-emerald-950 text-emerald-950 font-mono focus:outline-none"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Section: Automated Real-time Order Notifications (Telegram Bot) */}
                      <div>
                        <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-widest border-l-4 border-emerald-950 pl-2 mb-4">🤖 রিয়েল-টাইম অর্ডার সাইলেন্ট নোটিফিকেশন সিস্টেম (Telegram Bot)</h4>
                        <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200/60 space-y-4">
                          <p className="text-[11px] text-neutral-650 leading-relaxed font-sans">
                            হোয়াটসঅ্যাপের সিকিউরিটি নিয়মের কারণে ক্রেতার ব্রাউজার থেকে ক্রেতাকে সরাসরি কোনো মেসেজ না দেখিয়ে আপনার ফোনে অটোমেটিক ব্যাকগ্রাউন্ড মেসেজ পাঠানো সম্ভব নয়। তবে একটি <strong>টেলিগ্রাম বট (Telegram Bot)</strong> ব্যবহারের মাধ্যমে আপনি সম্পূর্ণ সাইলেন্টলি প্রতিটি অর্ডারের নিখুঁত নোটিফিকেশন আপনার ফোনে সেকেন্ডের মধ্যে পেয়ে যাবেন! ক্রেতা কিছুই জানতে পারবে না।
                          </p>
                          
                          <div className="flex items-center gap-3 bg-white p-3 rounded-lg border border-neutral-200">
                            <input 
                              type="checkbox" 
                              id="enableTelegramNotifications"
                              checked={shopSettings.enableTelegramNotifications || false}
                              onChange={(e) => setShopSettings({...shopSettings, enableTelegramNotifications: e.target.checked})}
                              className="w-4 h-4 text-emerald-950 border-neutral-300 rounded focus:ring-emerald-900 cursor-pointer"
                            />
                            <label htmlFor="enableTelegramNotifications" className="text-xs font-extrabold text-neutral-800 cursor-pointer select-none">
                              স্বয়ংক্রিয় ব্যাকগ্রাউন্ড নোটিফিকেশন চালু করুন (Enable Silent Telegram Notification System)
                            </label>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-xs font-black text-neutral-700 mb-1.5 font-sans">টেলিগ্রাম বট টোকেন (Telegram Bot Token)</label>
                              <input 
                                type="text" 
                                placeholder="যেমন: 12345678:AAFCaXy..."
                                value={shopSettings.telegramBotToken || ""}
                                onChange={(e) => setShopSettings({...shopSettings, telegramBotToken: e.target.value})}
                                className="w-full px-3.5 py-2 rounded-lg border border-neutral-200 text-xs focus:ring-1 focus:ring-emerald-950 text-emerald-950 font-mono focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-black text-neutral-700 mb-1.5 font-sans">আপনার টেলিগ্রাম চ্যাট আইডি (Chat ID or Group ID)</label>
                              <input 
                                type="text" 
                                placeholder="যেমন: 9876543210"
                                value={shopSettings.telegramChatId || ""}
                                onChange={(e) => setShopSettings({...shopSettings, telegramChatId: e.target.value})}
                                className="w-full px-3.5 py-2 rounded-lg border border-neutral-200 text-xs focus:ring-1 focus:ring-emerald-950 text-emerald-950 font-mono focus:outline-none"
                              />
                            </div>
                          </div>

                          <div className="text-[10px] text-neutral-500 font-sans space-y-1 mt-2 p-3 bg-white rounded-lg border border-neutral-100">
                            <p className="font-bold text-emerald-950 text-[11px]">💡 নোটিফিকেশন সিস্টেম চালু করার অত্যন্ত সহজ নিয়মাবলী:</p>
                            <p>১. টেলিগ্রামে সার্চ করুন <strong>@BotFather</strong> এবং <code>/newbot</code> লিখে আপনার ব্র্যান্ডের নামে একটি বট তৈরি করুন ও বটের <strong>Token</strong> কপি করে এখানে বসান।</p>
                            <p>২. বটের ইনবক্সে গিয়ে <code>/start</code> দিন। এরপর <strong>@userinfobot</strong> দিয়ে আপনার ও বটের নিজস্ব <strong>Chat ID</strong> বের করে এখানে বসান।</p>
                            <p>৩. এরপর <strong>Save Changes</strong> বোতাম চাপুন। ক্রেতা অর্ডার করার পরপরই আপনার মোবাইলের চ্যাটে স্বয়ংক্রিয় মেসেজ চলে আসবে!</p>
                          </div>
                        </div>
                      </div>

                      {/* Section: Website Branding Description */}
                      <div>
                        <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-widest border-l-4 border-emerald-950 pl-2 mb-4">✨ ফুটার টেক্সট ও ব্র্যান্ড বায়ো</h4>
                        <div>
                          <label className="block text-xs font-black text-neutral-700 mb-1.5 font-sans">ফুটার পরিচিতি বক্তব্য (Footer Brand Bio)</label>
                          <textarea 
                            rows={3}
                            required
                            value={shopSettings.footerText || ""}
                            onChange={(e) => setShopSettings({...shopSettings, footerText: e.target.value})}
                            className="w-full px-3.5 py-2 rounded-lg border border-neutral-200 text-xs focus:ring-1 focus:ring-emerald-950 text-emerald-950 font-sans focus:outline-none resize-none leading-relaxed"
                          />
                        </div>
                      </div>

                      {/* Form action button container */}
                      <div className="flex justify-end pt-4 border-t border-neutral-100">
                        <button
                          type="submit"
                          className="bg-emerald-950 hover:bg-emerald-850 active:scale-95 text-yellow-300 font-extrabold px-6 py-2.5 rounded-lg text-xs tracking-wide shadow-md shadow-emerald-950/20 hover:shadow-lg transition-all duration-150 cursor-pointer flex items-center gap-2 font-sans uppercase"
                        >
                          Save Changes (সংরক্ষণ করুন)
                        </button>
                      </div>

                    </form>
                  </div>
                )}

              </div>
            )}

          </div>
        </div>
      )}

      {/* 13. PRESTIGE FOOTER MARKERS */}
      {currentTab !== 'LazyChat' && (
        <footer id="app-footer" className="bg-emerald-950 text-neutral-100 border-t border-yellow-500/10 py-12 px-4 mt-20 relative overflow-hidden">
          
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 relative z-10">
            
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="w-9 h-9 rounded-full bg-emerald-900 flex items-center justify-center text-yellow-500 font-serif font-extrabold text-lg border border-yellow-500/30">L</span>
                <span className="font-serif font-black tracking-wide text-lg text-white">L'AURA LUXE</span>
              </div>
              
              <p className="text-xs text-neutral-300 leading-relaxed font-light">
                {shopSettings.footerText || "বাংলাদেশি ফ্যাশন ঐতিহ্যের আসল ঠিকানা। আমাদের প্রতিটি কাজের পেছনে রয়েছে নিপুণ হাতের স্পর্শ ও ঐতিহ্যবাহী জর্দোসি কাজের বিশুদ্ধতা।"}
              </p>
              <div className="flex gap-3 text-xs pt-1.5">
                <button onClick={triggerWhatsApp} className="bg-white/5 hover:bg-white/10 px-3.5 py-2 rounded text-neutral-300 flex items-center gap-1.5 transition">
                  <Phone className="w-3.5 h-3.5 text-yellow-400" /> {(shopSettings.whatsAppNumber.startsWith("+") || shopSettings.whatsAppNumber.startsWith("88")) ? "" : "+88"}{shopSettings.whatsAppNumber}
                </button>
              </div>
            </div>

            <div>
              <h4 className="font-serif font-bold text-sm tracking-wider text-white gap-1 flex items-center mb-4 uppercase">
                <span>Category Selection</span>
              </h4>
              <ul className="space-y-2 text-xs text-neutral-300">
                {['Men', 'Women', 'Kids', 'Accessories'].map((cat) => (
                  <li key={cat}>
                    <button 
                      onClick={() => {
                        setCurrentTab(cat as Category);
                        const sec = document.getElementById("products-catalog-section");
                        if (sec) sec.scrollIntoView({ behavior: "smooth" });
                      }} 
                      className="hover:text-yellow-400 transition"
                    >
                      ⚡ {cat} Fashion Couture
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-serif font-bold text-sm tracking-wider text-white mb-4 uppercase">Manual Payment flow</h4>
              <p className="text-xs text-neutral-300 leading-normal mb-3 font-light">
                আমরা ক্যাশ অন ডেলিভারি এবং দেশের প্রধান প্রধান মোবাইল পেমেন্ট গেটওয়েগুলো ম্যানুয়ালি সাপোর্ট করে থাকি:
              </p>
              <div className="flex flex-wrap gap-1">
                {['bKash', 'Nagad', 'Rocket', 'Upay'].map((g) => (
                  <span key={g} className="bg-emerald-950 border border-emerald-900/40 text-[9px] px-2.5 py-1 text-white uppercase rounded font-bold">{g}</span>
                ))}
              </div>
              <p className="text-[10px] text-yellow-500 font-mono mt-3">Account Number No: {shopSettings.merchantPhone}</p>
            </div>

            <div>
              <h4 className="font-serif font-bold text-sm tracking-wider text-white mb-4 uppercase">LazyChat Support</h4>
              <p className="text-xs text-neutral-300 leading-normal font-light">
                আমাদের আধুনিক এআই অ্যাসিস্ট্যান্ট আপনার যেকোনো পোশাক সাজেশনে সাহায্য করার জন্য ২৪/৭ লাইভ আছে। নিচে ডানদিকের আইকনে ট্যাপ করে চ্যাট চালু করুন!
              </p>
              <div className="pt-3">
                <button 
                  onClick={() => setIsChatOpen(true)}
                  className="bg-yellow-500 hover:bg-yellow-450 text-emerald-950 text-xs font-black px-4 py-2 rounded tracking-widest uppercase transition flex items-center gap-1"
                >
                  <Sparkles className="w-3.5 h-3.5" /> Start AI Chat
                </button>
              </div>
            </div>

          </div>

          <div className="max-w-7xl mx-auto mt-12 pt-6 border-t border-white/5 flex flex-col md:flex-row justify-between text-[11px] text-neutral-450 gap-4">
            <p>© 2026 L'AURA LUXE BD. All Premium Rigorous Rights Reserved. Custom Craft in Cloud Run platform.</p>
            <div className="flex gap-4">
              <span className="cursor-pointer hover:text-white" onClick={() => setIsAdminOpen(true)}>Staff Control Panel Log</span>
              <span>•</span>
              <span className="cursor-pointer hover:text-white" onClick={triggerWhatsApp}>Technical Support Contact</span>
            </div>
          </div>

        </footer>
      )}

      {/* Premium Elegant Floating Toast */}
      {toast && (
        <div id="toast-notify" className="fixed top-6 right-6 z-50 max-w-sm w-full bg-white text-emerald-950 rounded-xl shadow-2xl border border-neutral-100 p-4 animate-fade-in flex items-start gap-3.5 transition-all duration-300">
          <div className={`p-2 rounded-lg shrink-0 ${
            toast.type === 'success' ? 'bg-emerald-50 text-emerald-800' :
            toast.type === 'error' ? 'bg-red-50 text-red-700' :
            'bg-blue-50 text-blue-700'
          }`}>
            {toast.type === 'success' ? <CheckCheck className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          </div>
          <div className="flex-1">
            <p className="font-sans font-bold text-xs uppercase tracking-wider text-emerald-950">System Alert</p>
            <p className="font-sans font-medium text-[11px] text-neutral-600 mt-0.5 leading-snug">{toast.message}</p>
          </div>
          <button onClick={() => setToast(null)} className="text-neutral-400 hover:text-neutral-600 transition shrink-0 p-1 cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

    </div>
  );
}

/**
 * Gallery sub-component for premium item details modal.
 * Rotates on thumbnail clicks with exquisite focus indicators.
 */
function ProductImageGallery({ images, name }: { images: string[]; name: string }) {
  const [active, setActive] = useState(images[0] || "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=800");
  
  useEffect(() => {
    if (images && images.length > 0) {
      setActive(images[0] || "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=800");
    }
  }, [images]);
  
  return (
    <div className="space-y-3">
      <div className="aspect-square w-full rounded overflow-hidden bg-neutral-50 border">
        <img src={active} referrerPolicy="no-referrer" className="w-full h-full object-cover transition duration-300" alt={name} />
      </div>
      
      {images.length > 1 && (
        <div className="grid grid-cols-4 gap-2">
          {images.map((img, i) => (
            img && (
              <button
                key={i}
                onClick={() => setActive(img)}
                className={`aspect-square rounded overflow-hidden border transition ${
                  active === img ? "border-emerald-900 ring-2 ring-emerald-500/20" : "border-neutral-200 opacity-70 hover:opacity-100"
                }`}
              >
                <img src={img} referrerPolicy="no-referrer" className="w-full h-full object-cover" alt="angle view" />
              </button>
            )
          ))}
        </div>
      )}
    </div>
  );
}
