export type Category = 'Men' | 'Women' | 'Kids' | 'Accessories';

export type SizeOption = 'S' | 'M' | 'L' | 'XL';

export type PaymentMethod = 'bKash' | 'Nagad' | 'Rocket' | 'Upay' | 'Cash on Delivery';

export type OrderStatus = 'Pending' | 'Confirmed' | 'Shipped' | 'Delivered';

export interface Product {
  id: string;
  name: string;
  price: number;
  discountPrice?: number;
  description: string;
  images: string[]; // 3-4 image URLs
  stock: number;
  category: Category;
  sizes: SizeOption[];
  createdAt: string;
}

export interface Order {
  id: string;
  userName: string;
  phone: string;
  address: string;
  productId: string;
  productName: string;
  size: SizeOption;
  paymentMethod: PaymentMethod;
  transactionId: string;
  status: OrderStatus;
  amount: number;
  createdAt: string;
}

export interface UserProfile {
  id: string;
  email: string;
  userName: string;
  role: 'admin' | 'user';
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedProducts?: Product[];
  voiceUrl?: string; // Simulation voice URL
  voiceDuration?: string; // e.g. "0:12"
  imageUrl?: string; // photo attachment in message
  status?: 'sent' | 'delivered' | 'read'; // WhatsApp double ticks status
}
